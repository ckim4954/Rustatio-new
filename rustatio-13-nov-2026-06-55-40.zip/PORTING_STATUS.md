# PORTING_STATUS.md — Rustatio 2.14.1 PC → Android (Tauri 2)

## 1. Source Audit Summary (Rustatio 2.14.1)

Extracted from `public/assets/aistudio/rustatio-2.14.1_93289c7c.zip`.

### Cargo Workspace & Crates
- `rustatio-core`: Core BitTorrent ratio engine (`bencode`, `torrent/info.rs`, `torrent/client.rs`, `protocol/tracker.rs`, `protocol/peer.rs`, `faker.rs`, `peer_listener.rs`, `proxy.rs`, `config.rs`, `grid.rs`, `validation.rs`, `logger.rs`).
- `rustatio-watch`: Folder watch daemon (`notify` crate). Retained in workspace for desktop compatibility; watch daemon auto-start is gated off on Android/iOS (`#[cfg(not(any(target_os = "android", target_os = "ios")))]`).
- `rustatio-desktop`: Unified Tauri 2 desktop & mobile host (`lib.rs` with `#[cfg_attr(mobile, tauri::mobile_entry_point)] pub fn run()`, thin desktop `main.rs`, `commands/*`, `presets.rs`, `state.rs`, `persistence.rs`, `scheduler.rs`, `logging.rs`).
- `tauri-plugin-rustatio-android`: Custom Tauri 2 Android native plugin bridging SAF `.torrent` document picking (`ACTION_OPEN_DOCUMENT`), `RustatioForegroundService` (`foregroundServiceType="dataSync"`), Android 13+ `POST_NOTIFICATIONS` permission, and JSON Save/Share (`ACTION_CREATE_DOCUMENT` / `ACTION_SEND`).

### PC vs Android Compatibility Adaptations
1. **Tauri 2 Mobile Entrypoint**:
   - Split `rustatio-desktop` into library target `rustatio_lib` (`["staticlib", "cdylib", "rlib"]`) and thin binary `main.rs`. Desktop-only dependencies (`tray-icon`, `tauri-plugin-updater`, `tauri-plugin-process`, `os-release`) are gated under `#[cfg(not(any(target_os = "android", target_os = "ios")))]`.
2. **Persistence Paths (`persistence.rs` & `config.rs`)**:
   - Resolves `app.path().app_data_dir()` inside Tauri `.setup(...)` before loading configuration, state, or presets, storing `config.toml`, `desktop-state.json`, and `presets.json` atomically inside Android internal app storage.
3. **File Picker & Storage Access Framework (SAF)**:
   - Uses `Intent.ACTION_OPEN_DOCUMENT` + `ContentResolver.openInputStream(uri)` in `RustatioAndroidPlugin.kt`, base64-streaming validated `.torrent` bytes into Rust `TorrentInfo::from_bytes_summary(&bytes)` (`import_torrent_bytes`). Zero broad storage permissions requested.
4. **Background Execution & Foreground Service**:
   - Single Tracker Engine authority remains in Rust (`AppState` + `scheduler`). Kotlin `RustatioForegroundService` manages foreground notification lifecycle, `FOREGROUND_SERVICE_TYPE_DATA_SYNC`, bounded partial wake lock, and Android 13+ notification permission flow. Process-kill recovery restores persisted cumulative counters safely in `Stopped` state and emits `sessions-recovered`.
5. **Protocol, Target OS & Diagnostics Parity**:
   - Added `TargetOs` (`Windows 7`, `Windows 10`, `Windows 11`) across `ClientConfig`, `ClientSettings`, `FakerConfig`, `PresetSettings`, and `FakerStats`.
   - Implemented BEP-15 UDP tracker (`udp://`) announce/scrape alongside existing HTTP/HTTPS (`reqwest` + `rustls-tls`) in `rustatio-core/src/protocol/tracker.rs`.
   - Exposed real tracker diagnostics (`last_http_status`, `last_announce_at_ms`, `next_announce_at_ms`, `announce_interval_secs`, `peers_count`, `announce_in_progress`, `peer_id`, `key`, `user_agent`) preserving `None` when no announce has occurred.
6. **Announce Port vs Listening Port**:
   - Kept Announce Port (`client.default_port`) and local TCP Listening Port (`client.listening_enabled` + `client.listening_port`) explicitly separated in backend (`state.rs`, `commands/config.rs`) and Settings UI (`PortConfigSheet.svelte`).

---

## 2. Implementation Status

- [x] **Step 1**: Source extraction & audit of `rustatio-2.14.1`
- [x] **Step 2**: Workspace & `tauri-plugin-rustatio-android` (Kotlin Foreground Service + SAF `.torrent` picker + JSON share/save)
- [x] **Step 3**: Rust Backend Android adaptations (`rustatio-core`, `rustatio-desktop`, presets store, diagnostics, UDP tracker, Target OS)
- [x] **Step 4**: Svelte 5 + TypeScript Frontend (`Premium Soft Neumorphism 2.0`, Light Mint & Deep Forest, 3 tabs: `Phiên` / `Preset` / `Cài đặt`)
- [x] **Step 5**: GitHub Actions Release APK Workflow (`.github/workflows/android-release.yml`)
- [x] **Step 6**: Local UI build & static validation (`svelte-check`, `vite build`, JSON/TOML validation)

---

## 3. Verification & Acceptance Criteria Matrix

> **Environment Note**: Google AI Studio does **not** include `rustc`, `cargo`, `tauri-cli`, or the Android NDK. Rust compilation, native `.so` cross-compilation, and APK packaging are configured in `.github/workflows/android-release.yml` to run on Ubuntu GitHub Actions. Local verification executed `npm --prefix ui run check`, `npm --prefix ui run build`, and Python JSON/TOML validation.

| Hạng mục | Tiêu chí | Trạng thái | Ghi chú kiểm chứng |
|---|---|---|---|
| Frontend Build | `svelte-check` & `vite build` | VERIFIED (Local) | `svelte-check found 0 errors and 0 warnings`; `vite build` tạo `ui/dist` thành công |
| Config Schemas | JSON & TOML syntax | VERIFIED (Local) | Đã kiểm tra 9 file JSON và 6 file TOML hợp lệ |
| Tauri 2 Android | Build & khởi chạy APK trên Android | NOT TESTED | Chưa có `rustc`/`tauri-cli`/NDK tại local; chạy qua `.github/workflows/android-release.yml` |
| UI Screens | 3 tab chính (`Phiên`, `Preset`, `Cài đặt`) | VERIFIED (Code & UI Build) | Đã biên dịch thành công; cần test runtime trên Android |
| Navigation | Chuyển 3 tab BottomNav | NOT TESTED (Runtime) | Cần chạy trên Android/WebView thực tế |
| Theme | Light Mint / Deep Forest | NOT TESTED (Runtime) | CSS tokens & `set_dark_mode` đã nối; cần test runtime |
| Sessions | Hiển thị & điều khiển dữ liệu thật | NOT TESTED (Runtime) | Đã nối IPC tới Rust; cần test runtime |
| Search & Filter | Tìm kiếm & lọc chip trạng thái | NOT TESTED (Runtime) | Logic lọc theo `FakerStats` thực; cần test runtime |
| Import | Android File Picker SAF `.torrent` | NOT TESTED | Cần thiết bị/emulator Android thực |
| Metadata | Phân tích `.torrent` bằng `rustatio-core` | NOT TESTED | Cần biên dịch Rust trên CI |
| Tracker | Giao tiếp HTTP/HTTPS/UDP thật | NOT TESTED | Cần biên dịch Rust & mạng Android |
| Foreground Service | Duy trì dịch vụ nền & thông báo Android | NOT TESTED | Cần thiết bị Android thực |
| Preset | Tạo, sửa, nhân bản, mặc định, áp dụng, JSON I/O | NOT TESTED (Runtime) | Đã nối IPC & UI; cần test runtime |
| Settings | Client/Target OS, Announce vs Listening Port | NOT TESTED (Runtime) | Đã nối IPC & UI; cần test runtime |
| Persistence | Khôi phục trạng thái & dữ liệu sau khi đóng app | NOT TESTED | Cần `app_data_dir` trên Android runtime |
