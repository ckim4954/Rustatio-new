<script lang="ts">
  import {
    AlertTriangle,
    ArrowDown,
    ArrowUp,
    ChevronRight,
    Pause,
    Play,
    RotateCw,
    Square,
  } from '@lucide/svelte';
  import {
    extractTrackerHost,
    formatBytes,
    formatInfoHashHex,
    formatRateKbps,
    formatRatio,
    formatTargetOsLabel,
  } from '../lib/format';
  import { resolveSessionStatus } from '../lib/status';
  import { store } from '../lib/store.svelte';
  import type { InstanceInfo } from '../lib/types';

  interface Props {
    instance: InstanceInfo;
    onOpenDetails: (id: string) => void;
  }

  let { instance, onOpenDetails }: Props = $props();

  const status = $derived(resolveSessionStatus(instance, store.nowMs));
  const idNum = $derived(Number(instance.id));
  const trackerHost = $derived(extractTrackerHost(instance.torrent.announce));
  const shortHash = $derived(formatInfoHashHex(instance.torrent.info_hash).slice(0, 10));
  const isRunning = $derived(
    instance.stats.state === 'Running' || instance.stats.state === 'Starting',
  );
  const isPaused = $derived(instance.stats.state === 'Paused');
  const isStopped = $derived(instance.stats.state === 'Stopped');
</script>

<article class="session-card neu-card">
  <button
    type="button"
    class="card-main-tap"
    onclick={() => onOpenDetails(instance.id)}
    aria-label="Xem chi tiết phiên {instance.torrent.name}"
  >
    <div class="card-top">
      <div class="title-col">
        <h3 class="torrent-name">{instance.torrent.name}</h3>
        <div class="meta-line">
          <span class="tracker-host">{trackerHost}</span>
          <span>·</span>
          <span class="tabular-nums">{formatBytes(instance.torrent.total_size)}</span>
          <span>·</span>
          <span class="mono">{shortHash}</span>
        </div>
      </div>

      <span
        class="status-pill"
        style="color: {status.colorVar}; background: {status.bgTintVar};"
      >
        <span class="status-dot"></span>
        {status.label}
      </span>
    </div>

    <div class="metrics-strip neu-inset">
      <div class="metric-cell">
        <span class="metric-head upload">
          <ArrowUp size={13} />
          Upload
        </span>
        <span class="metric-val tabular-nums">{formatRateKbps(instance.stats.current_upload_rate)}</span>
        <span class="metric-sub tabular-nums">{formatBytes(instance.stats.uploaded)}</span>
      </div>

      <div class="metric-cell">
        <span class="metric-head download">
          <ArrowDown size={13} />
          Download
        </span>
        <span class="metric-val tabular-nums">{formatRateKbps(instance.stats.current_download_rate)}</span>
        <span class="metric-sub tabular-nums">{formatBytes(instance.stats.downloaded)}</span>
      </div>

      <div class="metric-cell right">
        <span class="metric-head">Tỷ lệ / Client</span>
        <span class="metric-val tabular-nums">Ratio {formatRatio(instance.stats.ratio)}</span>
        <span class="metric-sub">{instance.config.client_type} · {formatTargetOsLabel(instance.config.target_os)}</span>
      </div>
    </div>

    {#if instance.stats.tracker_error}
      <div class="error-banner">
        <AlertTriangle size={14} />
        <span>{instance.stats.tracker_error}</span>
      </div>
    {/if}
  </button>

  <div class="card-actions">
    {#if instance.stats.tracker_error}
      <button
        type="button"
        class="btn btn-sm btn-warning action-flex"
        onclick={() => store.startSession(instance)}
      >
        <RotateCw size={15} />
        Thử lại
      </button>
    {:else if isRunning}
      <button
        type="button"
        class="btn btn-sm btn-surface action-flex"
        onclick={() => store.pauseSession(idNum)}
      >
        <Pause size={15} />
        Tạm dừng
      </button>
    {:else if isPaused}
      <button
        type="button"
        class="btn btn-sm btn-primary action-flex"
        onclick={() => store.startSession(instance)}
      >
        <Play size={15} />
        Tiếp tục
      </button>
    {:else}
      <button
        type="button"
        class="btn btn-sm btn-primary action-flex"
        onclick={() => store.startSession(instance)}
      >
        <Play size={15} />
        Bắt đầu
      </button>
    {/if}

    <button
      type="button"
      class="btn btn-sm btn-surface"
      disabled={isStopped}
      onclick={() => store.stopSession(idNum)}
      aria-label="Dừng phiên"
    >
      <Square size={14} />
      Dừng
    </button>

    <button
      type="button"
      class="btn btn-sm btn-surface"
      onclick={() => onOpenDetails(instance.id)}
      aria-label="Mở chẩn đoán và hành động"
    >
      Chi tiết
      <ChevronRight size={15} />
    </button>
  </div>
</article>

<style>
  .session-card {
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .card-main-tap {
    display: flex;
    flex-direction: column;
    gap: 10px;
    text-align: left;
    width: 100%;
    padding: 0;
  }

  .card-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
  }

  .title-col {
    min-width: 0;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .torrent-name {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: var(--text-primary);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    word-break: break-word;
  }

  .meta-line {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    font-size: 12px;
    color: var(--text-secondary);
  }

  .tracker-host {
    font-weight: 600;
    max-width: 170px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .metrics-strip {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px;
    padding: 10px 12px;
  }

  .metric-cell {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }

  .metric-cell.right {
    text-align: right;
    align-items: flex-end;
  }

  .metric-head {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    font-size: 11px;
    font-weight: 700;
    color: var(--text-secondary);
  }

  .metric-head.upload {
    color: var(--upload-color);
  }

  .metric-head.download {
    color: var(--download-color);
  }

  .metric-val {
    font-size: 13px;
    font-weight: 700;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .metric-sub {
    font-size: 11px;
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .error-banner {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 12px;
    font-weight: 600;
  }

  .card-actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .action-flex {
    flex: 1;
  }
</style>
