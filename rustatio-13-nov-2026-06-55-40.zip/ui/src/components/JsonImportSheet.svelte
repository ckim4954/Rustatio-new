<script lang="ts">
  import { FileUp, X } from '@lucide/svelte';
  import { api } from '../lib/api';
  import { store } from '../lib/store.svelte';

  interface Props {
    onClose: () => void;
  }

  let { onClose }: Props = $props();
  let rawJson = $state('');
  let error = $state<string | null>(null);
  let importing = $state(false);

  async function handleFileSelect(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    try {
      rawJson = await file.text();
      error = null;
    } catch (err) {
      error = `Không thể đọc tệp JSON: ${String(err)}`;
    }
  }

  async function handleImport() {
    error = null;
    if (!rawJson.trim()) {
      error = 'Vui lòng dán nội dung JSON Preset hoặc chọn tệp .json.';
      return;
    }
    importing = true;
    try {
      const res = await api.importPresetsJson(rawJson);
      await store.refreshPresets();
      store.pushToast(`Đã nhập thành công ${res.importedCount} Preset.`, 'success');
      onClose();
    } catch (err) {
      error = String(err);
    } finally {
      importing = false;
    }
  }
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label="Nhập Preset JSON"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <h2 class="sheet-title">Nhập JSON Preset</h2>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      <p class="hint">
        Tương thích định dạng JSON từ Rustatio PC (1 preset object, mảng preset hoặc đối tượng
        chứa <code>presets</code>).
      </p>

      <label class="btn btn-surface file-label">
        <FileUp size={17} />
        Chọn tệp .json từ thiết bị
        <input
          type="file"
          accept=".json,application/json"
          class="hidden-file"
          onchange={handleFileSelect}
        />
      </label>

      <div class="field-group">
        <label class="field-label" for="json-input">Nội dung JSON</label>
        <textarea
          id="json-input"
          class="mono"
          bind:value={rawJson}
          placeholder={'{"version": 1, "type": "rustatio-preset", "name": "...", "settings": {...}}'}
        ></textarea>
      </div>

      {#if error}
        <div class="err-box">{error}</div>
      {/if}
    </div>

    <footer class="sheet-footer">
      <button type="button" class="btn btn-surface" onclick={onClose}>Hủy</button>
      <button type="button" class="btn btn-primary" disabled={importing} onclick={handleImport}>
        {importing ? 'Đang nhập...' : 'Nhập Preset'}
      </button>
    </footer>
  </div>
</div>

<style>
  .hint {
    margin: 0;
    font-size: 13px;
    color: var(--text-secondary);
  }

  .file-label {
    position: relative;
    overflow: hidden;
  }

  .hidden-file {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
  }

  .err-box {
    padding: 10px 12px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 13px;
    font-weight: 600;
  }
</style>
