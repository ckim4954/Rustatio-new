<script lang="ts">
  import { Check, Copy, Pencil, Star, Trash2 } from '@lucide/svelte';
  import { formatPostStopAction } from '../lib/format';
  import { store } from '../lib/store.svelte';
  import type { PresetItem } from '../lib/types';

  interface Props {
    preset: PresetItem;
    onEdit: (preset: PresetItem) => void;
  }

  let { preset, onEdit }: Props = $props();
  let confirmDelete = $state(false);

  const s = $derived(preset.settings);
  const stopSummary = $derived.by(() => {
    const parts: string[] = [];
    if (s.stopAtRatioEnabled && s.stopAtRatio != null) parts.push(`Ratio ${s.stopAtRatio}`);
    if (s.stopAtUploadedEnabled && s.stopAtUploadedGb != null) parts.push(`Up ${s.stopAtUploadedGb} GB`);
    if (s.stopAtDownloadedEnabled && s.stopAtDownloadedGb != null)
      parts.push(`Down ${s.stopAtDownloadedGb} GB`);
    if (s.stopAtSeedTimeEnabled && s.stopAtSeedTimeHours != null)
      parts.push(`${s.stopAtSeedTimeHours} giờ`);
    return parts.length > 0 ? parts.join(' · ') : 'Không giới hạn dừng';
  });
</script>

<article class="preset-card neu-card" class:active={preset.isActive}>
  <div class="preset-top">
    <div class="preset-title-col">
      <div class="badges-row">
        <span class="badge">{preset.builtIn ? 'Tích hợp' : 'Tùy chỉnh'}</span>
        {#if preset.isDefault}
          <span class="badge default">Mặc định</span>
        {/if}
        {#if preset.isActive}
          <span class="badge active">Đang áp dụng</span>
        {/if}
      </div>
      <h3>{preset.name}</h3>
      {#if preset.description}
        <p>{preset.description}</p>
      {/if}
    </div>
  </div>

  <!-- Color-grouped parameters -->
  <div class="spec-groups">
    <div class="spec-group green">
      <span class="group-title">Tốc độ & Ngẫu nhiên</span>
      <span class="group-value tabular-nums">
        ↑ {s.uploadRate ?? 50} KB/s · ↓ {s.downloadRate ?? 100} KB/s
        {#if s.randomizeRates}
          (±{s.randomRangePercent ?? 20}%)
        {/if}
      </span>
    </div>

    <div class="spec-group purple">
      <span class="group-title">Điều kiện dừng & Sau dừng</span>
      <span class="group-value tabular-nums">
        {stopSummary} · {formatPostStopAction(s.postStopAction)}
      </span>
    </div>

    <div class="spec-group orange">
      <span class="group-title">Hoàn thành & Hành vi</span>
      <span class="group-value tabular-nums">
        Hoàn thành {s.completionPercent ?? 100}% · Cập nhật {s.updateIntervalSeconds ?? 5}s
        {#if s.idleWhenNoLeechers}
          · Idle không có leecher
        {/if}
      </span>
    </div>
  </div>

  <div class="preset-actions">
    <button
      type="button"
      class="btn btn-sm {preset.isActive ? 'btn-surface' : 'btn-primary'}"
      onclick={() => store.applyPreset(preset.id)}
    >
      <Check size={15} />
      {preset.isActive ? 'Đang dùng' : 'Áp dụng'}
    </button>

    <button
      type="button"
      class="btn btn-sm btn-surface"
      disabled={preset.isDefault}
      onclick={() => store.setDefaultPreset(preset.id)}
    >
      <Star size={15} />
      Đặt mặc định
    </button>

    <button
      type="button"
      class="btn btn-sm btn-surface"
      onclick={() => store.duplicatePreset(preset.id)}
    >
      <Copy size={15} />
      Nhân bản
    </button>

    {#if !preset.builtIn}
      <button
        type="button"
        class="btn btn-sm btn-surface"
        onclick={() => onEdit(preset)}
      >
        <Pencil size={15} />
        Sửa
      </button>

      {#if !confirmDelete}
        <button
          type="button"
          class="btn btn-sm btn-danger"
          onclick={() => (confirmDelete = true)}
        >
          <Trash2 size={15} />
          Xóa
        </button>
      {:else}
        <button
          type="button"
          class="btn btn-sm btn-danger"
          onclick={() => store.deletePreset(preset.id)}
        >
          Xác nhận xóa
        </button>
      {/if}
    {/if}
  </div>
</article>

<style>
  .preset-card {
    padding: 15px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .preset-card.active {
    border-color: var(--accent);
  }

  .preset-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
  }

  .preset-title-col {
    display: flex;
    flex-direction: column;
    gap: 5px;
    min-width: 0;
  }

  .preset-title-col h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
  }

  .preset-title-col p {
    margin: 0;
    font-size: 13px;
    color: var(--text-secondary);
  }

  .badges-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .badge {
    font-size: 11px;
    font-weight: 700;
    padding: 3px 9px;
    border-radius: var(--radius-pill);
    background: var(--bg-inset);
    color: var(--text-secondary);
  }

  .badge.default {
    background: var(--tint-purple);
    color: var(--text-primary);
  }

  .badge.active {
    background: var(--tint-green);
    color: var(--accent-text);
  }

  .spec-groups {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .spec-group {
    padding: 9px 12px;
    border-radius: var(--radius-sm);
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .spec-group.green {
    background: var(--tint-green);
  }

  .spec-group.purple {
    background: var(--tint-purple);
  }

  .spec-group.orange {
    background: var(--tint-orange);
  }

  .group-title {
    font-size: 11px;
    font-weight: 700;
    color: var(--text-secondary);
  }

  .group-value {
    font-size: 13px;
    font-weight: 700;
    color: var(--text-primary);
  }

  .preset-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
</style>
