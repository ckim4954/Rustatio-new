<script lang="ts">
  import { AlertCircle, CheckCircle2, Info } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';
</script>

{#if store.toasts.length > 0}
  <div class="toast-stack" role="status" aria-live="polite">
    {#each store.toasts as toast (toast.id)}
      <div class="toast-item neu-card-sm {toast.kind}">
        {#if toast.kind === 'success'}
          <CheckCircle2 size={18} />
        {:else if toast.kind === 'error'}
          <AlertCircle size={18} />
        {:else}
          <Info size={18} />
        {/if}
        <span class="toast-text">{toast.text}</span>
      </div>
    {/each}
  </div>
{/if}

<style>
  .toast-stack {
    position: fixed;
    left: 14px;
    right: 14px;
    bottom: calc(var(--nav-height) + var(--safe-bottom) + 12px);
    z-index: 80;
    display: flex;
    flex-direction: column;
    gap: 8px;
    pointer-events: none;
  }

  .toast-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 14px;
    font-size: 13px;
    font-weight: 600;
    pointer-events: auto;
  }

  .toast-item.success {
    background: var(--tint-green);
    color: var(--accent-text);
  }

  .toast-item.error {
    background: var(--tint-red);
    color: var(--error-color);
  }

  .toast-item.info {
    background: var(--bg-elevated);
    color: var(--text-primary);
  }

  .toast-text {
    flex: 1;
    word-break: break-word;
  }
</style>
