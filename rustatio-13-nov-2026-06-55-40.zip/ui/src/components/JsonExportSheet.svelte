<script lang="ts">
  import { Copy, Download, Share2, X } from '@lucide/svelte';
  import { onMount } from 'svelte';
  import { api } from '../lib/api';
  import { store } from '../lib/store.svelte';

  interface Props {
    onClose: () => void;
  }

  let { onClose }: Props = $props();
  let selectedId = $state<string>('');
  let jsonPreview = $state('');
  let loading = $state(true);
  let error = $state<string | null>(null);

  async function refreshPreview() {
    loading = true;
    error = null;
    try {
      jsonPreview = await api.exportPresetsJson(selectedId || null);
    } catch (err) {
      error = String(err);
    } finally {
      loading = false;
    }
  }

  onMount(() => {
    void refreshPreview();
  });

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(jsonPreview);
      store.pushToast('Đã sao chép JSON vào clipboard.', 'success');
    } catch (err) {
      store.pushToast(`Không thể sao chép: ${String(err)}`, 'error');
    }
  }

  async function handleAndroidShareOrSave(mode: 'share' | 'save') {
    const filename = selectedId ? `rustatio-preset-${selectedId}.json` : 'rustatio-presets.json';
    try {
      const res = await api.shareOrSaveJson(filename, jsonPreview, mode);
      store.pushToast(res.message, res.success ? 'success' : 'info');
    } catch (err) {
      store.pushToast(String(err), 'error');
    }
  }
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label="Xuất JSON Preset"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <h2 class="sheet-title">Xuất JSON Preset</h2>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      <div class="field-group">
        <label class="field-label" for="export-scope">Phạm vi xuất</label>
        <select
          id="export-scope"
          bind:value={selectedId}
          onchange={() => refreshPreview()}
        >
          <option value="">Tất cả Preset tùy chỉnh (hoặc toàn bộ nếu chưa tạo)</option>
          {#each store.presets as item (item.id)}
            <option value={item.id}>{item.name}</option>
          {/each}
        </select>
      </div>

      {#if error}
        <div class="err-box">{error}</div>
      {:else}
        <textarea
          class="mono preview-area"
          readonly
          value={loading ? 'Đang tạo JSON...' : jsonPreview}
        ></textarea>
      {/if}
    </div>

    <footer class="sheet-footer wrap-footer">
      <button type="button" class="btn btn-surface" disabled={!jsonPreview} onclick={handleCopy}>
        <Copy size={16} />
        Sao chép
      </button>
      <button
        type="button"
        class="btn btn-surface"
        disabled={!jsonPreview}
        onclick={() => handleAndroidShareOrSave('save')}
      >
        <Download size={16} />
        Lưu tệp
      </button>
      <button
        type="button"
        class="btn btn-primary"
        disabled={!jsonPreview}
        onclick={() => handleAndroidShareOrSave('share')}
      >
        <Share2 size={16} />
        Chia sẻ
      </button>
    </footer>
  </div>
</div>

<style>
  .preview-area {
    min-height: 220px;
    font-size: 12px;
  }

  .err-box {
    padding: 10px 12px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 13px;
    font-weight: 600;
  }

  .wrap-footer {
    flex-wrap: wrap;
  }
</style>
