<script lang="ts">
  import {
    ArrowDown,
    ArrowUp,
    BellRing,
    FileUp,
    Pause,
    Play,
    Plus,
    Search,
    Square,
    X,
  } from '@lucide/svelte';
  import { formatBytes, formatRateKbps } from '../lib/format';
  import { STATUS_FILTER_CHIPS } from '../lib/status';
  import { store } from '../lib/store.svelte';
  import SessionCard from './SessionCard.svelte';
  import SessionDetailsSheet from './SessionDetailsSheet.svelte';

  const needsNotificationPrompt = $derived(
    store.foregroundStatus != null &&
      store.foregroundStatus.sdkInt >= 33 &&
      !store.foregroundStatus.notificationGranted &&
      store.instances.length > 0,
  );
</script>

<section class="sessions-page">
  <!-- Compact Header -->
  <header class="page-header">
    <div>
      <h1 class="page-title">Quản lý phiên</h1>
      <p class="page-sub tabular-nums">
        {store.activeSessionCount} đang chạy · {store.instances.length} phiên
      </p>
    </div>

    <button
      type="button"
      class="btn btn-primary"
      disabled={store.busyAction === 'pick-torrent'}
      onclick={() => store.addSessionFromAndroidPicker()}
    >
      <Plus size={18} />
      {store.busyAction === 'pick-torrent' ? 'Đang mở...' : 'Thêm phiên'}
    </button>
  </header>

  {#if needsNotificationPrompt}
    <div class="notif-banner neu-card-sm">
      <div class="notif-copy">
        <BellRing size={18} />
        <span>Cấp quyền thông báo để giữ phiên chạy nền ổn định trên Android.</span>
      </div>
      <button
        type="button"
        class="btn btn-sm btn-primary"
        onclick={() => store.requestNotificationPermission()}
      >
        Cho phép
      </button>
    </div>
  {/if}

  <!-- Slim Total Summary Bar -->
  <div class="summary-bar neu-card">
    <div class="summary-side">
      <span class="sum-label upload">
        <ArrowUp size={15} />
        Tổng Upload
      </span>
      <div class="sum-values">
        <strong class="tabular-nums">{formatRateKbps(store.totalUploadRateKbps)}</strong>
        <span class="tabular-nums">{formatBytes(store.totalUploadedBytes)}</span>
      </div>
    </div>

    <div class="summary-divider"></div>

    <div class="summary-side right">
      <span class="sum-label download">
        <ArrowDown size={15} />
        Tổng Download
      </span>
      <div class="sum-values">
        <strong class="tabular-nums">{formatRateKbps(store.totalDownloadRateKbps)}</strong>
        <span class="tabular-nums">{formatBytes(store.totalDownloadedBytes)}</span>
      </div>
    </div>
  </div>

  <!-- Bulk Action Bar -->
  <div class="bulk-bar">
    <button
      type="button"
      class="btn btn-sm btn-surface"
      disabled={store.instances.length === 0 || store.busyAction === 'bulk-start'}
      onclick={() => store.bulkStart()}
    >
      <Play size={15} />
      Chạy hết
    </button>
    <button
      type="button"
      class="btn btn-sm btn-surface"
      disabled={store.activeSessionCount === 0 || store.busyAction === 'bulk-pause'}
      onclick={() => store.bulkPause()}
    >
      <Pause size={15} />
      Tạm dừng
    </button>
    <button
      type="button"
      class="btn btn-sm btn-surface"
      disabled={store.instances.length === 0 || store.busyAction === 'bulk-stop'}
      onclick={() => store.bulkStop()}
    >
      <Square size={15} />
      Dừng hết
    </button>
  </div>

  <!-- Single-line Search -->
  <div class="search-box">
    <Search size={17} class="search-icon" />
    <input
      type="text"
      bind:value={store.searchQuery}
      placeholder="Tìm theo tên, tracker hoặc info hash..."
      aria-label="Tìm kiếm phiên"
    />
    {#if store.searchQuery}
      <button
        type="button"
        class="clear-btn"
        aria-label="Xóa từ khóa tìm kiếm"
        onclick={() => (store.searchQuery = '')}
      >
        <X size={16} />
      </button>
    {/if}
  </div>

  <!-- Horizontal Status Filter Chips -->
  <div class="chip-scroll" role="tablist" aria-label="Lọc trạng thái phiên">
    {#each STATUS_FILTER_CHIPS as chip (chip.key)}
      {@const selected = store.statusFilter === chip.key}
      <button
        type="button"
        role="tab"
        aria-selected={selected}
        class="filter-chip"
        class:selected
        onclick={() => (store.statusFilter = chip.key)}
      >
        {chip.label}
      </button>
    {/each}
  </div>

  <!-- Session List / Empty States -->
  {#if store.instances.length === 0}
    <div class="empty-state neu-card">
      <div class="empty-icon">
        <FileUp size={28} />
      </div>
      <h2>Chưa có phiên nào</h2>
      <p>Chọn tệp .torrent từ bộ nhớ thiết bị để tạo phiên tracker thực tế.</p>
      <button
        type="button"
        class="btn btn-primary"
        onclick={() => store.addSessionFromAndroidPicker()}
      >
        <Plus size={18} />
        Chọn tệp .torrent
      </button>
    </div>
  {:else if store.filteredInstances.length === 0}
    <div class="empty-state neu-card">
      <h2>Không tìm thấy phiên phù hợp</h2>
      <p>Thử thay đổi bộ lọc trạng thái hoặc từ khóa tìm kiếm.</p>
      <button
        type="button"
        class="btn btn-surface"
        onclick={() => {
          store.searchQuery = '';
          store.statusFilter = 'all';
        }}
      >
        Đặt lại bộ lọc
      </button>
    </div>
  {:else}
    <div class="cards-list">
      {#each store.filteredInstances as item (item.id)}
        <SessionCard
          instance={item}
          onOpenDetails={(id) => (store.selectedInstanceId = id)}
        />
      {/each}
    </div>
  {/if}
</section>

{#if store.selectedInstance}
  <SessionDetailsSheet
    instance={store.selectedInstance}
    onClose={() => (store.selectedInstanceId = null)}
  />
{/if}

<style>
  .sessions-page {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .page-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.02em;
  }

  .page-sub {
    margin: 2px 0 0;
    font-size: 13px;
    color: var(--text-secondary);
    font-weight: 600;
  }

  .notif-banner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 10px 12px;
    background: var(--tint-orange);
    color: var(--text-primary);
  }

  .notif-copy {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 600;
    flex: 1;
  }

  .summary-bar {
    display: flex;
    align-items: center;
    padding: 12px 14px;
    gap: 12px;
  }

  .summary-side {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  .summary-side.right {
    align-items: flex-end;
    text-align: right;
  }

  .summary-divider {
    width: 1px;
    height: 36px;
    background: var(--border-subtle);
  }

  .sum-label {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    font-weight: 700;
  }

  .sum-label.upload {
    color: var(--upload-color);
  }

  .sum-label.download {
    color: var(--download-color);
  }

  .sum-values {
    display: flex;
    align-items: baseline;
    gap: 8px;
    flex-wrap: wrap;
  }

  .sum-values strong {
    font-size: 16px;
    font-weight: 800;
  }

  .sum-values span {
    font-size: 12px;
    color: var(--text-secondary);
    font-weight: 600;
  }

  .bulk-bar {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px;
  }

  .search-box {
    position: relative;
    display: flex;
    align-items: center;
  }

  .search-box :global(.search-icon) {
    position: absolute;
    left: 14px;
    color: var(--text-secondary);
    pointer-events: none;
  }

  .search-box input {
    padding-left: 40px;
    padding-right: 42px;
  }

  .clear-btn {
    position: absolute;
    right: 6px;
    width: 36px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: var(--text-secondary);
  }

  .chip-scroll {
    display: flex;
    align-items: center;
    gap: 8px;
    overflow-x: auto;
    padding: 2px 2px 6px;
    scrollbar-width: none;
  }

  .chip-scroll::-webkit-scrollbar {
    display: none;
  }

  .filter-chip {
    flex-shrink: 0;
    min-height: 38px;
    padding: 0 14px;
    border-radius: var(--radius-pill);
    background: var(--bg-surface);
    border: 1px solid var(--border-subtle);
    box-shadow: var(--neu-shadow-sm);
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    white-space: nowrap;
  }

  .filter-chip.selected {
    background: var(--tint-green);
    color: var(--accent-text);
    border-color: var(--accent);
  }

  .cards-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .empty-state {
    padding: 28px 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 10px;
  }

  .empty-icon {
    width: 56px;
    height: 56px;
    border-radius: 18px;
    background: var(--tint-green);
    color: var(--accent-text);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 4px;
  }

  .empty-state h2 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
  }

  .empty-state p {
    margin: 0 0 6px;
    font-size: 13px;
    color: var(--text-secondary);
    max-width: 280px;
  }
</style>
