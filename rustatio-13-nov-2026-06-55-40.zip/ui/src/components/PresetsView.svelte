<script lang="ts">
  import { Download, Plus, Upload } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';
  import type { PresetItem } from '../lib/types';
  import JsonExportSheet from './JsonExportSheet.svelte';
  import JsonImportSheet from './JsonImportSheet.svelte';
  import PresetCard from './PresetCard.svelte';
  import PresetEditorSheet from './PresetEditorSheet.svelte';

  let editorOpen = $state(false);
  let editingPreset = $state<PresetItem | null>(null);
  let importOpen = $state(false);
  let exportOpen = $state(false);

  function openCreate() {
    editingPreset = null;
    editorOpen = true;
  }

  function openEdit(preset: PresetItem) {
    editingPreset = preset;
    editorOpen = true;
  }
</script>

<section class="presets-page">
  <header class="page-header">
    <div>
      <h1 class="page-title">Quản lý Preset</h1>
      <p class="page-sub">
        {store.presets.length} cấu hình sẵn dùng & tùy chỉnh
      </p>
    </div>
  </header>

  <div class="preset-toolbar">
    <button type="button" class="btn btn-primary" onclick={openCreate}>
      <Plus size={17} />
      Tạo Preset mới
    </button>
    <button type="button" class="btn btn-surface" onclick={() => (importOpen = true)}>
      <Upload size={16} />
      Nhập JSON
    </button>
    <button type="button" class="btn btn-surface" onclick={() => (exportOpen = true)}>
      <Download size={16} />
      Xuất JSON
    </button>
  </div>

  <div class="preset-list">
    {#each store.presets as item (item.id)}
      <PresetCard preset={item} onEdit={openEdit} />
    {/each}
  </div>
</section>

{#if editorOpen}
  <PresetEditorSheet preset={editingPreset} onClose={() => (editorOpen = false)} />
{/if}

{#if importOpen}
  <JsonImportSheet onClose={() => (importOpen = false)} />
{/if}

{#if exportOpen}
  <JsonExportSheet onClose={() => (exportOpen = false)} />
{/if}

<style>
  .presets-page {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }

  .page-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.02em;
  }

  .page-sub {
    margin: 2px 0 0;
    font-size: 13px;
    color: var(--text-secondary);
    font-weight: 600;
  }

  .preset-toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .preset-toolbar > .btn-primary {
    flex: 1 1 100%;
  }

  .preset-toolbar > .btn-surface {
    flex: 1;
  }

  .preset-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
</style>
