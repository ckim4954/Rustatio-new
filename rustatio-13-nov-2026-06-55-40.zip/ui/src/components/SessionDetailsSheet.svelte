<script lang="ts">
  import {
    Pause,
    Play,
    Radio,
    RotateCw,
    Square,
    Trash2,
    X,
  } from '@lucide/svelte';
  import {
    formatBytes,
    formatCountdownMs,
    formatDurationSeconds,
    formatInfoHashHex,
    formatRateKbps,
    formatRatio,
    formatTargetOsLabel,
    formatTimestampMs,
    formatWireDuration,
  } from '../lib/format';
  import { resolveSessionStatus } from '../lib/status';
  import { store } from '../lib/store.svelte';
  import type { InstanceInfo } from '../lib/types';

  interface Props {
    instance: InstanceInfo;
    onClose: () => void;
  }

  let { instance, onClose }: Props = $props();
  let confirmDelete = $state(false);

  const idNum = $derived(Number(instance.id));
  const status = $derived(resolveSessionStatus(instance, store.nowMs));
  const fullHash = $derived(formatInfoHashHex(instance.torrent.info_hash));
  const hasAnnounced = $derived(
    instance.stats.last_announce_at_ms != null || instance.stats.announce_count > 0,
  );
  const isRunning = $derived(
    instance.stats.state === 'Running' || instance.stats.state === 'Starting',
  );
  const isPaused = $derived(instance.stats.state === 'Paused');
  const isStopped = $derived(instance.stats.state === 'Stopped');
  const isAnnouncing = $derived(store.busyAction === `announce-${idNum}`);
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label="Chi tiết phiên"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <div class="header-text">
        <h2 class="sheet-title">{instance.torrent.name}</h2>
        <span
          class="status-pill"
          style="color: {status.colorVar}; background: {status.bgTintVar};"
        >
          <span class="status-dot"></span>
          {status.label}
        </span>
      </div>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      <!-- Tracker Diagnostics -->
      <section class="neu-inset block">
        <p class="section-label">Chẩn đoán Tracker</p>
        <div class="kv-grid">
          <div class="kv-row">
            <span class="kv-key">HTTP / Trạng thái</span>
            <span class="kv-val tabular-nums">
              {instance.stats.last_http_status != null
                ? `HTTP ${instance.stats.last_http_status}`
                : 'Chưa có dữ liệu'}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Số lần Announce</span>
            <span class="kv-val tabular-nums">{instance.stats.announce_count}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Chu kỳ Announce</span>
            <span class="kv-val tabular-nums">
              {instance.stats.announce_interval_secs != null
                ? formatDurationSeconds(instance.stats.announce_interval_secs)
                : 'Chưa có dữ liệu'}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Seeders / Leechers</span>
            <span class="kv-val tabular-nums">
              {hasAnnounced
                ? `${instance.stats.seeders} / ${instance.stats.leechers}`
                : 'Chưa có dữ liệu'}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Peers phản hồi</span>
            <span class="kv-val tabular-nums">
              {instance.stats.peers_count != null
                ? `${instance.stats.peers_count} peers`
                : 'Chưa có dữ liệu'}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Lần announce cuối</span>
            <span class="kv-val tabular-nums">
              {formatTimestampMs(instance.stats.last_announce_at_ms)}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Announce tiếp theo</span>
            <span class="kv-val tabular-nums">
              {isRunning
                ? formatCountdownMs(instance.stats.next_announce_at_ms, store.nowMs)
                : 'Chưa có dữ liệu'}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Lỗi gần nhất</span>
            <span class="kv-val" class:err={Boolean(instance.stats.tracker_error)}>
              {instance.stats.tracker_error ?? 'Không có lỗi'}
            </span>
          </div>
        </div>
      </section>

      <!-- Client Identity -->
      <section class="neu-inset block">
        <p class="section-label">Định danh Client giả lập</p>
        <div class="kv-grid">
          <div class="kv-row">
            <span class="kv-key">Client / Phiên bản</span>
            <span class="kv-val">
              {instance.config.client_type}
              {instance.config.client_version ? ` ${instance.config.client_version}` : ''}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Target OS</span>
            <span class="kv-val">{formatTargetOsLabel(instance.stats.target_os)}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Announce Port</span>
            <span class="kv-val tabular-nums">{instance.config.port}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Peer ID</span>
            <span class="kv-val mono">{instance.stats.peer_id || 'Chưa khởi tạo'}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Key</span>
            <span class="kv-val mono">{instance.stats.key || 'Chưa khởi tạo'}</span>
          </div>
          <div class="kv-row full">
            <span class="kv-key">User-Agent</span>
            <span class="kv-val mono wrap">{instance.stats.user_agent || 'Chưa có dữ liệu'}</span>
          </div>
        </div>
      </section>

      <!-- Session Stats -->
      <section class="neu-inset block">
        <p class="section-label">Thông tin & Thống kê phiên</p>
        <div class="kv-grid">
          <div class="kv-row">
            <span class="kv-key">Tổng Upload</span>
            <span class="kv-val tabular-nums upload">{formatBytes(instance.stats.uploaded)}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Tổng Download</span>
            <span class="kv-val tabular-nums download">{formatBytes(instance.stats.downloaded)}</span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Tốc độ hiện tại</span>
            <span class="kv-val tabular-nums">
              ↑ {formatRateKbps(instance.stats.current_upload_rate)} · ↓{' '}
              {formatRateKbps(instance.stats.current_download_rate)}
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Tỷ lệ / Hoàn thành</span>
            <span class="kv-val tabular-nums">
              Ratio {formatRatio(instance.stats.ratio)} ·{' '}
              {instance.stats.torrent_completion.toFixed(1)}%
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">Dung lượng / Thời gian</span>
            <span class="kv-val tabular-nums">
              {formatBytes(instance.torrent.total_size)} ·{' '}
              {formatWireDuration(instance.stats.elapsed_time)}
            </span>
          </div>
          <div class="kv-row full">
            <span class="kv-key">Tracker URL</span>
            <span class="kv-val mono wrap">{instance.torrent.announce}</span>
          </div>
          <div class="kv-row full">
            <span class="kv-key">Info Hash</span>
            <span class="kv-val mono wrap">{fullHash}</span>
          </div>
        </div>
      </section>

      <!-- Actions -->
      <section class="actions-block">
        <p class="section-label">Hành động</p>
        <div class="actions-grid">
          <button
            type="button"
            class="btn btn-surface"
            disabled={!isRunning || isAnnouncing}
            onclick={() => store.announceNow(idNum)}
          >
            <Radio size={17} />
            {isAnnouncing ? 'Đang gửi...' : 'Announce ngay'}
          </button>

          {#if instance.stats.tracker_error}
            <button
              type="button"
              class="btn btn-warning"
              onclick={() => store.startSession(instance)}
            >
              <RotateCw size={17} />
              Thử lại tracker
            </button>
          {:else if isRunning}
            <button
              type="button"
              class="btn btn-surface"
              onclick={() => store.pauseSession(idNum)}
            >
              <Pause size={17} />
              Tạm dừng
            </button>
          {:else if isPaused}
            <button
              type="button"
              class="btn btn-primary"
              onclick={() => store.startSession(instance)}
            >
              <Play size={17} />
              Tiếp tục
            </button>
          {:else}
            <button
              type="button"
              class="btn btn-primary"
              onclick={() => store.startSession(instance)}
            >
              <Play size={17} />
              Bắt đầu
            </button>
          {/if}

          <button
            type="button"
            class="btn btn-surface"
            disabled={isStopped}
            onclick={() => store.stopSession(idNum)}
          >
            <Square size={17} />
            Dừng
          </button>

          {#if !confirmDelete}
            <button
              type="button"
              class="btn btn-danger"
              onclick={() => (confirmDelete = true)}
            >
              <Trash2 size={17} />
              Xóa phiên
            </button>
          {:else}
            <button
              type="button"
              class="btn btn-danger"
              onclick={() => store.deleteSession(idNum)}
            >
              <Trash2 size={17} />
              Xác nhận xóa
            </button>
          {/if}
        </div>
      </section>
    </div>
  </div>
</div>

<style>
  .header-text {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 6px;
    min-width: 0;
    flex: 1;
  }

  .header-text .sheet-title {
    font-size: 16px;
    word-break: break-word;
  }

  .block {
    padding: 14px;
  }

  .kv-grid {
    display: flex;
    flex-direction: column;
    gap: 9px;
  }

  .kv-row {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    font-size: 13px;
  }

  .kv-row.full {
    flex-direction: column;
    gap: 3px;
  }

  .kv-key {
    color: var(--text-secondary);
    font-weight: 600;
    flex-shrink: 0;
  }

  .kv-val {
    color: var(--text-primary);
    font-weight: 600;
    text-align: right;
  }

  .kv-row.full .kv-val {
    text-align: left;
  }

  .kv-val.wrap {
    word-break: break-all;
    font-size: 12px;
  }

  .kv-val.err {
    color: var(--error-color);
  }

  .kv-val.upload {
    color: var(--upload-color);
  }

  .kv-val.download {
    color: var(--download-color);
  }

  .actions-block {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .actions-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
  }
</style>
