<script lang="ts">
  import {
    BellRing,
    ChevronRight,
    MonitorSmartphone,
    Moon,
    Router,
    SlidersHorizontal,
    Sun,
  } from '@lucide/svelte';
  import { formatTargetOsLabel } from '../lib/format';
  import { store } from '../lib/store.svelte';
  import ClientOsSheet from './ClientOsSheet.svelte';
  import PortConfigSheet from './PortConfigSheet.svelte';

  let clientSheetOpen = $state(false);
  let portSheetOpen = $state(false);

  const clientDisplay = $derived.by(() => {
    const id = store.config?.client.default_type ?? 'qbittorrent';
    const found = store.clientInfos.find((c) => c.id === id);
    const ver = store.config?.client.default_version ?? found?.default_version ?? '';
    return `${found?.name ?? id} ${ver}`.trim();
  });

  const osDisplay = $derived(formatTargetOsLabel(store.config?.client.target_os));
</script>

<section class="settings-page">
  <header class="page-header">
    <h1 class="page-title">Cài đặt</h1>
    <p class="page-sub">Tùy chỉnh giao diện, định danh Client & cổng mạng</p>
  </header>

  <!-- Group A: Theme (Light Mint / Deep Forest) -->
  <article class="settings-card neu-card">
    <div class="card-row">
      <div class="icon-badge theme">
        {#if store.darkMode}
          <Moon size={20} />
        {:else}
          <Sun size={20} />
        {/if}
      </div>
      <div class="card-copy">
        <h2>Giao diện</h2>
        <p>{store.darkMode ? 'Deep Forest (Tối)' : 'Light Mint (Sáng)'}</p>
      </div>
      <button
        type="button"
        class="switch"
        class:checked={store.darkMode}
        aria-pressed={store.darkMode}
        aria-label="Chuyển đổi giao diện sáng/tối"
        onclick={() => store.toggleTheme()}
      >
        <span class="switch-thumb"></span>
      </button>
    </div>
  </article>

  <!-- Group B: Client / Version / Target OS -->
  <button
    type="button"
    class="settings-card neu-card clickable"
    onclick={() => (clientSheetOpen = true)}
  >
    <div class="card-row">
      <div class="icon-badge client">
        <MonitorSmartphone size={20} />
      </div>
      <div class="card-copy">
        <h2>Client giả lập & Target OS</h2>
        <p>{clientDisplay} · {osDisplay}</p>
      </div>
      <ChevronRight size={20} class="chev" />
    </div>
  </button>

  <!-- Group C: Port Configuration -->
  <button
    type="button"
    class="settings-card neu-card clickable"
    onclick={() => (portSheetOpen = true)}
  >
    <div class="card-row">
      <div class="icon-badge port">
        <Router size={20} />
      </div>
      <div class="card-copy">
        <h2>Cấu hình Cổng (Port)</h2>
        <p class="tabular-nums">
          Announce: {store.config?.client.default_port ?? 6881} · Listening:{' '}
          {store.config?.client.listening_enabled
            ? store.config?.client.listening_port
            : 'Đang tắt'}
        </p>
      </div>
      <ChevronRight size={20} class="chev" />
    </div>
  </button>

  <!-- Group D: Preset Management Navigation -->
  <button
    type="button"
    class="settings-card neu-card clickable"
    onclick={() => (store.activeTab = 'presets')}
  >
    <div class="card-row">
      <div class="icon-badge preset">
        <SlidersHorizontal size={20} />
      </div>
      <div class="card-copy">
        <h2>Quản lý Preset</h2>
        <p>{store.presets.length} cấu hình · Mở màn hình Preset</p>
      </div>
      <ChevronRight size={20} class="chev" />
    </div>
  </button>

  <!-- Android Foreground Service Status -->
  {#if store.foregroundStatus}
    <article class="settings-card neu-inset fg-card">
      <div class="card-row">
        <div class="icon-badge fg">
          <BellRing size={19} />
        </div>
        <div class="card-copy">
          <h2>Dịch vụ chạy nền Android</h2>
          <p class="tabular-nums">
            {#if store.foregroundStatus.isRunning}
              Đang hoạt động ({store.foregroundStatus.activeSessions} phiên)
            {:else}
              Sẵn sàng (tự kích hoạt khi có phiên chạy)
            {/if}
          </p>
        </div>
        {#if store.foregroundStatus.sdkInt >= 33 && !store.foregroundStatus.notificationGranted}
          <button
            type="button"
            class="btn btn-sm btn-primary"
            onclick={() => store.requestNotificationPermission()}
          >
            Cấp quyền
          </button>
        {/if}
      </div>
    </article>
  {/if}
</section>

{#if clientSheetOpen}
  <ClientOsSheet onClose={() => (clientSheetOpen = false)} />
{/if}

{#if portSheetOpen}
  <PortConfigSheet onClose={() => (portSheetOpen = false)} />
{/if}

<style>
  .settings-page {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }

  .page-header {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.02em;
  }

  .page-sub {
    margin: 0;
    font-size: 13px;
    color: var(--text-secondary);
    font-weight: 600;
  }

  .settings-card {
    width: 100%;
    padding: 15px;
    text-align: left;
  }

  .settings-card.clickable:active {
    transform: scale(0.985);
  }

  .card-row {
    display: flex;
    align-items: center;
    gap: 13px;
  }

  .icon-badge {
    width: 44px;
    height: 44px;
    border-radius: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }

  .icon-badge.theme {
    background: var(--tint-purple);
    color: var(--text-primary);
  }

  .icon-badge.client {
    background: var(--tint-green);
    color: var(--accent-text);
  }

  .icon-badge.port {
    background: var(--tint-orange);
    color: var(--warning-color);
  }

  .icon-badge.preset {
    background: var(--tint-blue);
    color: var(--download-color);
  }

  .icon-badge.fg {
    background: var(--bg-surface);
    color: var(--accent-text);
  }

  .card-copy {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .card-copy h2 {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
  }

  .card-copy p {
    margin: 0;
    font-size: 13px;
    color: var(--text-secondary);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .card-row :global(.chev) {
    color: var(--text-secondary);
    flex-shrink: 0;
  }

  .fg-card {
    margin-top: 4px;
  }
</style>
