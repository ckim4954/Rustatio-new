<script lang="ts">
  import { untrack } from 'svelte';
  import { X } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';
  import type { PostStopAction, PresetItem, PresetSettings } from '../lib/types';

  interface Props {
    preset: PresetItem | null;
    onClose: () => void;
  }

  let { preset, onClose }: Props = $props();

  const seed = untrack(() => preset);
  const initial = seed?.settings;

  let name = $state(seed?.name ?? '');
  let description = $state(seed?.description ?? '');
  let icon = $state(seed?.icon ?? 'sliders');

  let uploadRate = $state(initial?.uploadRate ?? 50);
  let downloadRate = $state(initial?.downloadRate ?? 100);
  let completionPercent = $state(initial?.completionPercent ?? 100);
  let updateIntervalSeconds = $state(initial?.updateIntervalSeconds ?? 5);

  let randomizeRates = $state(initial?.randomizeRates ?? true);
  let randomRangePercent = $state(initial?.randomRangePercent ?? 20);

  let stopAtRatioEnabled = $state(initial?.stopAtRatioEnabled ?? false);
  let stopAtRatio = $state(initial?.stopAtRatio ?? 2.0);
  let randomizeRatio = $state(initial?.randomizeRatio ?? false);
  let randomRatioRangePercent = $state(initial?.randomRatioRangePercent ?? 10);

  let stopAtUploadedEnabled = $state(initial?.stopAtUploadedEnabled ?? false);
  let stopAtUploadedGb = $state(initial?.stopAtUploadedGb ?? 10);
  let stopAtDownloadedEnabled = $state(initial?.stopAtDownloadedEnabled ?? false);
  let stopAtDownloadedGb = $state(initial?.stopAtDownloadedGb ?? 10);
  let stopAtSeedTimeEnabled = $state(initial?.stopAtSeedTimeEnabled ?? false);
  let stopAtSeedTimeHours = $state(initial?.stopAtSeedTimeHours ?? 24);

  let postStopAction = $state<PostStopAction>(initial?.postStopAction ?? 'idle');
  let idleWhenNoLeechers = $state(initial?.idleWhenNoLeechers ?? false);
  let idleWhenNoSeeders = $state(initial?.idleWhenNoSeeders ?? false);

  let progressiveRatesEnabled = $state(initial?.progressiveRatesEnabled ?? false);
  let targetUploadRate = $state(initial?.targetUploadRate ?? 200);
  let targetDownloadRate = $state(initial?.targetDownloadRate ?? 50);
  let progressiveDurationHours = $state(initial?.progressiveDurationHours ?? 1);

  let errors = $state<Record<string, string>>({});
  let saving = $state(false);
  let serverError = $state<string | null>(null);

  function validate(): boolean {
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = 'Tên Preset không được để trống.';
    if (!Number.isFinite(uploadRate) || uploadRate < 0)
      next.uploadRate = 'Tốc độ Upload phải ≥ 0 KB/s.';
    if (!Number.isFinite(downloadRate) || downloadRate < 0)
      next.downloadRate = 'Tốc độ Download phải ≥ 0 KB/s.';
    if (!Number.isFinite(completionPercent) || completionPercent < 0 || completionPercent > 100)
      next.completionPercent = 'Hoàn thành phải nằm trong 0% – 100%.';
    if (!Number.isFinite(updateIntervalSeconds) || updateIntervalSeconds < 1)
      next.updateIntervalSeconds = 'Chu kỳ cập nhật phải ≥ 1 giây.';
    if (randomizeRates && (!Number.isFinite(randomRangePercent) || randomRangePercent < 0 || randomRangePercent > 100))
      next.randomRangePercent = 'Biên độ ngẫu nhiên phải trong 0% – 100%.';
    if (stopAtRatioEnabled && (!Number.isFinite(stopAtRatio) || stopAtRatio <= 0))
      next.stopAtRatio = 'Tỷ lệ dừng phải lớn hơn 0.';
    if (stopAtUploadedEnabled && (!Number.isFinite(stopAtUploadedGb) || stopAtUploadedGb <= 0))
      next.stopAtUploadedGb = 'Giới hạn Upload (GB) phải lớn hơn 0.';
    if (stopAtDownloadedEnabled && (!Number.isFinite(stopAtDownloadedGb) || stopAtDownloadedGb <= 0))
      next.stopAtDownloadedGb = 'Giới hạn Download (GB) phải lớn hơn 0.';
    if (stopAtSeedTimeEnabled && (!Number.isFinite(stopAtSeedTimeHours) || stopAtSeedTimeHours <= 0))
      next.stopAtSeedTimeHours = 'Thời gian Seed phải lớn hơn 0 giờ.';
    errors = next;
    return Object.keys(next).length === 0;
  }

  async function handleSave() {
    serverError = null;
    if (!validate()) return;

    const settings: PresetSettings = {
      uploadRate: Number(uploadRate),
      downloadRate: Number(downloadRate),
      completionPercent: Number(completionPercent),
      updateIntervalSeconds: Math.round(Number(updateIntervalSeconds)),
      randomizeRates,
      randomRangePercent: Number(randomRangePercent),
      randomizeRatio,
      randomRatioRangePercent: Number(randomRatioRangePercent),
      stopAtRatioEnabled,
      stopAtRatio: stopAtRatioEnabled ? Number(stopAtRatio) : null,
      stopAtUploadedEnabled,
      stopAtUploadedGb: stopAtUploadedEnabled ? Number(stopAtUploadedGb) : null,
      stopAtDownloadedEnabled,
      stopAtDownloadedGb: stopAtDownloadedEnabled ? Number(stopAtDownloadedGb) : null,
      stopAtSeedTimeEnabled,
      stopAtSeedTimeHours: stopAtSeedTimeEnabled ? Number(stopAtSeedTimeHours) : null,
      postStopAction,
      idleWhenNoLeechers,
      idleWhenNoSeeders,
      progressiveRatesEnabled,
      targetUploadRate: progressiveRatesEnabled ? Number(targetUploadRate) : null,
      targetDownloadRate: progressiveRatesEnabled ? Number(targetDownloadRate) : null,
      progressiveDurationHours: progressiveRatesEnabled ? Number(progressiveDurationHours) : null,
    };

    saving = true;
    try {
      await store.savePreset({
        id: preset?.id ?? null,
        name: name.trim(),
        description: description.trim(),
        icon,
        settings,
      });
      onClose();
    } catch (err) {
      serverError = String(err);
    } finally {
      saving = false;
    }
  }
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label={preset ? 'Sửa Preset' : 'Tạo Preset mới'}
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <h2 class="sheet-title">{preset ? 'Sửa Preset' : 'Tạo Preset mới'}</h2>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      {#if serverError}
        <div class="server-err">{serverError}</div>
      {/if}

      <div class="field-group">
        <label class="field-label" for="preset-name">Tên Preset</label>
        <input id="preset-name" type="text" bind:value={name} placeholder="Ví dụ: Seed Ổn Định" />
        {#if errors.name}<span class="field-error">{errors.name}</span>{/if}
      </div>

      <div class="field-group">
        <label class="field-label" for="preset-desc">Mô tả</label>
        <input
          id="preset-desc"
          type="text"
          bind:value={description}
          placeholder="Ghi chú ngắn cho kịch bản này"
        />
      </div>

      <!-- Group 1: Rates -->
      <section class="group-box green">
        <p class="section-label">Tốc độ & Ngẫu nhiên</p>
        <div class="grid-2">
          <div class="field-group">
            <label class="field-label" for="preset-up">Upload (KB/s)</label>
            <input id="preset-up" type="number" step="0.1" min="0" bind:value={uploadRate} />
            {#if errors.uploadRate}<span class="field-error">{errors.uploadRate}</span>{/if}
          </div>
          <div class="field-group">
            <label class="field-label" for="preset-down">Download (KB/s)</label>
            <input id="preset-down" type="number" step="0.1" min="0" bind:value={downloadRate} />
            {#if errors.downloadRate}<span class="field-error">{errors.downloadRate}</span>{/if}
          </div>
        </div>

        <div class="toggle-row">
          <span>Dao động tốc độ ngẫu nhiên</span>
          <button
            type="button"
            class="switch"
            class:checked={randomizeRates}
            aria-pressed={randomizeRates}
            aria-label="Bật dao động tốc độ"
            onclick={() => (randomizeRates = !randomizeRates)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>

        {#if randomizeRates}
          <div class="field-group">
            <label class="field-label" for="preset-rand">Biên độ dao động (%)</label>
            <input
              id="preset-rand"
              type="number"
              min="0"
              max="100"
              bind:value={randomRangePercent}
            />
            {#if errors.randomRangePercent}<span class="field-error">{errors.randomRangePercent}</span>{/if}
          </div>
        {/if}
      </section>

      <!-- Group 2: Stop conditions -->
      <section class="group-box purple">
        <p class="section-label">Điều kiện dừng</p>

        <div class="toggle-row">
          <span>Dừng khi đạt Ratio mục tiêu</span>
          <button
            type="button"
            class="switch"
            class:checked={stopAtRatioEnabled}
            aria-pressed={stopAtRatioEnabled}
            aria-label="Dừng theo Ratio"
            onclick={() => (stopAtRatioEnabled = !stopAtRatioEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>
        {#if stopAtRatioEnabled}
          <div class="grid-2">
            <div class="field-group">
              <label class="field-label" for="stop-ratio">Ratio mục tiêu</label>
              <input id="stop-ratio" type="number" step="0.1" min="0.1" bind:value={stopAtRatio} />
              {#if errors.stopAtRatio}<span class="field-error">{errors.stopAtRatio}</span>{/if}
            </div>
            <div class="field-group">
              <label class="field-label" for="rand-ratio-pct">Ngẫu nhiên Ratio (%)</label>
              <input
                id="rand-ratio-pct"
                type="number"
                min="0"
                max="50"
                disabled={!randomizeRatio}
                bind:value={randomRatioRangePercent}
              />
            </div>
          </div>
          <div class="toggle-row">
            <span>Ngẫu nhiên hóa Ratio dừng</span>
            <button
              type="button"
              class="switch"
              class:checked={randomizeRatio}
              aria-pressed={randomizeRatio}
              aria-label="Ngẫu nhiên hóa Ratio dừng"
              onclick={() => (randomizeRatio = !randomizeRatio)}
            >
              <span class="switch-thumb"></span>
            </button>
          </div>
        {/if}

        <div class="toggle-row">
          <span>Dừng khi Upload đạt (GB)</span>
          <button
            type="button"
            class="switch"
            class:checked={stopAtUploadedEnabled}
            aria-pressed={stopAtUploadedEnabled}
            aria-label="Dừng khi Upload đạt GB"
            onclick={() => (stopAtUploadedEnabled = !stopAtUploadedEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>
        {#if stopAtUploadedEnabled}
          <div class="field-group">
            <input type="number" step="0.5" min="0.1" bind:value={stopAtUploadedGb} />
            {#if errors.stopAtUploadedGb}<span class="field-error">{errors.stopAtUploadedGb}</span>{/if}
          </div>
        {/if}

        <div class="toggle-row">
          <span>Dừng khi Download đạt (GB)</span>
          <button
            type="button"
            class="switch"
            class:checked={stopAtDownloadedEnabled}
            aria-pressed={stopAtDownloadedEnabled}
            aria-label="Dừng khi Download đạt GB"
            onclick={() => (stopAtDownloadedEnabled = !stopAtDownloadedEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>
        {#if stopAtDownloadedEnabled}
          <div class="field-group">
            <input type="number" step="0.5" min="0.1" bind:value={stopAtDownloadedGb} />
            {#if errors.stopAtDownloadedGb}<span class="field-error">{errors.stopAtDownloadedGb}</span>{/if}
          </div>
        {/if}

        <div class="toggle-row">
          <span>Dừng sau thời gian Seed (giờ)</span>
          <button
            type="button"
            class="switch"
            class:checked={stopAtSeedTimeEnabled}
            aria-pressed={stopAtSeedTimeEnabled}
            aria-label="Dừng sau thời gian Seed"
            onclick={() => (stopAtSeedTimeEnabled = !stopAtSeedTimeEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>
        {#if stopAtSeedTimeEnabled}
          <div class="field-group">
            <input type="number" step="0.5" min="0.1" bind:value={stopAtSeedTimeHours} />
            {#if errors.stopAtSeedTimeHours}<span class="field-error">{errors.stopAtSeedTimeHours}</span>{/if}
          </div>
        {/if}

        <div class="field-group">
          <label class="field-label" for="post-stop">Hành động sau khi đạt điều kiện dừng</label>
          <select id="post-stop" bind:value={postStopAction}>
            <option value="idle">Giữ kết nối (Idle)</option>
            <option value="stop_seeding">Dừng Seed</option>
            <option value="delete_instance">Xóa phiên</option>
          </select>
        </div>
      </section>

      <!-- Group 3: Behavior & Progressive -->
      <section class="group-box orange">
        <p class="section-label">Hoàn thành & Hành vi</p>
        <div class="grid-2">
          <div class="field-group">
            <label class="field-label" for="preset-comp">Hoàn thành ban đầu (%)</label>
            <input
              id="preset-comp"
              type="number"
              min="0"
              max="100"
              step="1"
              bind:value={completionPercent}
            />
            {#if errors.completionPercent}<span class="field-error">{errors.completionPercent}</span>{/if}
          </div>
          <div class="field-group">
            <label class="field-label" for="preset-int">Cập nhật mỗi (giây)</label>
            <input id="preset-int" type="number" min="1" bind:value={updateIntervalSeconds} />
            {#if errors.updateIntervalSeconds}<span class="field-error">{errors.updateIntervalSeconds}</span>{/if}
          </div>
        </div>

        <div class="toggle-row">
          <span>Idle (0 KB/s) khi không có leecher</span>
          <button
            type="button"
            class="switch"
            class:checked={idleWhenNoLeechers}
            aria-pressed={idleWhenNoLeechers}
            aria-label="Idle khi không có leecher"
            onclick={() => (idleWhenNoLeechers = !idleWhenNoLeechers)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>

        <div class="toggle-row">
          <span>Idle (0 KB/s) khi không có seeder</span>
          <button
            type="button"
            class="switch"
            class:checked={idleWhenNoSeeders}
            aria-pressed={idleWhenNoSeeders}
            aria-label="Idle khi không có seeder"
            onclick={() => (idleWhenNoSeeders = !idleWhenNoSeeders)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>

        <div class="toggle-row">
          <span>Tăng/giảm tốc độ lũy tiến (Progressive)</span>
          <button
            type="button"
            class="switch"
            class:checked={progressiveRatesEnabled}
            aria-pressed={progressiveRatesEnabled}
            aria-label="Tốc độ lũy tiến"
            onclick={() => (progressiveRatesEnabled = !progressiveRatesEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>

        {#if progressiveRatesEnabled}
          <div class="grid-2">
            <div class="field-group">
              <label class="field-label" for="prog-up">Upload đích (KB/s)</label>
              <input id="prog-up" type="number" min="0" bind:value={targetUploadRate} />
            </div>
            <div class="field-group">
              <label class="field-label" for="prog-down">Download đích (KB/s)</label>
              <input id="prog-down" type="number" min="0" bind:value={targetDownloadRate} />
            </div>
          </div>
          <div class="field-group">
            <label class="field-label" for="prog-dur">Thời gian chuyển tiếp (giờ)</label>
            <input
              id="prog-dur"
              type="number"
              min="0.1"
              step="0.5"
              bind:value={progressiveDurationHours}
            />
          </div>
        {/if}
      </section>
    </div>

    <footer class="sheet-footer">
      <button type="button" class="btn btn-surface" onclick={onClose}>Hủy</button>
      <button type="button" class="btn btn-primary" disabled={saving} onclick={handleSave}>
        {saving ? 'Đang lưu...' : 'Lưu Preset'}
      </button>
    </footer>
  </div>
</div>

<style>
  .server-err {
    padding: 10px 12px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 13px;
    font-weight: 600;
  }

  .group-box {
    padding: 13px;
    border-radius: var(--radius-md);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .group-box.green {
    background: var(--tint-green);
  }

  .group-box.purple {
    background: var(--tint-purple);
  }

  .group-box.orange {
    background: var(--tint-orange);
  }

  .toggle-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    min-height: 40px;
    font-size: 14px;
    font-weight: 600;
  }
</style>
