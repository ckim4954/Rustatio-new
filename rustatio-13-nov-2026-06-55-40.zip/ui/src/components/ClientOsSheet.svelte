<script lang="ts">
  import { X } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';
  import type { ClientType, TargetOs } from '../lib/types';

  interface Props {
    onClose: () => void;
  }

  let { onClose }: Props = $props();

  let selectedClient = $state<ClientType>(store.config?.client.default_type ?? 'qbittorrent');
  let selectedVersion = $state<string>(store.config?.client.default_version ?? '');
  let selectedOs = $state<TargetOs>(store.config?.client.target_os ?? 'windows_10');
  let saving = $state(false);
  let error = $state<string | null>(null);

  const activeClientInfo = $derived(
    store.clientInfos.find((c) => c.id === selectedClient) ?? store.clientInfos[0],
  );

  $effect(() => {
    const info = activeClientInfo;
    if (info && !info.versions.includes(selectedVersion)) {
      selectedVersion = info.default_version;
    }
  });

  async function handleApply() {
    if (!store.config) return;
    error = null;
    saving = true;
    try {
      const updated = {
        ...store.config,
        client: {
          ...store.config.client,
          default_type: selectedClient,
          default_version: selectedVersion || activeClientInfo?.default_version || null,
          target_os: selectedOs,
        },
      };
      await store.saveConfig(updated);
      store.pushToast('Đã cập nhật Client & Target OS.', 'success');
      onClose();
    } catch (err) {
      error = String(err);
    } finally {
      saving = false;
    }
  }
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label="Chọn Client & Hệ điều hành"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <h2 class="sheet-title">Client giả lập & Target OS</h2>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      {#if error}
        <div class="err-box">{error}</div>
      {/if}

      <div class="field-group">
        <label class="field-label" for="client-select">BitTorrent Client</label>
        <select id="client-select" bind:value={selectedClient}>
          {#each store.clientInfos as client (client.id)}
            <option value={client.id}>{client.name}</option>
          {/each}
        </select>
      </div>

      <div class="field-group">
        <label class="field-label" for="version-select">Phiên bản Client</label>
        <select id="version-select" bind:value={selectedVersion}>
          {#if activeClientInfo}
            {#each activeClientInfo.versions as ver (ver)}
              <option value={ver}>{ver}</option>
            {/each}
          {/if}
        </select>
      </div>

      <div class="field-group">
        <span class="field-label">Target OS (User-Agent & định danh)</span>
        <div class="os-list">
          {#each store.targetOsInfos as osInfo (osInfo.id)}
            <button
              type="button"
              class="os-option neu-card-sm"
              class:selected={selectedOs === osInfo.id}
              onclick={() => (selectedOs = osInfo.id)}
            >
              <div class="os-meta">
                <strong>{osInfo.name}</strong>
                <span class="mono">{osInfo.nt_token}</span>
              </div>
              <span class="radio-dot" class:checked={selectedOs === osInfo.id}></span>
            </button>
          {/each}
        </div>
      </div>
    </div>

    <footer class="sheet-footer">
      <button type="button" class="btn btn-surface" onclick={onClose}>Hủy</button>
      <button type="button" class="btn btn-primary" disabled={saving} onclick={handleApply}>
        {saving ? 'Đang áp dụng...' : 'Áp dụng'}
      </button>
    </footer>
  </div>
</div>

<style>
  .err-box {
    padding: 10px 12px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 13px;
    font-weight: 600;
  }

  .os-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .os-option {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 14px;
    min-height: 56px;
    text-align: left;
  }

  .os-option.selected {
    border-color: var(--accent);
    background: var(--tint-green);
  }

  .os-meta {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .os-meta strong {
    font-size: 14px;
  }

  .os-meta span {
    font-size: 11px;
    color: var(--text-secondary);
  }

  .radio-dot {
    width: 18px;
    height: 18px;
    border-radius: 50%;
    border: 2px solid var(--border-subtle);
    flex-shrink: 0;
  }

  .radio-dot.checked {
    border-color: var(--accent);
    background: var(--accent);
    box-shadow: inset 0 0 0 4px var(--bg-surface);
  }
</style>
