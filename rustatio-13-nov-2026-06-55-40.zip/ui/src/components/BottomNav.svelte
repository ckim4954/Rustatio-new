<script lang="ts">
  import { Radio, Settings, SlidersHorizontal } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';
  import type { AppTab } from '../lib/types';

  const tabs: { id: AppTab; label: string }[] = [
    { id: 'sessions', label: 'Phiên' },
    { id: 'presets', label: 'Preset' },
    { id: 'settings', label: 'Cài đặt' },
  ];
</script>

<nav class="bottom-nav" aria-label="Điều hướng chính">
  {#each tabs as tab (tab.id)}
    {@const active = store.activeTab === tab.id}
    <button
      type="button"
      class="nav-item"
      class:active
      aria-current={active ? 'page' : undefined}
      onclick={() => (store.activeTab = tab.id)}
    >
      <span class="nav-pill">
        {#if tab.id === 'sessions'}
          <Radio size={20} strokeWidth={2.1} />
        {:else if tab.id === 'presets'}
          <SlidersHorizontal size={20} strokeWidth={2.1} />
        {:else}
          <Settings size={20} strokeWidth={2.1} />
        {/if}
      </span>
      <span class="nav-label">{tab.label}</span>
    </button>
  {/each}
</nav>

<style>
  .bottom-nav {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 40;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    align-items: center;
    padding: 6px 12px calc(8px + var(--safe-bottom));
    background: var(--nav-bg);
    border-top: 1px solid var(--border-subtle);
    box-shadow: 0 -6px 20px rgba(0, 0, 0, 0.08);
  }

  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 3px;
    min-height: 52px;
    color: var(--text-secondary);
    transition: color 0.18s ease;
  }

  .nav-item.active {
    color: var(--accent-text);
  }

  .nav-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 52px;
    height: 30px;
    border-radius: var(--radius-pill);
    transition: background-color 0.2s ease, transform 0.14s ease;
  }

  .nav-item.active .nav-pill {
    background: var(--tint-green);
    box-shadow: var(--neu-shadow-sm);
  }

  .nav-item:active .nav-pill {
    transform: scale(0.94);
  }

  .nav-label {
    font-size: 12px;
    font-weight: 700;
  }
</style>
