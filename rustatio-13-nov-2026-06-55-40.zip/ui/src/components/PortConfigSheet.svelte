<script lang="ts">
  import { Shuffle, X } from '@lucide/svelte';
  import { store } from '../lib/store.svelte';

  interface Props {
    onClose: () => void;
  }

  let { onClose }: Props = $props();

  let announcePort = $state(store.config?.client.default_port ?? 6881);
  let listeningEnabled = $state(store.config?.client.listening_enabled ?? false);
  let listeningPort = $state(store.config?.client.listening_port ?? 6882);
  let error = $state<string | null>(null);
  let saving = $state(false);

  function randomizeDraftAnnouncePort() {
    const port = Math.floor(Math.random() * (65535 - 1024 + 1)) + 1024;
    announcePort = port;
    error = null;
  }

  async function handleSave() {
    if (!store.config) return;
    const ann = Math.round(Number(announcePort));
    const lst = Math.round(Number(listeningPort));
    if (!Number.isInteger(ann) || ann < 1 || ann > 65535) {
      error = 'Announce Port phải nằm trong khoảng 1 – 65535.';
      return;
    }
    if (!Number.isInteger(lst) || lst < 1 || lst > 65535) {
      error = 'Listening Port phải nằm trong khoảng 1 – 65535.';
      return;
    }

    error = null;
    saving = true;
    try {
      const updated = {
        ...store.config,
        client: {
          ...store.config.client,
          default_port: ann,
          listening_enabled: listeningEnabled,
          listening_port: lst,
        },
      };
      await store.saveConfig(updated);
      store.pushToast('Đã lưu cấu hình cổng.', 'success');
      onClose();
    } catch (err) {
      error = String(err);
    } finally {
      saving = false;
    }
  }
</script>

<div class="sheet-backdrop" role="presentation" onclick={onClose}>
  <div
    class="sheet-panel"
    role="dialog"
    aria-modal="true"
    aria-label="Cấu hình cổng"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => {
      if (e.key === 'Escape') onClose();
    }}
  >
    <div class="sheet-handle"></div>
    <header class="sheet-header">
      <h2 class="sheet-title">Cấu hình Cổng (Port)</h2>
      <button type="button" class="icon-btn" aria-label="Đóng" onclick={onClose}>
        <X size={20} />
      </button>
    </header>

    <div class="sheet-body">
      {#if error}
        <div class="err-box">{error}</div>
      {/if}

      <section class="port-block neu-inset">
        <div class="port-head">
          <strong>Announce Port (Gửi tới Tracker)</strong>
          <span class="badge-tag">Tham số &amp;port=...</span>
        </div>
        <p class="port-desc">
          Giá trị cổng được khai báo trong bản tin announce tới tracker. Nhấn Ngẫu nhiên chỉ cập
          nhật bản nháp; chỉ lưu khi bạn bấm Lưu.
        </p>

        <div class="port-input-row">
          <input
            type="number"
            min="1"
            max="65535"
            class="tabular-nums"
            bind:value={announcePort}
            aria-label="Announce Port"
          />
          <button
            type="button"
            class="btn btn-surface"
            onclick={randomizeDraftAnnouncePort}
          >
            <Shuffle size={16} />
            Ngẫu nhiên
          </button>
        </div>
      </section>

      <section class="port-block neu-inset">
        <div class="toggle-row">
          <div>
            <strong>Listening Port (Socket cục bộ)</strong>
            <p class="port-desc">
              Mở socket TCP cục bộ phản hồi kết nối ngang hàng khi có phiên hoạt động (khác với
              Announce Port).
            </p>
          </div>
          <button
            type="button"
            class="switch"
            class:checked={listeningEnabled}
            aria-pressed={listeningEnabled}
            aria-label="Bật Listening Port cục bộ"
            onclick={() => (listeningEnabled = !listeningEnabled)}
          >
            <span class="switch-thumb"></span>
          </button>
        </div>

        <div class="field-group">
          <label class="field-label" for="listening-port-input">Cổng lắng nghe TCP (1 – 65535)</label>
          <input
            id="listening-port-input"
            type="number"
            min="1"
            max="65535"
            class="tabular-nums"
            disabled={!listeningEnabled}
            bind:value={listeningPort}
          />
        </div>

        {#if store.networkStatus}
          <div class="net-status">
            {#if store.networkStatus.peer_listener_active}
              <span>Đang lắng nghe trên cổng {store.networkStatus.peer_listener_port}</span>
            {:else if store.networkStatus.peer_listener_error}
              <span class="err-text">{store.networkStatus.peer_listener_error}</span>
            {:else}
              <span>Socket cục bộ đang tắt hoặc chưa có phiên chạy.</span>
            {/if}
          </div>
        {/if}
      </section>
    </div>

    <footer class="sheet-footer">
      <button type="button" class="btn btn-surface" onclick={onClose}>Hủy</button>
      <button type="button" class="btn btn-primary" disabled={saving} onclick={handleSave}>
        {saving ? 'Đang lưu...' : 'Lưu'}
      </button>
    </footer>
  </div>
</div>

<style>
  .err-box {
    padding: 10px 12px;
    border-radius: var(--radius-sm);
    background: var(--tint-red);
    color: var(--error-color);
    font-size: 13px;
    font-weight: 600;
  }

  .port-block {
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .port-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .badge-tag {
    font-size: 11px;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: var(--radius-pill);
    background: var(--tint-green);
    color: var(--accent-text);
  }

  .port-desc {
    margin: 4px 0 0;
    font-size: 12px;
    color: var(--text-secondary);
  }

  .port-input-row {
    display: flex;
    gap: 10px;
    align-items: center;
  }

  .port-input-row input {
    flex: 1;
  }

  .toggle-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  }

  .net-status {
    font-size: 12px;
    font-weight: 600;
    color: var(--text-secondary);
  }

  .err-text {
    color: var(--error-color);
  }
</style>
