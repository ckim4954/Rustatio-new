import type { DurationWire, PostStopAction, TargetOs } from './types';

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let idx = 0;
  let value = bytes;
  while (value >= 1024 && idx < units.length - 1) {
    value /= 1024;
    idx += 1;
  }
  const digits = idx === 0 ? 0 : value >= 100 ? 1 : 2;
  return `${value.toFixed(digits)} ${units[idx]}`;
}

export function formatRateKbps(kbps: number): string {
  if (!Number.isFinite(kbps) || kbps <= 0) return '0 KB/s';
  if (kbps >= 1024) {
    return `${(kbps / 1024).toFixed(2)} MB/s`;
  }
  return `${kbps >= 100 ? kbps.toFixed(0) : kbps.toFixed(1)} KB/s`;
}

export function formatRatio(ratio: number): string {
  if (!Number.isFinite(ratio) || ratio < 0) return '0.00';
  return ratio.toFixed(2);
}

export function formatInfoHashHex(hash: number[]): string {
  return hash.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function extractTrackerHost(announceUrl: string): string {
  try {
    const url = new URL(announceUrl);
    return url.host || announceUrl;
  } catch {
    return announceUrl || 'Không rõ tracker';
  }
}

export function formatDurationSeconds(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds <= 0) return '0 giây';
  const secs = Math.floor(totalSeconds);
  const hours = Math.floor(secs / 3600);
  const minutes = Math.floor((secs % 3600) / 60);
  const rem = secs % 60;
  if (hours > 0) return `${hours}g ${minutes}p`;
  if (minutes > 0) return `${minutes}p ${rem}s`;
  return `${rem} giây`;
}

export function formatWireDuration(duration: DurationWire | null | undefined): string {
  if (!duration) return '0 giây';
  return formatDurationSeconds(duration.secs);
}

export function formatTimestampMs(ms: number | null | undefined): string {
  if (ms == null || ms <= 0) return 'Chưa có dữ liệu';
  const date = new Date(ms);
  return date.toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function formatCountdownMs(targetMs: number | null | undefined, nowMs: number): string {
  if (targetMs == null || targetMs <= 0) return 'Chưa có dữ liệu';
  const diffSecs = Math.max(0, Math.ceil((targetMs - nowMs) / 1000));
  if (diffSecs === 0) return 'Đang đến hạn';
  return `Còn ${formatDurationSeconds(diffSecs)}`;
}

export function formatTargetOsLabel(os: TargetOs | undefined | null): string {
  switch (os) {
    case 'windows_7':
      return 'Windows 7';
    case 'windows_11':
      return 'Windows 11';
    case 'windows_10':
    default:
      return 'Windows 10';
  }
}

export function formatPostStopAction(action: PostStopAction | string | undefined | null): string {
  switch (action) {
    case 'stop_seeding':
      return 'Dừng Seed';
    case 'delete_instance':
      return 'Xóa phiên';
    case 'idle':
    default:
      return 'Giữ kết nối (Idle)';
  }
}
