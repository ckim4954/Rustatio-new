import { invoke } from '@tauri-apps/api/core';
import type {
  AppConfig,
  ApplyPresetResponse,
  BulkFakerActionResponse,
  ClientInfo,
  DesktopNetworkStatus,
  FakerStats,
  ForegroundServiceStatus,
  ImportPresetsResponse,
  InstanceInfo,
  PickedTorrentFile,
  PresetItem,
  PresetListResponse,
  SavePresetRequest,
  ShareJsonResult,
  TargetOsInfo,
} from './types';

export const api = {
  // Sessions / Instances
  listInstances: () => invoke<InstanceInfo[]>('list_instances'),
  pickTorrentFile: () => invoke<PickedTorrentFile>('pick_torrent_file'),
  importTorrentBytes: (name: string, bytesBase64: string, autoStart = false) =>
    invoke<InstanceInfo>('import_torrent_bytes', { name, bytesBase64, autoStart }),
  deleteInstance: (instanceId: number, force = true) =>
    invoke<void>('delete_instance', { instanceId, force }),

  // Faker lifecycle
  startFaker: (instance: InstanceInfo) =>
    invoke<void>('start_faker', {
      instanceId: Number(instance.id),
      torrent: {
        ...instance.torrent,
        files: [],
      },
      config: instance.config,
    }),
  stopFaker: (instanceId: number) => invoke<void>('stop_faker', { instanceId }),
  pauseFaker: (instanceId: number) => invoke<void>('pause_faker', { instanceId }),
  resumeFaker: (instanceId: number) => invoke<void>('resume_faker', { instanceId }),
  announceNow: (instanceId: number) => invoke<FakerStats>('announce_now', { instanceId }),
  recoverTrackerFaker: (instanceId: number) =>
    invoke<FakerStats>('recover_tracker_faker', { instanceId }),
  startAllFakers: () => invoke<BulkFakerActionResponse>('start_all_fakers'),
  pauseAllFakers: () => invoke<BulkFakerActionResponse>('pause_all_fakers'),
  stopAllFakers: () => invoke<BulkFakerActionResponse>('stop_all_fakers'),

  // Presets
  listPresets: () => invoke<PresetListResponse>('list_presets'),
  savePreset: (request: SavePresetRequest) => invoke<PresetItem>('save_preset', { request }),
  duplicatePreset: (id: string) => invoke<PresetItem>('duplicate_preset', { id }),
  deletePreset: (id: string) => invoke<PresetListResponse>('delete_preset', { id }),
  setDefaultPreset: (id: string) => invoke<PresetListResponse>('set_default_preset', { id }),
  applyPreset: (id: string, instanceId?: number | null) =>
    invoke<ApplyPresetResponse>('apply_preset', {
      id,
      instanceId: instanceId ?? null,
    }),
  importPresetsJson: (rawJson: string) =>
    invoke<ImportPresetsResponse>('import_presets_json', { rawJson }),
  exportPresetsJson: (presetId?: string | null) =>
    invoke<string>('export_presets_json', { presetId: presetId ?? null }),

  // Settings / Client / Network / Android Foreground Service
  getConfig: () => invoke<AppConfig>('get_config'),
  updateConfig: (config: AppConfig) => invoke<void>('update_config', { config }),
  setDarkMode: (darkMode: boolean) => invoke<AppConfig>('set_dark_mode', { darkMode }),
  getClientInfos: () => invoke<ClientInfo[]>('get_client_infos'),
  getTargetOsInfos: () => invoke<TargetOsInfo[]>('get_target_os_infos'),
  getNetworkStatus: () => invoke<DesktopNetworkStatus>('get_network_status'),
  getForegroundServiceStatus: () =>
    invoke<ForegroundServiceStatus>('get_foreground_service_status'),
  requestNotificationPermission: () =>
    invoke<ForegroundServiceStatus>('request_notification_permission'),
  syncForegroundService: () => invoke<ForegroundServiceStatus>('sync_foreground_service'),
  shareOrSaveJson: (filename: string, content: string, mode: 'share' | 'save') =>
    invoke<ShareJsonResult>('share_or_save_json', { filename, content, mode }),
};
