export type ClientType =
  | 'qbittorrent'
  | 'utorrent'
  | 'transmission'
  | 'deluge'
  | 'bittorrent'
  | 'rtorrent';

export type TargetOs = 'windows_7' | 'windows_10' | 'windows_11';

export type FakerState =
  | 'Idle'
  | 'Starting'
  | 'Running'
  | 'Stopping'
  | 'Paused'
  | 'Stopped';

export type PostStopAction = 'idle' | 'stop_seeding' | 'delete_instance';

export interface ClientInfo {
  id: ClientType;
  name: string;
  default_version: string;
  versions: string[];
  default_port: number;
}

export interface TargetOsInfo {
  id: TargetOs;
  name: string;
  nt_token: string;
}

export interface ClientSettings {
  default_type: ClientType;
  default_version: string | null;
  target_os: TargetOs;
  default_port: number;
  listening_enabled: boolean;
  listening_port: number;
  default_num_want: number;
}

export interface FakerSettings {
  default_upload_rate: number;
  default_download_rate: number;
  default_announce_interval: number;
  update_interval: number;
}

export interface UiSettings {
  window_width: number;
  window_height: number;
  dark_mode: boolean;
  show_logs: boolean;
}

export interface AppConfig {
  client: ClientSettings;
  faker: FakerSettings;
  ui: UiSettings;
}

export interface TorrentSummary {
  info_hash: number[];
  announce: string;
  announce_list?: string[][];
  name: string;
  total_size: number;
  piece_length: number;
  num_pieces: number;
  creation_date?: number;
  comment?: string;
  created_by?: string;
  is_single_file: boolean;
  file_count: number;
}

export interface FakerConfig {
  upload_rate: number;
  download_rate: number;
  port: number;
  vpn_port_sync: boolean;
  client_type: ClientType;
  client_version: string | null;
  target_os: TargetOs;
  initial_uploaded: number;
  initial_downloaded: number;
  completion_percent: number;
  num_want: number;
  randomize_rates: boolean;
  random_range_percent: number;
  randomize_ratio: boolean;
  random_ratio_range_percent: number;
  stop_at_ratio: number | null;
  effective_stop_at_ratio: number | null;
  stop_at_uploaded: number | null;
  stop_at_downloaded: number | null;
  stop_at_seed_time: number | null;
  idle_when_no_leechers: boolean;
  idle_when_no_seeders: boolean;
  scrape_interval: number;
  update_interval_seconds: number;
  progressive_rates: boolean;
  target_upload_rate: number | null;
  target_download_rate: number | null;
  progressive_duration: number;
  post_stop_action: PostStopAction;
}

export interface DurationWire {
  secs: number;
  nanos: number;
}

export interface FakerStats {
  uploaded: number;
  downloaded: number;
  ratio: number;
  left: number;
  torrent_completion: number;
  seeders: number;
  leechers: number;
  state: FakerState;
  is_idling: boolean;
  idling_reason: string | null;
  tracker_error: string | null;
  tracker_retry_attempt: number;
  tracker_retry_at_ms: number | null;
  session_uploaded: number;
  session_downloaded: number;
  session_ratio: number;
  elapsed_time: DurationWire;
  current_upload_rate: number;
  current_download_rate: number;
  average_upload_rate: number;
  average_download_rate: number;
  upload_progress: number;
  download_progress: number;
  ratio_progress: number;
  seed_time_progress: number;
  effective_stop_at_ratio: number | null;
  stop_condition_met: boolean;
  post_stop_action: PostStopAction;
  last_announce_at_ms: number | null;
  next_announce_at_ms: number | null;
  announce_interval_secs: number | null;
  last_http_status: number | null;
  peers_count: number | null;
  announce_in_progress: boolean;
  peer_id: string;
  key: string;
  user_agent: string;
  target_os: TargetOs;
  announce_count: number;
}

export interface InstanceInfo {
  id: string;
  torrent: TorrentSummary;
  config: FakerConfig;
  stats: FakerStats;
  created_at: number;
  source: string;
  tags: string[];
}

export interface PresetSettings {
  uploadRate?: number | null;
  downloadRate?: number | null;
  port?: number | null;
  vpnPortSync?: boolean | null;
  selectedClient?: ClientType | null;
  selectedClientVersion?: string | null;
  targetOs?: TargetOs | null;
  completionPercent?: number | null;
  randomizeRates?: boolean | null;
  randomRangePercent?: number | null;
  randomizeRatio?: boolean | null;
  randomRatioRangePercent?: number | null;
  stopAtRatioEnabled?: boolean | null;
  stopAtRatio?: number | null;
  stopAtUploadedEnabled?: boolean | null;
  stopAtUploadedGb?: number | null;
  stopAtDownloadedEnabled?: boolean | null;
  stopAtDownloadedGb?: number | null;
  stopAtSeedTimeEnabled?: boolean | null;
  stopAtSeedTimeHours?: number | null;
  idleWhenNoLeechers?: boolean | null;
  idleWhenNoSeeders?: boolean | null;
  updateIntervalSeconds?: number | null;
  postStopAction?: PostStopAction | null;
  progressiveRatesEnabled?: boolean | null;
  targetUploadRate?: number | null;
  targetDownloadRate?: number | null;
  progressiveDurationHours?: number | null;
}

export interface PresetItem {
  id: string;
  name: string;
  description: string;
  icon: string;
  recommended: boolean;
  builtIn: boolean;
  isDefault: boolean;
  isActive: boolean;
  settings: PresetSettings;
  tips: string[];
  createdAt?: string | null;
}

export interface PresetListResponse {
  presets: PresetItem[];
  defaultPresetId: string | null;
  activePresetId: string | null;
}

export interface SavePresetRequest {
  id?: string | null;
  name: string;
  description: string;
  icon: string;
  settings: PresetSettings;
}

export interface ApplyPresetResponse {
  list: PresetListResponse;
  appliedInstances: number;
  skippedRunning: number;
}

export interface ImportPresetsResponse {
  importedCount: number;
  presets: PresetItem[];
}

export interface PickedTorrentFile {
  name: string;
  bytesBase64: string;
  size: number;
  cancelled: boolean;
}

export interface ForegroundServiceStatus {
  isRunning: boolean;
  activeSessions: number;
  notificationGranted: boolean;
  sdkInt: number;
}

export interface ShareJsonResult {
  success: boolean;
  message: string;
}

export interface DesktopNetworkStatus {
  peer_listener_port: number | null;
  peer_listener_active: boolean;
  peer_listener_error: string | null;
  proxy_enabled: boolean;
  proxy_url: string | null;
}

export interface BulkFakerActionResponse {
  succeeded: number[];
  failed: { id: number; error: string }[];
}

export type SessionFilterKey =
  | 'all'
  | 'running'
  | 'starting'
  | 'announcing'
  | 'waiting'
  | 'paused'
  | 'stopped'
  | 'error';

export type AppTab = 'sessions' | 'presets' | 'settings';
