import type { InstanceInfo, SessionFilterKey } from './types';

export interface StatusPresentation {
  key: Exclude<SessionFilterKey, 'all'>;
  label: string;
  colorVar: string;
  bgTintVar: string;
}

export function resolveSessionStatus(
  instance: InstanceInfo,
  nowMs: number = Date.now(),
): StatusPresentation {
  const { stats } = instance;

  if (stats.tracker_error) {
    return {
      key: 'error',
      label: 'Lỗi tracker',
      colorVar: 'var(--error-color)',
      bgTintVar: 'var(--tint-red)',
    };
  }

  if (stats.announce_in_progress) {
    return {
      key: 'announcing',
      label: 'Đang announce',
      colorVar: 'var(--warning-color)',
      bgTintVar: 'var(--tint-orange)',
    };
  }

  switch (stats.state) {
    case 'Starting':
      return {
        key: 'starting',
        label: 'Đang kết nối',
        colorVar: 'var(--download-color)',
        bgTintVar: 'var(--tint-blue)',
      };
    case 'Running':
      if (stats.is_idling) {
        return {
          key: 'waiting',
          label: 'Chờ lần announce tiếp theo',
          colorVar: 'var(--warning-color)',
          bgTintVar: 'var(--tint-orange)',
        };
      }
      if (stats.next_announce_at_ms && stats.next_announce_at_ms > nowMs && stats.last_announce_at_ms) {
        return {
          key: 'running',
          label: 'Đang chạy',
          colorVar: 'var(--running-color)',
          bgTintVar: 'var(--tint-green)',
        };
      }
      return {
        key: 'running',
        label: 'Đang chạy',
        colorVar: 'var(--running-color)',
        bgTintVar: 'var(--tint-green)',
      };
    case 'Paused':
      return {
        key: 'paused',
        label: 'Tạm dừng',
        colorVar: 'var(--paused-color)',
        bgTintVar: 'var(--bg-inset)',
      };
    case 'Stopping':
    case 'Idle':
      return {
        key: 'waiting',
        label: 'Chờ lần announce tiếp theo',
        colorVar: 'var(--warning-color)',
        bgTintVar: 'var(--tint-orange)',
      };
    case 'Stopped':
    default:
      return {
        key: 'stopped',
        label: 'Đã dừng',
        colorVar: 'var(--stopped-color)',
        bgTintVar: 'var(--bg-inset)',
      };
  }
}

export function matchesSessionFilter(
  instance: InstanceInfo,
  filter: SessionFilterKey,
  nowMs: number = Date.now(),
): boolean {
  if (filter === 'all') return true;
  const resolved = resolveSessionStatus(instance, nowMs);
  if (filter === 'waiting') {
    return (
      resolved.key === 'waiting' ||
      (instance.stats.state === 'Running' &&
        Boolean(instance.stats.next_announce_at_ms && instance.stats.next_announce_at_ms > nowMs))
    );
  }
  return resolved.key === filter;
}

export const STATUS_FILTER_CHIPS: { key: SessionFilterKey; label: string }[] = [
  { key: 'all', label: 'Tất cả' },
  { key: 'running', label: 'Đang chạy' },
  { key: 'starting', label: 'Đang kết nối' },
  { key: 'announcing', label: 'Đang announce' },
  { key: 'waiting', label: 'Chờ lần announce tiếp theo' },
  { key: 'paused', label: 'Tạm dừng' },
  { key: 'stopped', label: 'Đã dừng' },
  { key: 'error', label: 'Lỗi tracker' },
];
