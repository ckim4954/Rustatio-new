import { listen, type UnlistenFn } from '@tauri-apps/api/event';
import { api } from './api';
import { formatInfoHashHex } from './format';
import { matchesSessionFilter } from './status';
import type {
  AppConfig,
  AppTab,
  ClientInfo,
  DesktopNetworkStatus,
  ForegroundServiceStatus,
  InstanceInfo,
  PresetItem,
  SavePresetRequest,
  SessionFilterKey,
  TargetOsInfo,
} from './types';

export interface ToastMessage {
  id: number;
  kind: 'success' | 'error' | 'info';
  text: string;
}

function applyThemeAttribute(darkMode: boolean) {
  if (typeof document !== 'undefined') {
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
  }
}

class RustatioStore {
  activeTab = $state<AppTab>('sessions');
  instances = $state<InstanceInfo[]>([]);
  presets = $state<PresetItem[]>([]);
  defaultPresetId = $state<string | null>('balanced');
  activePresetId = $state<string | null>('balanced');
  config = $state<AppConfig | null>(null);
  clientInfos = $state<ClientInfo[]>([]);
  targetOsInfos = $state<TargetOsInfo[]>([]);
  networkStatus = $state<DesktopNetworkStatus | null>(null);
  foregroundStatus = $state<ForegroundServiceStatus | null>(null);

  searchQuery = $state('');
  statusFilter = $state<SessionFilterKey>('all');
  selectedInstanceId = $state<string | null>(null);
  nowMs = $state(Date.now());
  busyAction = $state<string | null>(null);
  initialized = $state(false);
  toasts = $state<ToastMessage[]>([]);

  private nextToastId = 1;
  private pollTimer: ReturnType<typeof setInterval> | null = null;
  private clockTimer: ReturnType<typeof setInterval> | null = null;
  private unlisteners: UnlistenFn[] = [];

  get darkMode(): boolean {
    return this.config?.ui.dark_mode ?? true;
  }

  get selectedInstance(): InstanceInfo | null {
    if (!this.selectedInstanceId) return null;
    return this.instances.find((item) => item.id === this.selectedInstanceId) ?? null;
  }

  get activeSessionCount(): number {
    return this.instances.filter(
      (i) => i.stats.state === 'Running' || i.stats.state === 'Starting',
    ).length;
  }

  get totalUploadRateKbps(): number {
    return this.instances.reduce((sum, i) => sum + (i.stats.current_upload_rate || 0), 0);
  }

  get totalDownloadRateKbps(): number {
    return this.instances.reduce((sum, i) => sum + (i.stats.current_download_rate || 0), 0);
  }

  get totalUploadedBytes(): number {
    return this.instances.reduce((sum, i) => sum + (i.stats.uploaded || 0), 0);
  }

  get totalDownloadedBytes(): number {
    return this.instances.reduce((sum, i) => sum + (i.stats.downloaded || 0), 0);
  }

  get filteredInstances(): InstanceInfo[] {
    const q = this.searchQuery.trim().toLowerCase();
    return this.instances.filter((item) => {
      if (!matchesSessionFilter(item, this.statusFilter, this.nowMs)) {
        return false;
      }
      if (!q) return true;
      const hashHex = formatInfoHashHex(item.torrent.info_hash).toLowerCase();
      return (
        item.torrent.name.toLowerCase().includes(q) ||
        item.torrent.announce.toLowerCase().includes(q) ||
        hashHex.includes(q)
      );
    });
  }

  pushToast(text: string, kind: ToastMessage['kind'] = 'info') {
    const id = this.nextToastId++;
    this.toasts = [...this.toasts, { id, kind, text }];
    setTimeout(() => {
      this.toasts = this.toasts.filter((t) => t.id !== id);
    }, 3600);
  }

  async init() {
    await Promise.all([
      this.refreshInstances(),
      this.refreshPresets(),
      this.refreshConfig(),
      this.refreshClientMetadata(),
      this.refreshSystemStatuses(),
    ]);
    this.initialized = true;

    try {
      const unlistenSummaries = await listen('instance-summaries', () => {
        void this.refreshInstances();
      });
      const unlistenDeleted = await listen('instance-deleted', () => {
        void this.refreshInstances();
      });
      const unlistenRecovered = await listen<number>('sessions-recovered', (event) => {
        if (event.payload > 0) {
          this.pushToast(
            `Đã khôi phục ${event.payload} phiên trước đó với tiến độ đã lưu.`,
            'info',
          );
        }
        void this.refreshInstances();
      });
      const unlistenConfig = await listen<AppConfig>('config-updated', (event) => {
        this.config = event.payload;
        applyThemeAttribute(event.payload.ui.dark_mode);
      });
      this.unlisteners = [unlistenSummaries, unlistenDeleted, unlistenRecovered, unlistenConfig];
    } catch {
      // Ignore if running outside full Tauri event runtime
    }

    this.pollTimer = setInterval(() => {
      if (this.instances.length > 0 || this.activeTab === 'settings') {
        void this.refreshInstances();
        void this.refreshSystemStatuses();
      }
    }, 2000);

    this.clockTimer = setInterval(() => {
      this.nowMs = Date.now();
    }, 1000);
  }

  destroy() {
    if (this.pollTimer) clearInterval(this.pollTimer);
    if (this.clockTimer) clearInterval(this.clockTimer);
    for (const unlisten of this.unlisteners) {
      unlisten();
    }
    this.unlisteners = [];
  }

  async refreshInstances() {
    try {
      this.instances = await api.listInstances();
    } catch (err) {
      console.error('Failed to list instances:', err);
    }
  }

  async refreshPresets() {
    try {
      const res = await api.listPresets();
      this.presets = res.presets;
      this.defaultPresetId = res.defaultPresetId;
      this.activePresetId = res.activePresetId;
    } catch (err) {
      console.error('Failed to list presets:', err);
    }
  }

  async refreshConfig() {
    try {
      const cfg = await api.getConfig();
      this.config = cfg;
      applyThemeAttribute(cfg.ui.dark_mode);
    } catch (err) {
      console.error('Failed to get config:', err);
    }
  }

  async refreshClientMetadata() {
    try {
      const [clients, osList] = await Promise.all([
        api.getClientInfos(),
        api.getTargetOsInfos(),
      ]);
      this.clientInfos = clients;
      this.targetOsInfos = osList;
    } catch (err) {
      console.error('Failed to get client metadata:', err);
    }
  }

  async refreshSystemStatuses() {
    try {
      const [net, fg] = await Promise.all([
        api.getNetworkStatus(),
        api.getForegroundServiceStatus(),
      ]);
      this.networkStatus = net;
      this.foregroundStatus = fg;
    } catch {
      // Ignore non-critical status polling error
    }
  }

  async addSessionFromAndroidPicker() {
    this.busyAction = 'pick-torrent';
    try {
      const picked = await api.pickTorrentFile();
      if (picked.cancelled) {
        return;
      }
      const created = await api.importTorrentBytes(picked.name, picked.bytesBase64, false);
      await this.refreshInstances();
      this.pushToast(`Đã thêm phiên "${created.torrent.name}"`, 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    } finally {
      this.busyAction = null;
    }
  }

  async startSession(instance: InstanceInfo) {
    try {
      if (instance.stats.tracker_error) {
        await api.recoverTrackerFaker(Number(instance.id));
      } else if (instance.stats.state === 'Paused') {
        await api.resumeFaker(Number(instance.id));
      } else {
        await api.startFaker(instance);
      }
      await this.refreshInstances();
      await this.refreshSystemStatuses();
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async pauseSession(instanceId: number) {
    try {
      await api.pauseFaker(instanceId);
      await this.refreshInstances();
      await this.refreshSystemStatuses();
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async stopSession(instanceId: number) {
    try {
      await api.stopFaker(instanceId);
      await this.refreshInstances();
      await this.refreshSystemStatuses();
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async announceNow(instanceId: number) {
    this.busyAction = `announce-${instanceId}`;
    try {
      await api.announceNow(instanceId);
      await this.refreshInstances();
      this.pushToast('Đã gửi announce tới tracker.', 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    } finally {
      this.busyAction = null;
    }
  }

  async deleteSession(instanceId: number) {
    try {
      await api.deleteInstance(instanceId, true);
      if (this.selectedInstanceId === String(instanceId)) {
        this.selectedInstanceId = null;
      }
      await this.refreshInstances();
      await this.refreshSystemStatuses();
      this.pushToast('Đã xóa phiên.', 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async bulkStart() {
    this.busyAction = 'bulk-start';
    try {
      const res = await api.startAllFakers();
      await this.refreshInstances();
      await this.refreshSystemStatuses();
      if (res.failed.length > 0) {
        this.pushToast(
          `Đã chạy ${res.succeeded.length} phiên (${res.failed.length} lỗi).`,
          'info',
        );
      } else {
        this.pushToast(`Đã chạy ${res.succeeded.length} phiên.`, 'success');
      }
    } catch (err) {
      this.pushToast(String(err), 'error');
    } finally {
      this.busyAction = null;
    }
  }

  async bulkPause() {
    this.busyAction = 'bulk-pause';
    try {
      const res = await api.pauseAllFakers();
      await this.refreshInstances();
      await this.refreshSystemStatuses();
      this.pushToast(`Đã tạm dừng ${res.succeeded.length} phiên.`, 'info');
    } catch (err) {
      this.pushToast(String(err), 'error');
    } finally {
      this.busyAction = null;
    }
  }

  async bulkStop() {
    this.busyAction = 'bulk-stop';
    try {
      const res = await api.stopAllFakers();
      await this.refreshInstances();
      await this.refreshSystemStatuses();
      this.pushToast(`Đã dừng ${res.succeeded.length} phiên.`, 'info');
    } catch (err) {
      this.pushToast(String(err), 'error');
    } finally {
      this.busyAction = null;
    }
  }

  async toggleTheme() {
    const next = !this.darkMode;
    applyThemeAttribute(next);
    if (this.config) {
      this.config = {
        ...this.config,
        ui: { ...this.config.ui, dark_mode: next },
      };
    }
    try {
      this.config = await api.setDarkMode(next);
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async saveConfig(updated: AppConfig) {
    await api.updateConfig(updated);
    this.config = updated;
    applyThemeAttribute(updated.ui.dark_mode);
    await Promise.all([this.refreshInstances(), this.refreshSystemStatuses()]);
  }

  async savePreset(request: SavePresetRequest) {
    const saved = await api.savePreset(request);
    await this.refreshPresets();
    this.pushToast(`Đã lưu Preset "${saved.name}".`, 'success');
    return saved;
  }

  async duplicatePreset(id: string) {
    try {
      const copy = await api.duplicatePreset(id);
      await this.refreshPresets();
      this.pushToast(`Đã nhân bản thành "${copy.name}".`, 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async deletePreset(id: string) {
    try {
      const res = await api.deletePreset(id);
      this.presets = res.presets;
      this.defaultPresetId = res.defaultPresetId;
      this.activePresetId = res.activePresetId;
      this.pushToast('Đã xóa Preset.', 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async setDefaultPreset(id: string) {
    try {
      const res = await api.setDefaultPreset(id);
      this.presets = res.presets;
      this.defaultPresetId = res.defaultPresetId;
      this.activePresetId = res.activePresetId;
      this.pushToast('Đã đặt làm Preset mặc định.', 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async applyPreset(id: string) {
    try {
      const res = await api.applyPreset(id, null);
      this.presets = res.list.presets;
      this.defaultPresetId = res.list.defaultPresetId;
      this.activePresetId = res.list.activePresetId;
      await this.refreshInstances();
      const extra =
        res.appliedInstances > 0 ? ` (${res.appliedInstances} phiên đã dừng được cập nhật)` : '';
      this.pushToast(`Đã áp dụng Preset${extra}.`, 'success');
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }

  async requestNotificationPermission() {
    try {
      this.foregroundStatus = await api.requestNotificationPermission();
      if (this.foregroundStatus.notificationGranted) {
        this.pushToast('Đã cấp quyền thông báo dịch vụ nền.', 'success');
      } else {
        this.pushToast('Chưa cấp quyền thông báo trên Android.', 'error');
      }
    } catch (err) {
      this.pushToast(String(err), 'error');
    }
  }
}

export const store = new RustatioStore();
