<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import BottomNav from './components/BottomNav.svelte';
  import PresetsView from './components/PresetsView.svelte';
  import SessionsView from './components/SessionsView.svelte';
  import SettingsView from './components/SettingsView.svelte';
  import ToastHost from './components/ToastHost.svelte';
  import { store } from './lib/store.svelte';

  onMount(() => {
    void store.init();
  });

  onDestroy(() => {
    store.destroy();
  });
</script>

<main class="app-shell">
  {#if store.activeTab === 'sessions'}
    <SessionsView />
  {:else if store.activeTab === 'presets'}
    <PresetsView />
  {:else}
    <SettingsView />
  {/if}
</main>

<ToastHost />
<BottomNav />

<style>
  .app-shell {
    width: 100%;
    max-width: 640px;
    margin: 0 auto;
    padding: calc(14px + var(--safe-top)) 14px calc(var(--nav-height) + var(--safe-bottom) + 20px);
    flex: 1;
  }
</style>
