#![cfg_attr(all(not(debug_assertions), target_os = "windows"), windows_subsystem = "windows")]

mod commands;
mod logging;
mod persistence;
mod presets;
mod scheduler;
mod state;
mod watch;
#[cfg(test)]
mod watch_tests;

use async_trait::async_trait;
use rustatio_core::{
    AppConfig, FakerState, PeerCatalog, PeerListenerService, PeerListenerStatus, PeerLookup,
    RatioFaker, RatioFakerHandle,
};
use rustatio_watch::InstanceSource;
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use tauri::{Emitter, Manager, RunEvent};
use tokio::sync::RwLock;

use logging::log_and_emit;
use state::{build_summary, AppState, FakerInstance};

#[derive(Clone)]
struct DesktopPeerLookup {
    fakers: Arc<RwLock<HashMap<u32, FakerInstance>>>,
}

#[async_trait]
impl PeerLookup for DesktopPeerLookup {
    async fn snapshot(&self) -> PeerCatalog {
        let guard = self.fakers.read().await;
        let mut out = PeerCatalog::new();
        for instance in guard.values() {
            out.entry(instance.torrent.info_hash)
                .and_modify(|entry| {
                    *entry = Err("duplicate active instances for info_hash".to_string());
                })
                .or_insert_with(|| Ok(Arc::clone(&instance.faker)));
        }
        out
    }
}

/// Synchronous save for the exit handler (tokio runtime may be winding down)
fn save_state_sync(state: &AppState) {
    let persisted = state.build_persisted_state_blocking();
    match persistence::save_state(&persisted) {
        Ok(()) => log::info!("Final state saved successfully"),
        Err(e) => log::error!("Exit save failed: {e}"),
    }
}

fn save_state_blocking(state: &AppState) {
    let rt = tokio::runtime::Handle::current();
    let cloned = state.clone();
    if let Err(e) = rt.block_on(async move { cloned.save_state().await }) {
        log::error!("Periodic save failed: {e}");
    }
}

async fn restore_saved_instances(
    app_handle: tauri::AppHandle,
    state: AppState,
    saved_instances: HashMap<u32, persistence::PersistedInstance>,
    watch_auto_start: bool,
) {
    let mut auto_start_ids: Vec<u32> = Vec::new();
    let mut recovered_interrupted = 0u32;

    for (id, persisted) in &saved_instances {
        let mut config = persisted.config.clone();
        config.initial_uploaded = persisted.cumulative_uploaded;
        config.initial_downloaded = persisted.cumulative_downloaded;

        let summary = Arc::new(persisted.torrent.clone());
        let torrent = Arc::new(persisted.torrent.to_info());

        match RatioFaker::new(Arc::clone(&torrent), config, Some(state.http_client().await)) {
            Ok(faker) => {
                let was_running =
                    matches!(persisted.state, FakerState::Starting | FakerState::Running);
                let source = if persisted.from_watch_folder {
                    InstanceSource::WatchFolder
                } else {
                    InstanceSource::Manual
                };

                state.fakers.write().await.insert(
                    *id,
                    FakerInstance {
                        faker: Arc::new(RatioFakerHandle::new(faker)),
                        torrent,
                        summary,
                        config: persisted.config.clone(),
                        cumulative_uploaded: persisted.cumulative_uploaded,
                        cumulative_downloaded: persisted.cumulative_downloaded,
                        tags: persisted.tags.clone(),
                        created_at: persisted.created_at,
                        source,
                    },
                );

                let _ = app_handle.emit("instance-restored", *id);

                if was_running && matches!(source, InstanceSource::WatchFolder) && watch_auto_start
                {
                    auto_start_ids.push(*id);
                } else if was_running {
                    recovered_interrupted = recovered_interrupted.saturating_add(1);
                }

                log_and_emit!(
                    &app_handle,
                    *id,
                    info,
                    "Restored instance: {}",
                    persisted.torrent.name
                );
            }
            Err(e) => {
                log_and_emit!(&app_handle, error, "Failed to restore instance {}: {}", id, e);
            }
        }
    }

    if !saved_instances.is_empty() {
        log_and_emit!(
            &app_handle,
            info,
            "Restored {} instance(s), {} to auto-start",
            saved_instances.len(),
            auto_start_ids.len()
        );
    }

    if recovered_interrupted > 0 {
        let _ = app_handle.emit("sessions-recovered", recovered_interrupted);
    }

    for id in &auto_start_ids {
        let faker = {
            let fakers = state.fakers.read().await;
            match fakers.get(id) {
                Some(instance) => Arc::clone(&instance.faker),
                None => continue,
            }
        };

        match faker.start().await {
            Ok(()) => {
                log_and_emit!(&app_handle, *id, info, "Auto-started (was running before shutdown)");
            }
            Err(e) => {
                log_and_emit!(&app_handle, *id, error, "Auto-start failed: {}", e);
            }
        };
    }

    let mut summaries = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .map(|(id, inst)| inst.faker.with_stats(|stats| build_summary(*id, inst, stats)))
            .collect::<Vec<_>>()
    };
    summaries.sort_by_key(|s| s.id.parse::<u32>().unwrap_or(0));
    let _ = app_handle.emit("instance-summaries", summaries);

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app_handle).await;
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn show_exit_prompt(app: &tauri::AppHandle, prompt_open: &Arc<AtomicBool>) {
    if prompt_open.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire).is_err() {
        return;
    }

    if let Some(window) = app.get_webview_window("main") {
        ensure_window_interactive(&window);
        let _ = window.emit("app-close-requested", ());
        let _ = window.show();
        let _ = window.unminimize();
        let _ = window.set_focus();
    } else {
        prompt_open.store(false, Ordering::Relaxed);
    }
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn toggle_main_window(app: &tauri::AppHandle) {
    let Some(window) = app.get_webview_window("main") else {
        return;
    };

    let is_visible = window.is_visible().unwrap_or(true);
    if is_visible {
        let _ = window.hide();
    } else {
        let _ = window.show();
        let _ = window.unminimize();
        ensure_window_interactive(&window);
        let _ = window.set_focus();
    }
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn ensure_window_interactive(window: &tauri::WebviewWindow) {
    let _ = window.set_enabled(true);
    let _ = window.set_closable(true);
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn handle_tray_menu_event(app: &tauri::AppHandle, id: &str, should_exit: &AtomicBool) {
    match id {
        "tray-show" => toggle_main_window(app),
        "tray-quit" => {
            should_exit.store(true, Ordering::Relaxed);
            app.exit(0);
        }
        _ => {}
    }
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn handle_tray_icon_event(app: &tauri::AppHandle, event: &tauri::tray::TrayIconEvent) {
    if let tauri::tray::TrayIconEvent::Click {
        button: tauri::tray::MouseButton::Left,
        button_state: tauri::tray::MouseButtonState::Up,
        ..
    } = event
    {
        toggle_main_window(app);
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let _ = env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .try_init();

    log::info!("Starting Rustatio v{} (Tauri 2)", env!("CARGO_PKG_VERSION"));

    let should_exit = Arc::new(AtomicBool::new(false));
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    let close_prompt_open = Arc::new(AtomicBool::new(false));
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    let should_exit_for_tray = Arc::clone(&should_exit);

    let builder = tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_os::init())
        .plugin(tauri_plugin_rustatio_android::init());

    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    let builder = builder
        .plugin(tauri_plugin_updater::Builder::new().build())
        .plugin(tauri_plugin_process::init());

    let app_setup_should_exit = Arc::clone(&should_exit);

    let builder = builder
        .invoke_handler(tauri::generate_handler![
            commands::create_instance,
            commands::import_torrent_bytes,
            commands::delete_instance,
            commands::list_instances,
            commands::load_torrent,
            commands::load_instance_torrent,
            commands::get_instance_torrent,
            commands::get_instance_summary,
            commands::update_instance_config,
            commands::get_config,
            commands::update_config,
            commands::set_dark_mode,
            commands::start_faker,
            commands::stop_faker,
            commands::update_faker,
            commands::announce_now,
            commands::update_stats_only,
            commands::get_stats,
            commands::scrape_tracker,
            commands::pause_faker,
            commands::resume_faker,
            commands::recover_tracker_faker,
            commands::start_all_fakers,
            commands::pause_all_fakers,
            commands::stop_all_fakers,
            commands::get_client_types,
            commands::get_client_infos,
            commands::get_target_os_infos,
            commands::get_network_status,
            commands::get_proxy_settings,
            commands::set_proxy_settings,
            commands::test_proxy,
            commands::write_file,
            commands::set_log_level,
            commands::detect_linux_package_type,
            commands::grid_import_folder,
            commands::grid_import_files,
            commands::grid_start,
            commands::grid_stop,
            commands::grid_pause,
            commands::grid_resume,
            commands::grid_delete,
            commands::grid_update_config,
            commands::bulk_update_configs,
            commands::grid_tag,
            commands::set_instance_tags,
            commands::list_summaries,
            commands::get_watch_status,
            commands::list_watch_files,
            commands::delete_watch_file,
            commands::reload_watch_file,
            commands::reload_all_watch_files,
            commands::get_watch_config,
            commands::set_watch_config,
            commands::get_default_config,
            commands::set_default_config,
            commands::clear_default_config,
            commands::close_to_tray,
            commands::quit_app,
            commands::cancel_close_prompt,
            commands::list_presets,
            commands::save_preset,
            commands::duplicate_preset,
            commands::delete_preset,
            commands::set_default_preset,
            commands::apply_preset,
            commands::import_presets_json,
            commands::export_presets_json,
            commands::pick_torrent_file,
            commands::request_notification_permission,
            commands::get_foreground_service_status,
            commands::sync_foreground_service,
            commands::share_or_save_json,
        ])
        .setup(move |app| {
            rustatio_core::logger::init_logger(app.handle().clone());

            if let Ok(app_data_dir) = app.path().app_data_dir() {
                if let Err(err) = std::fs::create_dir_all(&app_data_dir) {
                    log::warn!("Failed to create app data dir {}: {err}", app_data_dir.display());
                } else {
                    log::info!("Resolved app data dir: {}", app_data_dir.display());
                    persistence::set_app_data_dir(Some(app_data_dir));
                }
            }

            let config = AppConfig::load_or_default_at(&persistence::config_file_path());
            let saved_state = persistence::load_state();
            let mut presets_file = presets::load_presets_file();
            if presets_file.active_preset_id.is_none() {
                presets_file.active_preset_id = saved_state.active_preset_id.clone();
            }
            if presets_file.default_preset_id.is_none() {
                presets_file.default_preset_id = saved_state.default_preset_id.clone();
            }

            let next_id = saved_state.next_instance_id.max(1);
            let saved_instances_map = saved_state.instances;
            let saved_default_config = saved_state
                .default_config
                .or_else(|| presets::default_faker_config_from_presets(&presets_file));
            let saved_watch_settings = saved_state.watch_settings;
            let saved_proxy_settings = saved_state.proxy_settings;

            let mut initial_http_client = rustatio_core::proxy::build_client(None).unwrap_or_default();
            let mut initial_proxy_settings = None;

            if let Some(settings) = saved_proxy_settings {
                match rustatio_core::proxy::build_client(Some(&settings)) {
                    Ok(client) => {
                        initial_http_client = client;
                        initial_proxy_settings = Some(settings);
                    }
                    Err(err) => log::warn!("Ignoring invalid saved proxy settings: {err}"),
                }
            }

            let app_state = AppState {
                fakers: Arc::new(RwLock::new(HashMap::new())),
                next_instance_id: Arc::new(RwLock::new(next_id)),
                config: Arc::new(RwLock::new(config)),
                http_client: Arc::new(RwLock::new(initial_http_client)),
                proxy_settings: Arc::new(RwLock::new(initial_proxy_settings)),
                watch: Arc::new(RwLock::new(None)),
                default_config: Arc::new(RwLock::new(saved_default_config)),
                watch_settings: Arc::new(RwLock::new(saved_watch_settings)),
                should_exit: Arc::clone(&app_setup_should_exit),
                close_prompt_open: Arc::new(AtomicBool::new(false)),
                peer_listener: Arc::new(RwLock::new(None)),
                peer_listener_status: Arc::new(RwLock::new(PeerListenerStatus::default())),
                presets: Arc::new(RwLock::new(presets_file)),
            };

            app.manage(app_state.clone());

            #[cfg(not(any(target_os = "android", target_os = "ios")))]
            {
                use tauri::menu::{Menu, MenuItem};
                use tauri::tray::TrayIconBuilder;

                let show_item =
                    MenuItem::with_id(app, "tray-show", "Show/Hide", true, None::<&str>)?;
                let quit_item = MenuItem::with_id(app, "tray-quit", "Quit", true, None::<&str>)?;
                let menu = Menu::with_items(app, &[&show_item, &quit_item])?;
                let menu_state = Arc::clone(&should_exit_for_tray);

                if let Some(icon) = app.default_window_icon().cloned() {
                    let tray_icon = TrayIconBuilder::with_id("main-tray")
                        .menu(&menu)
                        .show_menu_on_left_click(false)
                        .on_menu_event(move |app, event| {
                            handle_tray_menu_event(app, event.id().as_ref(), &menu_state);
                        })
                        .on_tray_icon_event(|tray, event| {
                            handle_tray_icon_event(tray.app_handle(), &event);
                        })
                        .icon(icon)
                        .tooltip("Rustatio")
                        .build(app)?;
                    let _ = tray_icon;
                }
            }

            let app_handle = app.handle().clone();
            let state_inner = app_state;
            let peer_lookup = DesktopPeerLookup { fakers: Arc::clone(&state_inner.fakers) };
            let peer_listener_store = Arc::clone(&state_inner.peer_listener_status);
            let peer_listener_rx = {
                let state_ref = &state_inner;
                tauri::async_runtime::block_on(async {
                    let mut peer_listener = PeerListenerService::new();
                    peer_listener.start(Arc::new(peer_lookup));
                    let status_rx = peer_listener.subscribe();
                    let peer_listener = Arc::new(tokio::sync::Mutex::new(peer_listener));
                    state_ref.attach_peer_listener(Arc::clone(&peer_listener)).await;
                    status_rx
                })
            };
            tauri::async_runtime::spawn(async move {
                let mut rx = peer_listener_rx;
                while rx.changed().await.is_ok() {
                    let status = rx.borrow().clone();
                    *peer_listener_store.write().await = status;
                }
            });

            let watch_settings =
                state_inner.watch_settings.try_read().ok().and_then(|guard| guard.clone());
            let watch_auto_start = watch_settings.as_ref().is_some_and(|w| w.auto_start);

            let scheduler_state = state_inner.clone();
            let state_for_save = state_inner.clone();
            tauri::async_runtime::spawn(async move {
                restore_saved_instances(
                    app_handle.clone(),
                    state_inner.clone(),
                    saved_instances_map,
                    watch_auto_start,
                )
                .await;

                #[cfg(not(any(target_os = "android", target_os = "ios")))]
                {
                    let default_config = Arc::clone(&state_inner.default_config);
                    let watch_state = Arc::clone(&state_inner.watch);
                    let mut watch =
                        watch::build_watch_service(state_inner, default_config, watch_settings);
                    if let Err(e) = watch.start().await {
                        log::error!("Failed to start watch service: {e}");
                    }
                    let mut watch_guard = watch_state.write().await;
                    *watch_guard = Some(watch);
                }

                #[cfg(any(target_os = "android", target_os = "ios"))]
                let _ = watch_settings;

                scheduler::spawn(scheduler_state, app_handle);
            });

            tauri::async_runtime::spawn(async move {
                loop {
                    tokio::time::sleep(std::time::Duration::from_secs(30)).await;
                    let state_snapshot = state_for_save.clone();
                    let _ = tokio::task::spawn_blocking(move || save_state_blocking(&state_snapshot)).await;
                }
            });

            Ok(())
        });

    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    let builder = builder.on_window_event(move |window, event| {
        if let tauri::WindowEvent::CloseRequested { api, .. } = event {
            if should_exit.load(Ordering::Relaxed) {
                return;
            }
            api.prevent_close();
            show_exit_prompt(window.app_handle(), &close_prompt_open);
        }
    });

    #[cfg(any(target_os = "android", target_os = "ios"))]
    let _ = should_exit;

    let app = builder
        .build(tauri::generate_context!())
        .expect("error while building tauri application");

    app.run(move |app_handle, event| {
        if matches!(event, RunEvent::Exit) {
            log::info!("Application exiting, saving final state...");
            if let Some(state) = app_handle.try_state::<AppState>() {
                save_state_sync(state.inner());
            }
        }
    });
}
