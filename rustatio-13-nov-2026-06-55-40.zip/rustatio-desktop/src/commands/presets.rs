use rustatio_core::{FakerConfig, FakerState, RatioFaker};
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use tauri::{AppHandle, Emitter, State};

use crate::persistence;
use crate::presets::{
    self, build_list_response, export_presets_to_json, find_preset, parse_import_json,
    save_presets_file, validate_preset_settings, ImportPresetsResponse, PresetItem,
    PresetListResponse, SavePresetRequest,
};
use crate::state::{build_summary, AppState};

static PRESET_ID_COUNTER: AtomicU64 = AtomicU64::new(1);

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ApplyPresetResponse {
    pub list: PresetListResponse,
    pub applied_instances: usize,
    pub skipped_running: usize,
}

#[tauri::command]
pub async fn list_presets(state: State<'_, AppState>) -> Result<PresetListResponse, String> {
    let guard = state.presets.read().await;
    Ok(build_list_response(&guard))
}

#[tauri::command]
pub async fn save_preset(
    request: SavePresetRequest,
    state: State<'_, AppState>,
) -> Result<PresetItem, String> {
    let trimmed_name = request.name.trim().to_string();
    validate_preset_settings(&trimmed_name, &request.settings)?;

    if let Some(ref existing_id) = request.id {
        if presets::built_in_presets().iter().any(|p| p.id == *existing_id) {
            return Err("Không thể sửa trực tiếp Preset tích hợp. Hãy nhân bản để tùy chỉnh.".to_string());
        }
    }

    let now_str = persistence::now_timestamp().to_string();
    let mut presets_guard = state.presets.write().await;

    let saved_item = if let Some(ref id) = request.id {
        if let Some(existing) = presets_guard.custom_presets.iter_mut().find(|p| p.id == *id) {
            existing.name = trimmed_name;
            existing.description = request.description.trim().to_string();
            existing.icon = if request.icon.trim().is_empty() {
                "sliders".to_string()
            } else {
                request.icon.trim().to_string()
            };
            existing.settings = request.settings;
            existing.clone()
        } else {
            let item = PresetItem {
                id: id.clone(),
                name: trimmed_name,
                description: request.description.trim().to_string(),
                icon: if request.icon.trim().is_empty() {
                    "sliders".to_string()
                } else {
                    request.icon.trim().to_string()
                },
                recommended: false,
                built_in: false,
                is_default: false,
                is_active: false,
                settings: request.settings,
                tips: vec![],
                created_at: Some(now_str),
            };
            presets_guard.custom_presets.push(item.clone());
            item
        }
    } else {
        let counter = PRESET_ID_COUNTER.fetch_add(1, Ordering::Relaxed);
        let generated_id = format!("custom-{}-{counter}", persistence::now_timestamp());
        let item = PresetItem {
            id: generated_id,
            name: trimmed_name,
            description: request.description.trim().to_string(),
            icon: if request.icon.trim().is_empty() {
                "sliders".to_string()
            } else {
                request.icon.trim().to_string()
            },
            recommended: false,
            built_in: false,
            is_default: false,
            is_active: false,
            settings: request.settings,
            tips: vec![],
            created_at: Some(now_str),
        };
        presets_guard.custom_presets.push(item.clone());
        item
    };

    save_presets_file(&presets_guard)?;
    drop(presets_guard);

    Ok(saved_item)
}

#[tauri::command]
pub async fn duplicate_preset(
    id: String,
    state: State<'_, AppState>,
) -> Result<PresetItem, String> {
    let mut presets_guard = state.presets.write().await;
    let source = find_preset(&presets_guard, &id)
        .ok_or_else(|| format!("Không tìm thấy Preset '{id}'."))?;

    let counter = PRESET_ID_COUNTER.fetch_add(1, Ordering::Relaxed);
    let new_id = format!("custom-{}-{counter}", persistence::now_timestamp());
    let copy = PresetItem {
        id: new_id,
        name: format!("{} (Bản sao)", source.name),
        description: source.description,
        icon: source.icon,
        recommended: false,
        built_in: false,
        is_default: false,
        is_active: false,
        settings: source.settings,
        tips: vec![],
        created_at: Some(persistence::now_timestamp().to_string()),
    };

    presets_guard.custom_presets.push(copy.clone());
    save_presets_file(&presets_guard)?;
    drop(presets_guard);

    Ok(copy)
}

#[tauri::command]
pub async fn delete_preset(
    id: String,
    state: State<'_, AppState>,
) -> Result<PresetListResponse, String> {
    if presets::built_in_presets().iter().any(|p| p.id == id) {
        return Err("Không thể xóa Preset tích hợp.".to_string());
    }

    let mut presets_guard = state.presets.write().await;
    let before_len = presets_guard.custom_presets.len();
    presets_guard.custom_presets.retain(|p| p.id != id);
    if presets_guard.custom_presets.len() == before_len {
        return Err(format!("Không tìm thấy Preset '{id}'."));
    }

    if presets_guard.default_preset_id.as_deref() == Some(id.as_str()) {
        presets_guard.default_preset_id = Some("balanced".to_string());
    }
    if presets_guard.active_preset_id.as_deref() == Some(id.as_str()) {
        presets_guard.active_preset_id = presets_guard.default_preset_id.clone();
    }

    save_presets_file(&presets_guard)?;
    let response = build_list_response(&presets_guard);
    let default_cfg = presets::default_faker_config_from_presets(&presets_guard);
    drop(presets_guard);

    *state.default_config.write().await = default_cfg;
    state.save_state().await?;
    Ok(response)
}

#[tauri::command]
pub async fn set_default_preset(
    id: String,
    state: State<'_, AppState>,
) -> Result<PresetListResponse, String> {
    let mut presets_guard = state.presets.write().await;
    let preset = find_preset(&presets_guard, &id)
        .ok_or_else(|| format!("Không tìm thấy Preset '{id}'."))?;

    presets_guard.default_preset_id = Some(id);
    if presets_guard.active_preset_id.is_none() {
        presets_guard.active_preset_id = presets_guard.default_preset_id.clone();
    }

    save_presets_file(&presets_guard)?;
    let response = build_list_response(&presets_guard);
    drop(presets_guard);

    *state.default_config.write().await = Some(FakerConfig::from(preset.settings));
    state.save_state().await?;
    Ok(response)
}

#[tauri::command]
pub async fn apply_preset(
    id: String,
    instance_id: Option<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<ApplyPresetResponse, String> {
    let preset = {
        let mut presets_guard = state.presets.write().await;
        let found = find_preset(&presets_guard, &id)
            .ok_or_else(|| format!("Không tìm thấy Preset '{id}'."))?;
        presets_guard.active_preset_id = Some(id);
        save_presets_file(&presets_guard)?;
        found
    };

    let global_cfg = state.config.read().await.clone();
    let mut base_config = FakerConfig::from(preset.settings.clone());
    if preset.settings.selected_client.is_none() {
        base_config.client_type = global_cfg.client.default_type;
        base_config.client_version = global_cfg.client.default_version.clone();
    }
    if preset.settings.target_os.is_none() {
        base_config.target_os = global_cfg.client.target_os;
    }
    if preset.settings.port.is_none() {
        base_config.port = global_cfg.client.default_port;
    }
    base_config.num_want = global_cfg.client.default_num_want;

    *state.default_config.write().await = Some(base_config.clone());

    let http_client = state.http_client().await;
    let mut applied_instances = 0usize;
    let mut skipped_running = 0usize;

    {
        let mut fakers = state.fakers.write().await;
        if let Some(target_id) = instance_id {
            let instance = fakers
                .get_mut(&target_id)
                .ok_or_else(|| format!("Không tìm thấy phiên #{target_id}."))?;
            let status = instance.faker.stats_snapshot().state;
            if matches!(status, FakerState::Running | FakerState::Starting | FakerState::Paused) {
                return Err("Không thể áp dụng Preset khi phiên đang chạy. Hãy dừng phiên trước.".to_string());
            }
            let mut next_cfg = base_config.clone();
            next_cfg.initial_uploaded = instance.cumulative_uploaded;
            next_cfg.initial_downloaded = instance.cumulative_downloaded;
            let faker = RatioFaker::new(
                Arc::clone(&instance.torrent),
                next_cfg.clone(),
                Some(http_client.clone()),
            )
            .map_err(|e| format!("Không thể khởi tạo lại engine: {e}"))?;
            instance.faker = Arc::new(rustatio_core::RatioFakerHandle::new(faker));
            instance.config = next_cfg;
            applied_instances = 1;
        } else {
            for instance in fakers.values_mut() {
                let status = instance.faker.stats_snapshot().state;
                if matches!(status, FakerState::Running | FakerState::Starting | FakerState::Paused) {
                    skipped_running = skipped_running.saturating_add(1);
                    continue;
                }
                let mut next_cfg = base_config.clone();
                next_cfg.initial_uploaded = instance.cumulative_uploaded;
                next_cfg.initial_downloaded = instance.cumulative_downloaded;
                let faker = RatioFaker::new(
                    Arc::clone(&instance.torrent),
                    next_cfg.clone(),
                    Some(http_client.clone()),
                )
                .map_err(|e| format!("Không thể áp dụng Preset: {e}"))?;
                instance.faker = Arc::new(rustatio_core::RatioFakerHandle::new(faker));
                instance.config = next_cfg;
                applied_instances = applied_instances.saturating_add(1);
            }
        }
    }

    state.save_state().await?;

    let summaries = {
        let fakers = state.fakers.read().await;
        let mut list = fakers
            .iter()
            .map(|(fid, inst)| inst.faker.with_stats(|stats| build_summary(*fid, inst, stats)))
            .collect::<Vec<_>>();
        list.sort_by_key(|s| s.id.parse::<u32>().unwrap_or(0));
        list
    };
    let _ = app.emit("instance-summaries", summaries);

    let list = build_list_response(&*state.presets.read().await);
    Ok(ApplyPresetResponse { list, applied_instances, skipped_running })
}

#[tauri::command]
pub async fn import_presets_json(
    raw_json: String,
    state: State<'_, AppState>,
) -> Result<ImportPresetsResponse, String> {
    let parsed = parse_import_json(&raw_json)?;
    let now_str = persistence::now_timestamp().to_string();

    let mut presets_guard = state.presets.write().await;
    let mut imported_count = 0usize;

    for req in parsed {
        let counter = PRESET_ID_COUNTER.fetch_add(1, Ordering::Relaxed);
        let id = format!("custom-{}-{counter}", persistence::now_timestamp());
        let item = PresetItem {
            id,
            name: req.name,
            description: req.description,
            icon: if req.icon.trim().is_empty() { "sliders".to_string() } else { req.icon },
            recommended: false,
            built_in: false,
            is_default: false,
            is_active: false,
            settings: req.settings,
            tips: vec![],
            created_at: Some(now_str.clone()),
        };
        presets_guard.custom_presets.push(item);
        imported_count = imported_count.saturating_add(1);
    }

    save_presets_file(&presets_guard)?;
    let response = build_list_response(&presets_guard);
    drop(presets_guard);

    Ok(ImportPresetsResponse { imported_count, presets: response.presets })
}

#[tauri::command]
pub async fn export_presets_json(
    preset_id: Option<String>,
    state: State<'_, AppState>,
) -> Result<String, String> {
    let presets_guard = state.presets.read().await;
    export_presets_to_json(&presets_guard, preset_id.as_deref())
}
