use base64::Engine as _;
use rustatio_core::validation;
use rustatio_core::{FakerConfig, RatioFaker, RatioFakerHandle, TorrentInfo, TorrentSummary};
use rustatio_watch::InstanceSource;
use std::sync::Arc;
use tauri::{AppHandle, Emitter, State};

use crate::logging::log_and_emit;
use crate::presets;
use crate::state::{build_summary, AppState, FakerInstance, InstanceInfo};

#[tauri::command]
pub async fn create_instance(state: State<'_, AppState>, app: AppHandle) -> Result<u32, String> {
    let mut next_id = state.next_instance_id.write().await;
    let instance_id = *next_id;
    *next_id += 1;

    log_and_emit!(&app, info, "Created instance {}", instance_id);
    Ok(instance_id)
}

#[tauri::command]
pub async fn import_torrent_bytes(
    name: String,
    bytes_base64: String,
    auto_start: Option<bool>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<InstanceInfo, String> {
    let raw_bytes = base64::engine::general_purpose::STANDARD
        .decode(bytes_base64.trim())
        .map_err(|e| format!("Dữ liệu tệp .torrent không hợp lệ: {e}"))?;

    let torrent = TorrentInfo::from_bytes_summary(&raw_bytes)
        .map_err(|e| format!("Không thể đọc tệp .torrent '{name}': {e}"))?;

    {
        let fakers = state.fakers.read().await;
        if fakers.values().any(|instance| instance.torrent.info_hash == torrent.info_hash) {
            return Err("Torrent này đã tồn tại trong danh sách phiên.".to_string());
        }
    }

    let global_cfg = state.config.read().await.clone();
    let mut config = {
        let presets_guard = state.presets.read().await;
        let preset_cfg = presets::default_faker_config_from_presets(&presets_guard);
        preset_cfg.unwrap_or_else(|| FakerConfig {
            upload_rate: global_cfg.faker.default_upload_rate,
            download_rate: global_cfg.faker.default_download_rate,
            update_interval_seconds: global_cfg.faker.update_interval,
            ..FakerConfig::default()
        })
    };

    config.client_type = global_cfg.client.default_type;
    config.client_version = global_cfg.client.default_version.clone();
    config.target_os = global_cfg.client.target_os;
    config.port = global_cfg.client.default_port;
    config.num_want = global_cfg.client.default_num_want;

    let instance_id = {
        let mut next_id = state.next_instance_id.write().await;
        let id = *next_id;
        *next_id = id.saturating_add(1);
        id
    };

    let torrent_arc = Arc::new(torrent.without_files());
    let summary_arc = Arc::new(torrent_arc.summary());
    let http_client = state.http_client().await;
    let faker = RatioFaker::new(Arc::clone(&torrent_arc), config.clone(), Some(http_client))
        .map_err(|e| format!("Không thể khởi tạo phiên: {e}"))?;
    let faker_handle = Arc::new(RatioFakerHandle::new(faker));

    let now = crate::state::now_secs();
    {
        let mut fakers = state.fakers.write().await;
        fakers.insert(
            instance_id,
            FakerInstance {
                faker: Arc::clone(&faker_handle),
                torrent: Arc::clone(&torrent_arc),
                summary: Arc::clone(&summary_arc),
                config: config.clone(),
                cumulative_uploaded: 0,
                cumulative_downloaded: 0,
                tags: vec![],
                created_at: now,
                source: InstanceSource::Manual,
            },
        );
    }

    if auto_start.unwrap_or(false) {
        if let Err(err) = faker_handle.start().await {
            log_and_emit!(&app, instance_id, warn, "Auto-start failed: {}", err);
        }
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    state.save_state().await?;

    let stats = faker_handle.stats_snapshot();
    let info = InstanceInfo {
        id: instance_id.to_string(),
        torrent: (*summary_arc).clone(),
        config,
        stats,
        created_at: now,
        source: "manual".to_string(),
        tags: vec![],
    };

    let summaries = {
        let fakers = state.fakers.read().await;
        let mut list = fakers
            .iter()
            .map(|(id, inst)| inst.faker.with_stats(|s| build_summary(*id, inst, s)))
            .collect::<Vec<_>>();
        list.sort_by_key(|s| s.id.parse::<u32>().unwrap_or(0));
        list
    };
    let _ = app.emit("instance-summaries", summaries);
    log_and_emit!(&app, instance_id, info, "Imported torrent from SAF: {}", torrent_arc.name);

    Ok(info)
}

#[tauri::command]
pub async fn update_instance_config(
    instance_id: u32,
    config: FakerConfig,
    state: State<'_, AppState>,
) -> Result<(), String> {
    state.apply_instance_config(instance_id, config).await
}

#[tauri::command]
pub async fn delete_instance(
    instance_id: u32,
    force: Option<bool>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    let is_forced = force.unwrap_or(false);

    if let Some(instance) = state.fakers.read().await.get(&instance_id) {
        if matches!(instance.source, InstanceSource::WatchFolder) && !is_forced {
            return Err(
                "Cannot delete watch folder instance. Delete the torrent file from the watch folder instead."
                    .to_string(),
            );
        }
    }

    // Remove from HashMap first, then stop — HTTP happens after lock is released
    let removed = {
        let mut fakers = state.fakers.write().await;
        fakers.remove(&instance_id)
    };

    if let Some(instance) = removed {
        if is_forced && matches!(instance.source, InstanceSource::WatchFolder) {
            let info_hash = instance.summary.info_hash;
            let watch_guard = state.watch.read().await;
            if let Some(watch) = watch_guard.as_ref() {
                watch.remove_info_hash(&info_hash).await;
            }
        }

        if let Err(e) = instance.faker.stop().await {
            log_and_emit!(&app, warn, "Error stopping faker on delete: {}", e);
        }
        log_and_emit!(&app, info, "Deleted instance {}", instance_id);
    } else {
        log::info!("Deleted instance {instance_id} (was not started)");
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    state.save_state().await?;
    let _ = app.emit("instance-deleted", instance_id.to_string());

    Ok(())
}

#[tauri::command]
pub async fn list_instances(state: State<'_, AppState>) -> Result<Vec<InstanceInfo>, String> {
    let fakers = state.fakers.read().await;

    let mut instances: Vec<InstanceInfo> = vec![];
    for (id, instance) in fakers.iter() {
        let stats = instance.faker.stats_snapshot();
        instances.push(InstanceInfo {
            id: id.to_string(),
            torrent: (*instance.summary).clone(),
            config: instance.config.clone(),
            stats,
            created_at: instance.created_at,
            source: match instance.source {
                InstanceSource::Manual => "manual".to_string(),
                InstanceSource::WatchFolder => "watch_folder".to_string(),
            },
            tags: instance.tags.clone(),
        });
    }

    instances.sort_by_key(|i| i.id.parse::<u32>().unwrap_or(0));
    Ok(instances)
}

#[tauri::command]
pub async fn load_torrent(path: String, app: AppHandle) -> Result<TorrentInfo, String> {
    let validated_path = validation::validate_torrent_path(&path).map_err(|e| {
        let error_msg = format!("Invalid torrent path: {e}");
        log_and_emit!(&app, error, "{}", error_msg);
        error_msg
    })?;

    log_and_emit!(&app, info, "Loading torrent from: {}", validated_path.display());

    match TorrentInfo::from_file_summary(validated_path.to_str().unwrap_or(&path)) {
        Ok(torrent) => {
            log_and_emit!(
                &app,
                info,
                "Torrent loaded: {} ({} bytes)",
                torrent.name,
                torrent.total_size
            );
            Ok(torrent)
        }
        Err(e) => {
            let error_msg = format!("Failed to load torrent: {e}");
            log_and_emit!(&app, error, "{}", error_msg);
            Err(error_msg)
        }
    }
}

#[tauri::command]
pub async fn load_instance_torrent(
    instance_id: u32,
    path: String,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<TorrentInfo, String> {
    let validated_path = validation::validate_torrent_path(&path).map_err(|e| {
        let error_msg = format!("Invalid torrent path: {e}");
        log_and_emit!(&app, error, "{}", error_msg);
        error_msg
    })?;

    let torrent = TorrentInfo::from_file_summary(validated_path.to_str().unwrap_or(&path))
        .map_err(|e| {
            let error_msg = format!("Failed to load torrent: {e}");
            log_and_emit!(&app, error, "{}", error_msg);
            error_msg
        })?;

    log_and_emit!(
        &app,
        instance_id,
        info,
        "Loaded torrent: {} ({} bytes)",
        torrent.name,
        torrent.total_size
    );

    let mut fakers = state.fakers.write().await;
    if fakers
        .iter()
        .any(|(id, instance)| *id != instance_id && instance.torrent.info_hash == torrent.info_hash)
    {
        return Err("Duplicate torrent skipped: already imported".to_string());
    }
    let response_torrent = torrent.clone();
    let torrent_arc = Arc::new(torrent.without_files());
    let summary_arc = Arc::new(torrent_arc.summary());
    match fakers.entry(instance_id) {
        std::collections::hash_map::Entry::Vacant(entry) => {
            let config = FakerConfig::default();
            let faker = RatioFaker::new(
                Arc::clone(&torrent_arc),
                config.clone(),
                Some(state.http_client().await),
            )
            .map_err(|e| format!("Failed to create faker: {e}"))?;

            let now = crate::state::now_secs();

            entry.insert(FakerInstance {
                faker: Arc::new(RatioFakerHandle::new(faker)),
                torrent: torrent_arc,
                summary: summary_arc,
                config,
                cumulative_uploaded: 0,
                cumulative_downloaded: 0,
                tags: vec![],
                created_at: now,
                source: InstanceSource::Manual,
            });
        }
        std::collections::hash_map::Entry::Occupied(mut entry) => {
            let instance = entry.get_mut();
            let config = instance.config.clone();
            let faker =
                RatioFaker::new(Arc::clone(&torrent_arc), config, Some(state.http_client().await))
                    .map_err(|e| format!("Failed to create faker: {e}"))?;
            instance.torrent = torrent_arc;
            instance.summary = summary_arc;
            instance.faker = Arc::new(RatioFakerHandle::new(faker));
            instance.source = InstanceSource::Manual;
        }
    }
    drop(fakers);
    let _ = state.save_state().await;
    Ok(response_torrent)
}

#[tauri::command]
pub async fn get_instance_torrent(
    instance_id: u32,
    state: State<'_, AppState>,
) -> Result<TorrentInfo, String> {
    let fakers = state.fakers.read().await;
    let instance =
        fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
    Ok((*instance.torrent).clone())
}

#[tauri::command]
pub async fn get_instance_summary(
    instance_id: u32,
    state: State<'_, AppState>,
) -> Result<TorrentSummary, String> {
    let fakers = state.fakers.read().await;
    let instance =
        fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
    Ok((*instance.summary).clone())
}
