use rustatio_core::{validation, FakerState, RatioFaker, RatioFakerHandle};
use rustatio_core::{AppConfig, ClientInfo, ClientType, TargetOs, TargetOsInfo};
use std::sync::Arc;
use tauri::{AppHandle, Emitter, State};

use crate::persistence;
use crate::state::{build_summary, AppState};

#[tauri::command]
pub async fn get_config(state: State<'_, AppState>) -> Result<AppConfig, String> {
    let config = state.config.read().await;
    Ok(config.clone())
}

#[tauri::command]
pub async fn update_config(
    config: AppConfig,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    validation::validate_rate(config.faker.default_upload_rate, "upload_rate")
        .map_err(|e| format!("{e}"))?;
    validation::validate_rate(config.faker.default_download_rate, "download_rate")
        .map_err(|e| format!("{e}"))?;
    validation::validate_update_interval(config.faker.update_interval)
        .map_err(|e| format!("{e}"))?;
    validation::validate_port(config.client.default_port).map_err(|e| format!("{e}"))?;
    validation::validate_port(config.client.listening_port).map_err(|e| format!("{e}"))?;

    let path = persistence::config_file_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| format!("Failed to create config directory: {e}"))?;
    }
    config.save(&path).map_err(|e| format!("Failed to save config: {e}"))?;

    {
        let mut app_config = state.config.write().await;
        *app_config = config.clone();
    }

    // Apply updated client identity & announce port to stopped/idle instances
    let http_client = state.http_client().await;
    let mut updated_any = false;
    {
        let mut fakers = state.fakers.write().await;
        for instance in fakers.values_mut() {
            let status = instance.faker.stats_snapshot().state;
            if matches!(status, FakerState::Stopped) {
                let mut next_cfg = instance.config.clone();
                next_cfg.client_type = config.client.default_type;
                next_cfg.client_version = config.client.default_version.clone();
                next_cfg.target_os = config.client.target_os;
                next_cfg.port = config.client.default_port;
                next_cfg.initial_uploaded = instance.cumulative_uploaded;
                next_cfg.initial_downloaded = instance.cumulative_downloaded;

                if let Ok(faker) = RatioFaker::new(
                    Arc::clone(&instance.torrent),
                    next_cfg.clone(),
                    Some(http_client.clone()),
                ) {
                    instance.faker = Arc::new(RatioFakerHandle::new(faker));
                    instance.config = next_cfg;
                    updated_any = true;
                }
            }
        }
    }

    state.refresh_peer_listener_port().await;
    state.save_state().await?;

    if updated_any {
        let fakers = state.fakers.read().await;
        let mut summaries = fakers
            .iter()
            .map(|(id, inst)| inst.faker.with_stats(|stats| build_summary(*id, inst, stats)))
            .collect::<Vec<_>>();
        summaries.sort_by_key(|s| s.id.parse::<u32>().unwrap_or(0));
        let _ = app.emit("instance-summaries", summaries);
    }

    let _ = app.emit("config-updated", &config);
    log::info!("Configuration updated and saved to {}", path.display());
    Ok(())
}

#[tauri::command]
pub async fn set_dark_mode(
    dark_mode: bool,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<AppConfig, String> {
    let updated = {
        let mut guard = state.config.write().await;
        guard.ui.dark_mode = dark_mode;
        guard.clone()
    };

    let path = persistence::config_file_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| format!("Failed to create config directory: {e}"))?;
    }
    updated.save(&path).map_err(|e| format!("Failed to save theme setting: {e}"))?;
    let _ = app.emit("config-updated", &updated);
    Ok(updated)
}

#[tauri::command]
pub async fn get_client_types() -> Vec<String> {
    ClientType::all_ids()
}

#[tauri::command]
pub async fn get_client_infos() -> Vec<ClientInfo> {
    ClientType::all_infos()
}

#[tauri::command]
pub async fn get_target_os_infos() -> Vec<TargetOsInfo> {
    TargetOs::all_infos()
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn set_log_level(level: String) {
    rustatio_core::logger::set_max_emit_level(&level);
    log::info!("IPC log level set to: {level}");
}

#[tauri::command]
pub async fn write_file(path: String, contents: String) -> Result<(), String> {
    std::fs::write(&path, contents).map_err(|e| format!("Failed to write file: {e}"))?;
    log::info!("File written to: {path}");
    Ok(())
}
