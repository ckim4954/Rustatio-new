use rustatio_core::{
    FakerConfig, FakerStats, GridImportSettings, InstanceSummary, PresetSettings, RatioFaker,
    RatioFakerHandle, TorrentInfo,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tauri::{AppHandle, State};
use tokio::task::JoinSet;

use crate::logging::{format_instance_message, log_and_emit};
use crate::state::{hex_info_hash, now_secs, AppState, FakerInstance};
use rustatio_watch::InstanceSource;

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GridActionResponse {
    succeeded: Vec<u32>,
    failed: Vec<GridActionError>,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GridActionError {
    id: u32,
    error: String,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GridImportResponse {
    imported: Vec<GridImportedInstance>,
    duplicates: Vec<String>,
    errors: Vec<String>,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GridImportedInstance {
    id: u32,
    name: String,
    info_hash: String,
}

async fn import_torrent_files(
    paths: Vec<std::path::PathBuf>,
    config: &GridImportSettings,
    state: &AppState,
    app: &AppHandle,
) -> GridImportResponse {
    let mut imported = Vec::new();
    let mut duplicates = Vec::new();
    let mut errors = Vec::new();
    let mut auto_start_ids = Vec::new();
    let mut seen_hashes = std::collections::HashSet::new();

    let now = now_secs();

    // Reserve the whole range up front so concurrent imports cannot claim the same ids.
    let count = u32::try_from(paths.len()).unwrap_or(u32::MAX);
    let base_id = {
        let mut next_id = state.next_instance_id.write().await;
        let base_id = *next_id;
        *next_id = (*next_id).saturating_add(count);
        base_id
    };

    let existing_hashes: std::collections::HashSet<[u8; 20]> = {
        let fakers = state.fakers.read().await;
        fakers.values().map(|instance| instance.torrent.info_hash).collect()
    };

    let parsed = tokio::task::spawn_blocking(move || {
        paths
            .into_iter()
            .map(|path| {
                let result = TorrentInfo::from_file_summary(&path);
                (path, result)
            })
            .collect::<Vec<_>>()
    })
    .await;

    let parsed = match parsed {
        Ok(parsed) => parsed,
        Err(error) => {
            return GridImportResponse {
                imported,
                duplicates,
                errors: vec![format!("Failed to read torrent files: {error}")],
            };
        }
    };

    let client = state.http_client().await;
    let mut prepared = Vec::new();

    for (index, (path, result)) in parsed.into_iter().enumerate() {
        let torrent = match result {
            Ok(torrent) => torrent,
            Err(error) => {
                errors.push(format!("{}: {error}", path.display()));
                continue;
            }
        };

        let torrent_name = torrent.name.clone();
        let torrent_info_hash = torrent.info_hash;

        if !seen_hashes.insert(torrent_info_hash) {
            duplicates.push(format!("{}: duplicate in import batch", path.display()));
            continue;
        }

        if existing_hashes.contains(&torrent_info_hash) {
            duplicates.push(format!("{}: already imported", path.display()));
            continue;
        }

        let preset = config.resolve_for_instance();
        let faker_config: FakerConfig = preset.into();
        let torrent_arc = Arc::new(torrent.without_files());
        let summary_arc = Arc::new(torrent_arc.summary());

        let faker = match RatioFaker::new(
            Arc::clone(&torrent_arc),
            faker_config.clone(),
            Some(client.clone()),
        ) {
            Ok(faker) => faker,
            Err(error) => {
                errors.push(format!("{torrent_name}: {error}"));
                continue;
            }
        };

        let Ok(offset) = u32::try_from(index) else {
            errors.push(format!("{}: too many torrents in one import", path.display()));
            continue;
        };
        let instance_id = base_id.saturating_add(offset);
        prepared.push((
            instance_id,
            torrent_arc,
            summary_arc,
            faker_config,
            torrent_name,
            torrent_info_hash,
            faker,
        ));
    }

    let mut fakers_lock = state.fakers.write().await;
    let mut current_hashes: std::collections::HashSet<[u8; 20]> =
        fakers_lock.values().map(|instance| instance.torrent.info_hash).collect();

    for (instance_id, torrent, summary, faker_config, torrent_name, hash, faker) in prepared {
        if !current_hashes.insert(hash) {
            duplicates.push(format!("{torrent_name}: already imported"));
            continue;
        }

        fakers_lock.insert(
            instance_id,
            FakerInstance {
                faker: Arc::new(RatioFakerHandle::new(faker)),
                torrent,
                summary,
                config: faker_config,
                cumulative_uploaded: 0,
                cumulative_downloaded: 0,
                tags: config.tags.clone(),
                created_at: now,
                source: InstanceSource::Manual,
            },
        );

        imported.push(GridImportedInstance {
            id: instance_id,
            name: torrent_name,
            info_hash: hex_info_hash(&hash),
        });

        if config.auto_start {
            auto_start_ids.push(instance_id);
        }
    }

    let max_id = imported.iter().map(|i| i.id).max().unwrap_or(base_id);
    drop(fakers_lock);
    let mut next_id = state.next_instance_id.write().await;
    if max_id >= *next_id {
        *next_id = max_id.saturating_add(1);
    }
    drop(next_id);

    log_and_emit!(
        app,
        info,
        "Imported {} torrent(s) ({} duplicates, {} errors)",
        imported.len(),
        duplicates.len(),
        errors.len()
    );

    if !auto_start_ids.is_empty() {
        let state_fakers = Arc::clone(&state.fakers);
        let app_handle = app.clone();
        let stagger = config.stagger_start_secs.filter(|seconds| *seconds > 0);

        tauri::async_runtime::spawn(async move {
            let faker_arcs: Vec<_> = {
                let fakers = state_fakers.read().await;
                auto_start_ids
                    .iter()
                    .filter_map(|id| fakers.get(id).map(|i| (*id, Arc::clone(&i.faker))))
                    .collect()
            };

            if let Some(delay) = stagger {
                for (i, (id, faker)) in faker_arcs.into_iter().enumerate() {
                    if i > 0 {
                        tokio::time::sleep(std::time::Duration::from_secs(delay)).await;
                    }
                    match faker.start().await {
                        Ok(()) => log_and_emit!(&app_handle, id, info, "Auto-started"),
                        Err(e) => log_and_emit!(&app_handle, id, error, "Auto-start failed: {}", e),
                    };
                }
            } else {
                let mut join_set = JoinSet::new();
                for (id, faker) in faker_arcs {
                    join_set.spawn(async move {
                        let result = faker.start().await;
                        (id, result.map_err(|e| e.to_string()))
                    });
                }
                while let Some(result) = join_set.join_next().await {
                    match result {
                        Ok((id, Ok(()))) => log_and_emit!(&app_handle, id, info, "Auto-started"),
                        Ok((id, Err(e))) => {
                            log_and_emit!(&app_handle, id, error, "Auto-start failed: {}", e);
                        }
                        Err(e) => log::error!("Auto-start join error: {e}"),
                    }
                }
            }

            log_and_emit!(
                &app_handle,
                info,
                "Auto-start complete for {} instance(s)",
                auto_start_ids.len()
            );
        });
    }

    GridImportResponse { imported, duplicates, errors }
}

#[tauri::command]
pub async fn grid_import_folder(
    path: String,
    config: GridImportSettings,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridImportResponse, String> {
    log_and_emit!(&app, info, "Grid importing from folder: {}", path);

    let dir = std::path::Path::new(&path);
    if !dir.is_dir() {
        return Err(format!("Not a directory: {path}"));
    }

    let mut torrent_paths = Vec::new();
    let entries = std::fs::read_dir(dir).map_err(|e| format!("Failed to read directory: {e}"))?;
    for entry in entries {
        let entry = entry.map_err(|e| format!("Failed to read entry: {e}"))?;
        let p = entry.path();
        if p.extension().and_then(|e| e.to_str()) == Some("torrent") {
            torrent_paths.push(p);
        }
    }

    if torrent_paths.is_empty() {
        return Ok(GridImportResponse {
            imported: vec![],
            duplicates: vec![],
            errors: vec!["No .torrent files found in directory".to_string()],
        });
    }

    torrent_paths.sort();
    log_and_emit!(&app, info, "Found {} .torrent files", torrent_paths.len());

    let result = import_torrent_files(torrent_paths, &config, &state, &app).await;
    log_and_emit!(
        &app,
        info,
        "Grid import complete: {} imported, {} errors",
        result.imported.len(),
        result.errors.len()
    );

    Ok(result)
}

#[tauri::command]
pub async fn grid_import_files(
    paths: Vec<String>,
    config: GridImportSettings,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridImportResponse, String> {
    log_and_emit!(&app, info, "Grid importing {} files", paths.len());

    let torrent_paths: Vec<std::path::PathBuf> =
        paths.iter().map(std::path::PathBuf::from).collect();
    let result = import_torrent_files(torrent_paths, &config, &state, &app).await;
    log_and_emit!(
        &app,
        info,
        "Grid import complete: {} imported, {} errors",
        result.imported.len(),
        result.errors.len()
    );

    Ok(result)
}

#[tauri::command]
pub async fn grid_start(
    ids: Vec<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    let mut to_start = Vec::new();
    {
        let fakers = state.fakers.read().await;
        for id in &ids {
            match fakers.get(id) {
                Some(instance) => {
                    to_start.push((*id, Arc::clone(&instance.faker)));
                    succeeded.push(*id);
                }
                None => {
                    failed.push(GridActionError {
                        id: *id,
                        error: format!("Instance {id} not found"),
                    });
                }
            }
        }
    }

    // Spawn HTTP announces in background — return immediately
    let app_handle = app.clone();
    tauri::async_runtime::spawn(async move {
        let mut join_set = JoinSet::new();
        for (id, faker) in to_start {
            join_set.spawn(async move {
                let result = faker.start().await;
                (id, result.map_err(|e| e.to_string()))
            });
        }

        while let Some(result) = join_set.join_next().await {
            match result {
                Ok((id, Ok(()))) => log::info!(
                    "{}",
                    format_instance_message(&app_handle, id, "Started via grid action")
                ),
                Ok((id, Err(e))) => {
                    let msg = format!("Grid start failed: {e}");
                    log::error!("{}", format_instance_message(&app_handle, id, &msg));
                }
                Err(e) => log::error!("Grid start join error: {e}"),
            }
        }
    });

    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_stop(
    ids: Vec<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    let mut to_stop = Vec::new();
    {
        let fakers = state.fakers.read().await;
        for id in &ids {
            match fakers.get(id) {
                Some(instance) => {
                    to_stop.push((*id, Arc::clone(&instance.faker)));
                    succeeded.push(*id);
                }
                None => {
                    failed.push(GridActionError {
                        id: *id,
                        error: format!("Instance {id} not found"),
                    });
                }
            }
        }
    }

    // Spawn HTTP stop announces + cumulative stats update in background
    let fakers_arc = Arc::clone(&state.fakers);
    let app_handle = app.clone();
    tauri::async_runtime::spawn(async move {
        let mut join_set = JoinSet::new();
        for (id, faker) in to_stop {
            join_set.spawn(async move {
                let final_stats = faker.stats_snapshot();
                let stop_result = faker.stop().await;
                (id, final_stats, stop_result.map_err(|e| e.to_string()))
            });
        }

        let mut stats_updates: Vec<(u32, FakerStats)> = Vec::new();
        while let Some(result) = join_set.join_next().await {
            match result {
                Ok((id, stats, Ok(()))) => {
                    log::info!(
                        "{}",
                        format_instance_message(&app_handle, id, "Stopped via grid action")
                    );
                    stats_updates.push((id, stats));
                }
                Ok((id, _, Err(e))) => {
                    let msg = format!("Grid stop failed: {e}");
                    log::error!("{}", format_instance_message(&app_handle, id, &msg));
                }
                Err(e) => log::error!("Grid stop join error: {e}"),
            }
        }

        if !stats_updates.is_empty() {
            let mut fakers = fakers_arc.write().await;
            for (id, stats) in stats_updates {
                if let Some(instance) = fakers.get_mut(&id) {
                    instance.cumulative_uploaded = stats.uploaded;
                    instance.cumulative_downloaded = stats.downloaded;
                }
            }
        }
    });

    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_pause(
    ids: Vec<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    // Collect Arcs under read lock, then drop HashMap lock
    let faker_arcs: Vec<_> = {
        let fakers = state.fakers.read().await;
        ids.iter().map(|id| (*id, fakers.get(id).map(|i| Arc::clone(&i.faker)))).collect()
    };

    for (id, faker_opt) in faker_arcs {
        match faker_opt {
            Some(faker) => match faker.pause().await {
                Ok(()) => {
                    log_and_emit!(&app, id, info, "Paused via grid action");
                    succeeded.push(id);
                }
                Err(e) => {
                    failed.push(GridActionError { id, error: e.to_string() });
                }
            },
            None => {
                failed.push(GridActionError { id, error: format!("Instance {id} not found") });
            }
        }
    }

    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_resume(
    ids: Vec<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    // Collect Arcs under read lock, then drop HashMap lock
    let faker_arcs: Vec<_> = {
        let fakers = state.fakers.read().await;
        ids.iter().map(|id| (*id, fakers.get(id).map(|i| Arc::clone(&i.faker)))).collect()
    };

    for (id, faker_opt) in faker_arcs {
        match faker_opt {
            Some(faker) => match faker.resume().await {
                Ok(()) => {
                    log_and_emit!(&app, id, info, "Resumed via grid action");
                    succeeded.push(id);
                }
                Err(e) => {
                    failed.push(GridActionError { id, error: e.to_string() });
                }
            },
            None => {
                failed.push(GridActionError { id, error: format!("Instance {id} not found") });
            }
        }
    }

    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_delete(
    ids: Vec<u32>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    let removed: Vec<_> = {
        let mut fakers = state.fakers.write().await;
        ids.iter().map(|id| (*id, fakers.remove(id))).collect()
    };

    let mut join_set = JoinSet::new();
    for (id, instance_opt) in removed {
        match instance_opt {
            Some(instance) => {
                join_set.spawn(async move {
                    let _ = instance.faker.stop().await;
                    id
                });
            }
            None => {
                failed.push(GridActionError { id, error: format!("Instance {id} not found") });
            }
        }
    }

    while let Some(result) = join_set.join_next().await {
        match result {
            Ok(id) => {
                log_and_emit!(&app, id, info, "Deleted via grid action");
                succeeded.push(id);
            }
            Err(e) => log::error!("Grid delete join error: {e}"),
        }
    }

    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_update_config(
    ids: Vec<u32>,
    config: PresetSettings,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let faker_config: FakerConfig = config.into();
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    let mut fakers = state.fakers.write().await;
    for id in ids {
        match fakers.get_mut(&id) {
            Some(instance) => {
                let mut new_config = faker_config.clone();
                new_config.initial_uploaded = instance.cumulative_uploaded;
                new_config.initial_downloaded = instance.cumulative_downloaded;

                let result =
                    instance.faker.update_config(new_config, Some(state.http_client().await)).await;
                match result {
                    Ok(()) => {
                        instance.config = faker_config.clone();
                        log_and_emit!(&app, id, info, "Config updated via grid action");
                        succeeded.push(id);
                    }
                    Err(e) => {
                        failed.push(GridActionError { id, error: e.to_string() });
                    }
                }
            }
            None => {
                failed.push(GridActionError { id, error: format!("Instance {id} not found") });
            }
        }
    }

    drop(fakers);

    if !succeeded.is_empty() {
        state.save_state().await?;
    }

    state.refresh_peer_listener_port().await;
    Ok(GridActionResponse { succeeded, failed })
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BulkConfigEntry {
    id: u32,
    config: FakerConfig,
}

#[tauri::command]
pub async fn bulk_update_configs(
    entries: Vec<BulkConfigEntry>,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<GridActionResponse, String> {
    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    let mut fakers = state.fakers.write().await;
    for entry in entries {
        match fakers.get_mut(&entry.id) {
            Some(instance) => {
                let mut new_config = entry.config.clone();
                new_config.initial_uploaded = instance.cumulative_uploaded;
                new_config.initial_downloaded = instance.cumulative_downloaded;

                let result =
                    instance.faker.update_config(new_config, Some(state.http_client().await)).await;
                match result {
                    Ok(()) => {
                        instance.config = entry.config;
                        log_and_emit!(&app, entry.id, info, "Config synced before bulk start");
                        succeeded.push(entry.id);
                    }
                    Err(e) => {
                        failed.push(GridActionError { id: entry.id, error: e.to_string() });
                    }
                }
            }
            None => {
                failed.push(GridActionError {
                    id: entry.id,
                    error: format!("Instance {} not found", entry.id),
                });
            }
        }
    }

    drop(fakers);
    state.refresh_peer_listener_port().await;
    Ok(GridActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn grid_tag(
    ids: Vec<u32>,
    add_tags: Vec<String>,
    remove_tags: Vec<String>,
    state: State<'_, AppState>,
) -> Result<u32, String> {
    let mut fakers = state.fakers.write().await;
    let mut updated = 0u32;

    for id in ids {
        if let Some(instance) = fakers.get_mut(&id) {
            for tag in &remove_tags {
                instance.tags.retain(|t| t != tag);
            }
            for tag in &add_tags {
                if !instance.tags.contains(tag) {
                    instance.tags.push(tag.clone());
                }
            }
            updated += 1;
        }
    }

    drop(fakers);
    Ok(updated)
}

#[tauri::command]
pub async fn set_instance_tags(
    instance_id: u32,
    tags: Vec<String>,
    state: State<'_, AppState>,
) -> Result<(), String> {
    let mut fakers = state.fakers.write().await;

    if let Some(instance) = fakers.get_mut(&instance_id) {
        instance.tags = tags;
        Ok(())
    } else {
        Err(format!("Instance {instance_id} not found"))
    }?;

    drop(fakers);
    Ok(())
}

#[tauri::command]
pub async fn list_summaries(state: State<'_, AppState>) -> Result<Vec<InstanceSummary>, String> {
    let mut summaries = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .map(|(id, instance)| {
                instance.faker.with_stats(|stats| crate::state::build_summary(*id, instance, stats))
            })
            .collect::<Vec<_>>()
    };

    summaries.sort_by_key(|summary| summary.id.parse::<u32>().unwrap_or(0));
    Ok(summaries)
}
