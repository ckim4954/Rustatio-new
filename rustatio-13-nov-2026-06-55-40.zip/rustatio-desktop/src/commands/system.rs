use rustatio_core::ProxySettings;
use serde::Serialize;
use std::sync::atomic::Ordering;
use tauri::{AppHandle, Manager, State};
use tauri_plugin_rustatio_android::{
    ForegroundServiceStatus, PickedTorrentFile, RustatioAndroidExt, ShareJsonPayload,
    ShareJsonResult,
};

#[cfg(target_os = "linux")]
const RPM_LIKE: [&str; 9] =
    ["fedora", "rhel", "centos", "rocky", "almalinux", "suse", "opensuse", "sles", "mageia"];
#[cfg(target_os = "linux")]
const DEB_LIKE: [&str; 8] =
    ["debian", "ubuntu", "linuxmint", "pop", "elementary", "kali", "raspbian", "zorin"];

#[cfg(target_os = "linux")]
fn matches_family<'a>(mut tokens: impl Iterator<Item = &'a str>, family: &[&str]) -> bool {
    tokens.any(|token| family.contains(&token))
}

#[tauri::command]
pub fn detect_linux_package_type() -> String {
    #[cfg(target_os = "linux")]
    {
        use os_release::OsRelease;

        let Ok(os_release) = OsRelease::new() else {
            return "unknown".to_string();
        };

        let id = os_release.id.trim().to_lowercase();
        let id_like = os_release.id_like.trim().to_lowercase();
        let tokens = id.split_whitespace().chain(id_like.split_whitespace());

        if matches_family(tokens.clone(), &RPM_LIKE) {
            return "rpm".to_string();
        }

        if matches_family(tokens, &DEB_LIKE) {
            return "deb".to_string();
        }

        "unknown".to_string()
    }

    #[cfg(not(target_os = "linux"))]
    {
        "unknown".to_string()
    }
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn close_to_tray(app: AppHandle) -> Result<(), String> {
    let state = app.state::<crate::state::AppState>();
    state.close_prompt_open.store(false, Ordering::Relaxed);

    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let Some(window) = app.get_webview_window("main") else {
            return Err("Main window not found".to_string());
        };

        if let Err(e) = window.hide() {
            return Err(e.to_string());
        }
    }

    Ok(())
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn quit_app(app: AppHandle) {
    let state = app.state::<crate::state::AppState>();
    state.should_exit.store(true, Ordering::Relaxed);
    state.close_prompt_open.store(false, Ordering::Relaxed);

    app.exit(0);
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn cancel_close_prompt(app: AppHandle) {
    let state = app.state::<crate::state::AppState>();
    state.close_prompt_open.store(false, Ordering::Relaxed);
}

#[derive(Serialize)]
pub struct DesktopNetworkStatus {
    #[serde(rename = "peer_listener_port")]
    port: Option<u16>,
    #[serde(rename = "peer_listener_active")]
    active: bool,
    #[serde(rename = "peer_listener_error")]
    error: Option<String>,
    #[serde(rename = "proxy_enabled")]
    proxy_enabled: bool,
    #[serde(rename = "proxy_url")]
    proxy_url: Option<String>,
}

#[tauri::command]
pub async fn get_network_status(
    state: State<'_, crate::state::AppState>,
) -> Result<DesktopNetworkStatus, String> {
    let status = state.peer_listener_status().await;
    let proxy = state.proxy_settings().await;
    Ok(DesktopNetworkStatus {
        port: status.bound_port,
        active: status.bound_port.is_some(),
        error: status.last_error,
        proxy_enabled: proxy.is_configured(),
        proxy_url: proxy.is_configured().then(|| proxy.url.clone()),
    })
}

#[derive(Serialize)]
pub struct ProxyTestResponse {
    ip: String,
}

#[tauri::command]
pub async fn get_proxy_settings(
    state: State<'_, crate::state::AppState>,
) -> Result<ProxySettings, String> {
    Ok(state.proxy_settings().await)
}

#[tauri::command]
pub async fn set_proxy_settings(
    settings: ProxySettings,
    state: State<'_, crate::state::AppState>,
) -> Result<(), String> {
    state.set_proxy_settings(settings).await
}

#[tauri::command]
pub async fn test_proxy(settings: ProxySettings) -> Result<ProxyTestResponse, String> {
    let proxy = settings.is_configured().then_some(&settings);
    let ip = rustatio_core::proxy::fetch_public_ip(proxy).await?;
    Ok(ProxyTestResponse { ip })
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn pick_torrent_file(app: AppHandle) -> Result<PickedTorrentFile, String> {
    app.rustatio_android().pick_torrent_file()
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn request_notification_permission(app: AppHandle) -> Result<ForegroundServiceStatus, String> {
    app.rustatio_android().request_notification_permission()
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn get_foreground_service_status(app: AppHandle) -> Result<ForegroundServiceStatus, String> {
    app.rustatio_android().get_service_status()
}

#[tauri::command]
pub async fn sync_foreground_service(
    state: State<'_, crate::state::AppState>,
    app: AppHandle,
) -> Result<ForegroundServiceStatus, String> {
    state.sync_android_foreground_service(&app).await;
    app.rustatio_android().get_service_status()
}

#[tauri::command]
#[allow(clippy::needless_pass_by_value)]
pub fn share_or_save_json(
    filename: String,
    content: String,
    mode: String,
    app: AppHandle,
) -> Result<ShareJsonResult, String> {
    app.rustatio_android().share_or_save_json(ShareJsonPayload { filename, content, mode })
}
