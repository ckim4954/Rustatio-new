use rustatio_core::validation;
use rustatio_core::{
    FakerConfig, FakerState, FakerStats, RatioFaker, RatioFakerHandle, TorrentInfo,
};
use rustatio_watch::InstanceSource;
use serde::Serialize;
use std::sync::Arc;
use tauri::{AppHandle, Emitter, State};
use tokio::task::JoinSet;

use crate::logging::log_and_emit;
use crate::state::{build_summary, AppState, FakerInstance};

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BulkFakerActionResponse {
    pub succeeded: Vec<u32>,
    pub failed: Vec<BulkFakerActionError>,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BulkFakerActionError {
    pub id: u32,
    pub error: String,
}

fn set_instance_label(state: &AppState, instance_id: u32, fallback: Option<&str>) {
    let label = state
        .fakers
        .try_read()
        .ok()
        .and_then(|fakers| fakers.get(&instance_id).map(|instance| instance.summary.name.clone()))
        .filter(|name| !name.is_empty())
        .or_else(|| fallback.map(std::string::ToString::to_string))
        .unwrap_or_else(|| instance_id.to_string());

    rustatio_core::logger::set_instance_context_str(Some(&label));
}

async fn emit_all_summaries(state: &AppState, app: &AppHandle) {
    let mut summaries = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .map(|(id, instance)| instance.faker.with_stats(|stats| build_summary(*id, instance, stats)))
            .collect::<Vec<_>>()
    };
    summaries.sort_by_key(|s| s.id.parse::<u32>().unwrap_or(0));
    let _ = app.emit("instance-summaries", summaries);
}

#[tauri::command]
pub async fn start_faker(
    instance_id: u32,
    torrent: TorrentInfo,
    config: FakerConfig,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    validation::validate_rate(config.upload_rate, "upload_rate").map_err(|e| format!("{e}"))?;
    validation::validate_rate(config.download_rate, "download_rate").map_err(|e| format!("{e}"))?;
    validation::validate_port(config.port).map_err(|e| format!("{e}"))?;
    validation::validate_percentage(config.completion_percent, "completion_percent")
        .map_err(|e| format!("{e}"))?;

    if config.randomize_rates {
        validation::validate_percentage(config.random_range_percent, "random_range_percent")
            .map_err(|e| format!("{e}"))?;
    }

    if config.randomize_ratio {
        validation::validate_percentage(
            config.random_ratio_range_percent,
            "random_ratio_range_percent",
        )
        .map_err(|e| format!("{e}"))?;
    }

    log_and_emit!(&app, instance_id, info, "Starting faker for torrent: {}", torrent.name);
    log_and_emit!(
        &app,
        instance_id,
        info,
        "Upload: {} KB/s, Download: {} KB/s",
        config.upload_rate,
        config.download_rate
    );

    let torrent_info_hash = torrent.info_hash;

    set_instance_label(&state, instance_id, Some(&torrent.name));

    let mut config_with_cumulative = config.clone();
    let (existing_tags, created_at, existing_source) = {
        let fakers = state.fakers.read().await;
        if let Some(existing) = fakers.get(&instance_id) {
            if existing.torrent.info_hash == torrent_info_hash {
                config_with_cumulative.initial_uploaded = existing.cumulative_uploaded;
                config_with_cumulative.initial_downloaded = existing.cumulative_downloaded;
                (existing.tags.clone(), existing.created_at, existing.source)
            } else {
                (existing.tags.clone(), existing.created_at, InstanceSource::Manual)
            }
        } else {
            (vec![], crate::state::now_secs(), InstanceSource::Manual)
        }
    };

    let cumulative_uploaded = config_with_cumulative.initial_uploaded;
    let cumulative_downloaded = config_with_cumulative.initial_downloaded;

    let torrent_arc = Arc::new(torrent.without_files());
    let summary_arc = Arc::new(torrent_arc.summary());

    let mut faker = RatioFaker::new(
        Arc::clone(&torrent_arc),
        config_with_cumulative,
        Some(state.http_client().await),
    )
    .map_err(|e| {
        let error_msg = format!("Failed to create faker: {e}");
        log_and_emit!(&app, instance_id, error, "{}", error_msg);
        error_msg
    })?;

    faker.start().await.map_err(|e| {
        let error_msg = format!("Failed to start faker: {e}");
        log_and_emit!(&app, instance_id, error, "{}", error_msg);
        error_msg
    })?;

    let mut fakers = state.fakers.write().await;
    fakers.insert(
        instance_id,
        FakerInstance {
            faker: Arc::new(RatioFakerHandle::new(faker)),
            torrent: torrent_arc,
            summary: summary_arc,
            config,
            cumulative_uploaded,
            cumulative_downloaded,
            tags: existing_tags,
            created_at,
            source: existing_source,
        },
    );
    drop(fakers);

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;

    log_and_emit!(&app, instance_id, info, "Faker started successfully");
    Ok(())
}

#[tauri::command]
pub async fn stop_faker(
    instance_id: u32,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    log_and_emit!(&app, instance_id, info, "Stopping faker");
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    let final_stats = faker.stats_snapshot();
    faker.stop().await.map_err(|e| {
        let error_msg = format!("Failed to stop faker: {e}");
        log_and_emit!(&app, instance_id, error, "{}", error_msg);
        error_msg
    })?;

    {
        let mut fakers = state.fakers.write().await;
        if let Some(instance) = fakers.get_mut(&instance_id) {
            instance.cumulative_uploaded = final_stats.uploaded;
            instance.cumulative_downloaded = final_stats.downloaded;
            instance.config.completion_percent = final_stats.torrent_completion;
        }
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;

    log_and_emit!(
        &app,
        instance_id,
        info,
        "Faker stopped successfully - Cumulative: uploaded={} bytes, downloaded={} bytes",
        final_stats.uploaded,
        final_stats.downloaded
    );

    Ok(())
}

#[tauri::command]
pub async fn update_faker(instance_id: u32, state: State<'_, AppState>) -> Result<(), String> {
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    faker.update().await.map_err(|e| format!("Failed to update faker: {e}"))?;

    Ok(())
}

#[tauri::command]
pub async fn announce_now(
    instance_id: u32,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<FakerStats, String> {
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    let stats = faker.announce_now().await.map_err(|e| format!("Announce thất bại: {e}"))?;

    {
        let mut fakers = state.fakers.write().await;
        if let Some(instance) = fakers.get_mut(&instance_id) {
            instance.cumulative_uploaded = stats.uploaded;
            instance.cumulative_downloaded = stats.downloaded;
            instance.config.completion_percent = stats.torrent_completion;
        }
    }

    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;
    Ok(stats)
}

#[tauri::command]
pub async fn update_stats_only(
    instance_id: u32,
    state: State<'_, AppState>,
) -> Result<FakerStats, String> {
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    faker.update_stats_only().await.map_err(|e| format!("Failed to update stats: {e}"))?;

    let stats = faker.stats_snapshot();
    Ok(stats)
}

#[tauri::command]
pub async fn get_stats(instance_id: u32, state: State<'_, AppState>) -> Result<FakerStats, String> {
    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    let stats = faker.stats_snapshot();
    Ok(stats)
}

#[tauri::command]
pub async fn scrape_tracker(
    instance_id: u32,
    state: State<'_, AppState>,
) -> Result<(i64, i64, i64), String> {
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    let scrape = faker.scrape().await.map_err(|e| format!("Failed to scrape: {e}"))?;

    Ok((scrape.complete, scrape.incomplete, scrape.downloaded))
}

#[tauri::command]
pub async fn pause_faker(
    instance_id: u32,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    log_and_emit!(&app, instance_id, info, "Pausing faker");
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    faker.pause().await.map_err(|e| format!("Failed to pause faker: {e}"))?;

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;

    log_and_emit!(&app, instance_id, info, "Faker paused successfully");
    Ok(())
}

#[tauri::command]
pub async fn resume_faker(
    instance_id: u32,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<(), String> {
    log_and_emit!(&app, instance_id, info, "Resuming faker");
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    faker.resume().await.map_err(|e| format!("Failed to resume faker: {e}"))?;

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;

    log_and_emit!(&app, instance_id, info, "Faker resumed successfully");
    Ok(())
}

#[tauri::command]
pub async fn recover_tracker_faker(
    instance_id: u32,
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<FakerStats, String> {
    log_and_emit!(&app, instance_id, info, "Retrying tracker after temporary failure");
    set_instance_label(&state, instance_id, None);

    let faker = {
        let fakers = state.fakers.read().await;
        let instance =
            fakers.get(&instance_id).ok_or_else(|| format!("Instance {instance_id} not found"))?;
        Arc::clone(&instance.faker)
    };

    let stats =
        faker.recover_tracker().await.map_err(|e| format!("Failed to retry tracker: {e}"))?;

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;

    Ok(stats)
}

#[tauri::command]
pub async fn start_all_fakers(
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<BulkFakerActionResponse, String> {
    let targets: Vec<(u32, Arc<RatioFakerHandle>, FakerState)> = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .filter_map(|(id, inst)| {
                let st = inst.faker.stats_snapshot().state;
                match st {
                    FakerState::Stopped | FakerState::Paused | FakerState::Idle => {
                        Some((*id, Arc::clone(&inst.faker), st))
                    }
                    _ => None,
                }
            })
            .collect()
    };

    let mut join_set = JoinSet::new();
    for (id, faker, st) in targets {
        join_set.spawn(async move {
            let res = if matches!(st, FakerState::Paused) {
                faker.resume().await
            } else {
                faker.start().await
            };
            (id, res.map_err(|e| e.to_string()))
        });
    }

    let mut succeeded = Vec::new();
    let mut failed = Vec::new();
    while let Some(res) = join_set.join_next().await {
        match res {
            Ok((id, Ok(()))) => succeeded.push(id),
            Ok((id, Err(error))) => failed.push(BulkFakerActionError { id, error }),
            Err(e) => log::error!("start_all_fakers join error: {e}"),
        }
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;
    Ok(BulkFakerActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn pause_all_fakers(
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<BulkFakerActionResponse, String> {
    let targets: Vec<(u32, Arc<RatioFakerHandle>)> = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .filter_map(|(id, inst)| {
                let st = inst.faker.stats_snapshot().state;
                matches!(st, FakerState::Running | FakerState::Starting)
                    .then(|| (*id, Arc::clone(&inst.faker)))
            })
            .collect()
    };

    let mut succeeded = Vec::new();
    let mut failed = Vec::new();
    for (id, faker) in targets {
        match faker.pause().await {
            Ok(()) => succeeded.push(id),
            Err(e) => failed.push(BulkFakerActionError { id, error: e.to_string() }),
        }
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;
    Ok(BulkFakerActionResponse { succeeded, failed })
}

#[tauri::command]
pub async fn stop_all_fakers(
    state: State<'_, AppState>,
    app: AppHandle,
) -> Result<BulkFakerActionResponse, String> {
    let targets: Vec<(u32, Arc<RatioFakerHandle>)> = {
        let fakers = state.fakers.read().await;
        fakers
            .iter()
            .filter_map(|(id, inst)| {
                let st = inst.faker.stats_snapshot().state;
                (!matches!(st, FakerState::Stopped)).then(|| (*id, Arc::clone(&inst.faker)))
            })
            .collect()
    };

    let mut join_set = JoinSet::new();
    for (id, faker) in targets {
        join_set.spawn(async move {
            let res = faker.stop().await;
            let stats = faker.stats_snapshot();
            (id, stats, res.map_err(|e| e.to_string()))
        });
    }

    let mut succeeded = Vec::new();
    let mut failed = Vec::new();
    let mut stats_updates = Vec::new();
    while let Some(res) = join_set.join_next().await {
        match res {
            Ok((id, stats, Ok(()))) => {
                succeeded.push(id);
                stats_updates.push((id, stats));
            }
            Ok((id, _, Err(error))) => failed.push(BulkFakerActionError { id, error }),
            Err(e) => log::error!("stop_all_fakers join error: {e}"),
        }
    }

    if !stats_updates.is_empty() {
        let mut fakers = state.fakers.write().await;
        for (id, stats) in stats_updates {
            if let Some(instance) = fakers.get_mut(&id) {
                instance.cumulative_uploaded = stats.uploaded;
                instance.cumulative_downloaded = stats.downloaded;
                instance.config.completion_percent = stats.torrent_completion;
            }
        }
    }

    state.refresh_peer_listener_port().await;
    state.sync_android_foreground_service(&app).await;
    let _ = state.save_state().await;
    emit_all_summaries(&state, &app).await;
    Ok(BulkFakerActionResponse { succeeded, failed })
}
