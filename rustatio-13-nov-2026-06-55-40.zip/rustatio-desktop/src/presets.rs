use rustatio_core::{validation, FakerConfig, PresetSettings};
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicU64, Ordering};

use crate::persistence;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PresetItem {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub description: String,
    #[serde(default = "default_icon")]
    pub icon: String,
    #[serde(default)]
    pub recommended: bool,
    #[serde(default)]
    pub built_in: bool,
    #[serde(default)]
    pub is_default: bool,
    #[serde(default)]
    pub is_active: bool,
    pub settings: PresetSettings,
    #[serde(default)]
    pub tips: Vec<String>,
    #[serde(default)]
    pub created_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PresetListResponse {
    pub presets: Vec<PresetItem>,
    pub default_preset_id: Option<String>,
    pub active_preset_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SavePresetRequest {
    pub id: Option<String>,
    pub name: String,
    #[serde(default)]
    pub description: String,
    #[serde(default = "default_icon")]
    pub icon: String,
    pub settings: PresetSettings,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ImportPresetsResponse {
    pub imported_count: usize,
    pub presets: Vec<PresetItem>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct PersistedPresetsFile {
    #[serde(default)]
    pub custom_presets: Vec<PresetItem>,
    #[serde(default)]
    pub default_preset_id: Option<String>,
    #[serde(default)]
    pub active_preset_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ExportPresetEnvelope {
    version: u32,
    #[serde(rename = "type")]
    kind: String,
    name: String,
    description: String,
    icon: String,
    created_at: String,
    settings: PresetSettings,
}

fn default_icon() -> String {
    "sliders".to_string()
}

pub fn built_in_presets() -> Vec<PresetItem> {
    let raw_files = [
        include_str!("../../ui/src/lib/presets/balanced.json"),
        include_str!("../../ui/src/lib/presets/fast.json"),
        include_str!("../../ui/src/lib/presets/partial.json"),
        include_str!("../../ui/src/lib/presets/seedbox.json"),
        include_str!("../../ui/src/lib/presets/stealth.json"),
    ];

    let mut out: Vec<PresetItem> = raw_files
        .iter()
        .filter_map(|raw| serde_json::from_str::<PresetItem>(raw).ok())
        .map(|mut item| {
            item.built_in = true;
            item
        })
        .collect();

    out.sort_by(|a, b| b.recommended.cmp(&a.recommended).then_with(|| a.name.cmp(&b.name)));
    out
}

pub fn load_presets_file() -> PersistedPresetsFile {
    let path = persistence::presets_file_path();
    if !path.exists() {
        return PersistedPresetsFile {
            custom_presets: Vec::new(),
            default_preset_id: Some("balanced".to_string()),
            active_preset_id: Some("balanced".to_string()),
        };
    }
    match std::fs::read_to_string(&path) {
        Ok(raw) => serde_json::from_str::<PersistedPresetsFile>(&raw).unwrap_or_else(|e| {
            log::warn!("Failed to parse presets file: {e}");
            PersistedPresetsFile {
                custom_presets: Vec::new(),
                default_preset_id: Some("balanced".to_string()),
                active_preset_id: Some("balanced".to_string()),
            }
        }),
        Err(e) => {
            log::warn!("Failed to read presets file: {e}");
            PersistedPresetsFile::default()
        }
    }
}

pub fn save_presets_file(file: &PersistedPresetsFile) -> Result<(), String> {
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let path = persistence::presets_file_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| format!("Failed to create presets directory: {e}"))?;
    }
    let unique_id = COUNTER.fetch_add(1, Ordering::Relaxed);
    let temp_path = path.with_file_name(format!("presets.json.{}.{unique_id}.tmp", std::process::id()));
    let json = serde_json::to_vec_pretty(file)
        .map_err(|e| format!("Failed to serialize presets: {e}"))?;
    std::fs::write(&temp_path, &json)
        .map_err(|e| format!("Failed to write temporary presets file: {e}"))?;
    if let Ok(f) = std::fs::File::open(&temp_path) {
        let _ = f.sync_all();
    }
    std::fs::rename(&temp_path, &path).map_err(|e| {
        let _ = std::fs::remove_file(&temp_path);
        format!("Failed to save presets: {e}")
    })?;
    Ok(())
}

pub fn validate_preset_settings(name: &str, settings: &PresetSettings) -> Result<(), String> {
    if name.trim().is_empty() {
        return Err("Tên Preset không được để trống.".to_string());
    }
    if let Some(rate) = settings.upload_rate {
        validation::validate_rate(rate, "uploadRate").map_err(|e| e.to_string())?;
    }
    if let Some(rate) = settings.download_rate {
        validation::validate_rate(rate, "downloadRate").map_err(|e| e.to_string())?;
    }
    if let Some(target_up) = settings.target_upload_rate {
        validation::validate_rate(target_up, "targetUploadRate").map_err(|e| e.to_string())?;
    }
    if let Some(target_down) = settings.target_download_rate {
        validation::validate_rate(target_down, "targetDownloadRate").map_err(|e| e.to_string())?;
    }
    if let Some(port) = settings.port {
        validation::validate_port(port).map_err(|e| e.to_string())?;
    }
    if let Some(interval) = settings.update_interval_seconds {
        validation::validate_update_interval(interval).map_err(|e| e.to_string())?;
    }
    if let Some(completion) = settings.completion_percent {
        validation::validate_percentage(completion, "completionPercent")
            .map_err(|e| e.to_string())?;
    }
    if let Some(range) = settings.random_range_percent {
        validation::validate_percentage(range, "randomRangePercent").map_err(|e| e.to_string())?;
    }
    if let Some(ratio_range) = settings.random_ratio_range_percent {
        validation::validate_percentage(ratio_range, "randomRatioRangePercent")
            .map_err(|e| e.to_string())?;
    }
    if settings.stop_at_ratio_enabled.unwrap_or(false) {
        let ratio = settings.stop_at_ratio.unwrap_or(0.0);
        if ratio <= 0.0 || ratio > 10_000.0 {
            return Err("Tỷ lệ dừng (Stop Ratio) phải lớn hơn 0 và nhỏ hơn 10000.".to_string());
        }
    }
    if settings.stop_at_uploaded_enabled.unwrap_or(false)
        && settings.stop_at_uploaded_gb.unwrap_or(0.0) <= 0.0
    {
        return Err("Giới hạn Upload (GB) phải lớn hơn 0.".to_string());
    }
    if settings.stop_at_downloaded_enabled.unwrap_or(false)
        && settings.stop_at_downloaded_gb.unwrap_or(0.0) <= 0.0
    {
        return Err("Giới hạn Download (GB) phải lớn hơn 0.".to_string());
    }
    if settings.stop_at_seed_time_enabled.unwrap_or(false)
        && settings.stop_at_seed_time_hours.unwrap_or(0.0) <= 0.0
    {
        return Err("Thời gian Seed (giờ) phải lớn hơn 0.".to_string());
    }
    Ok(())
}

pub fn build_list_response(file: &PersistedPresetsFile) -> PresetListResponse {
    let mut presets = built_in_presets();
    for custom in &file.custom_presets {
        let mut item = custom.clone();
        item.built_in = false;
        presets.push(item);
    }

    let default_id = file.default_preset_id.clone().or_else(|| Some("balanced".to_string()));
    let active_id = file.active_preset_id.clone().or_else(|| default_id.clone());

    for item in &mut presets {
        item.is_default = default_id.as_deref() == Some(item.id.as_str());
        item.is_active = active_id.as_deref() == Some(item.id.as_str());
    }

    PresetListResponse { presets, default_preset_id: default_id, active_preset_id: active_id }
}

pub fn find_preset(file: &PersistedPresetsFile, id: &str) -> Option<PresetItem> {
    built_in_presets()
        .into_iter()
        .chain(file.custom_presets.iter().cloned())
        .find(|p| p.id == id)
}

pub fn default_faker_config_from_presets(file: &PersistedPresetsFile) -> Option<FakerConfig> {
    let target_id = file
        .active_preset_id
        .as_deref()
        .or(file.default_preset_id.as_deref())
        .unwrap_or("balanced");
    find_preset(file, target_id).map(|p| FakerConfig::from(p.settings))
}

pub fn parse_import_json(raw_json: &str) -> Result<Vec<SavePresetRequest>, String> {
    let value: serde_json::Value = serde_json::from_str(raw_json)
        .map_err(|e| format!("JSON không hợp lệ: {e}"))?;

    let items = if let Some(arr) = value.as_array() {
        arr.clone()
    } else if let Some(arr) = value.get("presets").and_then(serde_json::Value::as_array) {
        arr.clone()
    } else if value.is_object() {
        vec![value]
    } else {
        return Err("Định dạng JSON Preset phải là object hoặc mảng preset.".to_string());
    };

    if items.is_empty() {
        return Err("Không tìm thấy Preset nào trong dữ liệu JSON.".to_string());
    }

    let mut parsed = Vec::with_capacity(items.len());
    for (idx, item) in items.into_iter().enumerate() {
        let name = item
            .get("name")
            .and_then(serde_json::Value::as_str)
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .ok_or_else(|| format!("Preset #{} thiếu trường 'name'.", idx + 1))?
            .to_string();

        let description = item
            .get("description")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("")
            .to_string();

        let icon = item
            .get("icon")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("sliders")
            .to_string();

        let settings_val = item
            .get("settings")
            .cloned()
            .ok_or_else(|| format!("Preset '{name}' thiếu trường 'settings'."))?;
        let settings: PresetSettings = serde_json::from_value(settings_val)
            .map_err(|e| format!("Thông số 'settings' của Preset '{name}' không hợp lệ: {e}"))?;

        validate_preset_settings(&name, &settings)?;
        parsed.push(SavePresetRequest { id: None, name, description, icon, settings });
    }

    Ok(parsed)
}

pub fn export_presets_to_json(
    file: &PersistedPresetsFile,
    preset_id: Option<&str>,
) -> Result<String, String> {
    let list = build_list_response(file).presets;
    let now_str = persistence::now_timestamp().to_string();

    if let Some(id) = preset_id {
        let preset = list
            .into_iter()
            .find(|p| p.id == id)
            .ok_or_else(|| format!("Không tìm thấy Preset '{id}'."))?;
        let envelope = ExportPresetEnvelope {
            version: 1,
            kind: "rustatio-preset".to_string(),
            name: preset.name,
            description: preset.description,
            icon: preset.icon,
            created_at: preset.created_at.unwrap_or(now_str),
            settings: preset.settings,
        };
        return serde_json::to_string_pretty(&envelope)
            .map_err(|e| format!("Không thể xuất JSON: {e}"));
    }

    let custom_or_all: Vec<ExportPresetEnvelope> = list
        .into_iter()
        .filter(|p| !p.built_in)
        .map(|p| ExportPresetEnvelope {
            version: 1,
            kind: "rustatio-preset".to_string(),
            name: p.name,
            description: p.description,
            icon: p.icon,
            created_at: p.created_at.unwrap_or_else(|| now_str.clone()),
            settings: p.settings,
        })
        .collect();

    if custom_or_all.len() == 1 {
        if let Some(single) = custom_or_all.into_iter().next() {
            return serde_json::to_string_pretty(&single)
                .map_err(|e| format!("Không thể xuất JSON: {e}"));
        }
    }

    if custom_or_all.is_empty() {
        let fallback = build_list_response(file).presets;
        let all_envelopes: Vec<ExportPresetEnvelope> = fallback
            .into_iter()
            .map(|p| ExportPresetEnvelope {
                version: 1,
                kind: "rustatio-preset".to_string(),
                name: p.name,
                description: p.description,
                icon: p.icon,
                created_at: p.created_at.unwrap_or_else(|| now_str.clone()),
                settings: p.settings,
            })
            .collect();
        return serde_json::to_string_pretty(&all_envelopes)
            .map_err(|e| format!("Không thể xuất JSON: {e}"));
    }

    serde_json::to_string_pretty(&custom_or_all)
        .map_err(|e| format!("Không thể xuất JSON: {e}"))
}
