# Rustatio Android (Tauri 2) – Porting & Mobile UI/UX Implementation Plan

Complete port of Rustatio 2.14.1 from PC to Android using **Tauri 2 (Mobile)**, reusing the **Rust backend** (`rustatio-core`, `rustatio-watch`, and adapted desktop state/commands) paired with a mobile-first **Svelte 5 + TypeScript** frontend styled in **Premium Soft Neumorphism 2.0**, an **Android Foreground Service** native adapter, and an automated **GitHub Actions Release APK** workflow.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> All architectural and scope choices below were confirmed during clarification. Because this Google AI Studio container provides the Android Gradle/Kotlin SDK without Rust, Cargo, Tauri CLI, or the Android NDK, native `.so` compilation and APK packaging cannot execute locally here and will be executed via the included GitHub Actions Ubuntu workflow (never falsely marked as locally built).

- **Confirmed Decision 1 — Tauri 2 + Rust + Svelte Architecture**: Preserve the Rust backend (`rustatio-core` and Tauri commands) and build a dedicated Svelte 5 + TypeScript mobile frontend inside Tauri 2 Android, rather than rewriting business logic in Kotlin or Compose.
- **Confirmed Decision 2 — Android Foreground Service Integration**: Use a lightweight Kotlin/Android Tauri plugin adapter (`foregroundServiceType="dataSync"`) solely for background lifecycle, persistent status notification, and Android version permissions (`POST_NOTIFICATIONS`, `FOREGROUND_SERVICE_DATA_SYNC`), while Rust remains the sole Tracker Engine and state authority.
- **Confirmed Decision 3 — Strict 3-Tab Mobile UI Scope**: Implement the exact 3-tab mobile specification (`Phiên`, `Preset`, `Cài đặt`) without extra proxy-test or live-log tabs, while preserving full backend compatibility for presets, client identities, ports, and persistence.
- **Confirmed Decision 4 — Automated GitHub Actions Release APK CI**: Include a self-detecting GitHub Actions workflow on Ubuntu that installs Java, Android SDK, Android NDK, Rust Android targets (`aarch64-linux-android`, `armv7-linux-androideabi`, `x86_64-linux-android`, `i686-linux-android`), and `@tauri-apps/cli`, handles nested ZIP/repo paths if applicable, and builds the signed/unsigned Release APK artifact.

---

### 1. Overview & Core Concept

- **What It Does**: Brings Rustatio 2.14.1's BitTorrent ratio management, `.torrent` metadata parsing, HTTP/UDP tracker communication, client identity emulation, preset automation, and session persistence to Android in a mobile-first Tauri 2 application.
- **Target Audience / Persona**: Existing Rustatio users and mobile power users who need compact, high-density visibility over multiple active tracker sessions, one-tap bulk controls, preset management, and reliable background announce continuity on Android.
- **Key Value**: Zero-compromise reuse of `rustatio-core`'s battle-tested bencode parser, SHA-1 info-hash calculation, HTTP/UDP tracker client, progressive/randomized rate faker, and JSON preset schema—paired with an ergonomic Android UI and OS-compliant background execution.

---

### 2. User Experience & Visual Design

#### Visual Identity & Theme (`Premium Soft Neumorphism 2.0`)
- **Aesthetic Direction**: Soft, tactile, low-glare layered surfaces with subtle dual-edge elevation shadows, crisp hairline borders, high information density, and zero generic flat-white or pitch-black screens.
- **Color Tokens** (centralized CSS variables shared across all views):
  - **Light Mode — Light Mint**: Background `#EAF0EB`, Surface `#F1F6F1`, Elevated `#F5F8F4`, Secondary `#DFE9E1`, Primary Mint `#35B889`, Dark Mint `#168C67`, Soft Mint `#D1EBDD`, Lavender `#E6E0F2`, Warm `#F3E5DA`, Primary Text `#263C32`, Secondary Text `#71847A`, Divider `#D3DFD6`, Input `#E7EFE8`.
  - **Dark Mode — Deep Forest**: Background `#18211D`, Surface `#202D26`, Elevated `#26352D`, Secondary `#2D3C33`, Primary Mint `#49D3A1`, Dark Mint `#35B889`, Soft Mint `#294A3C`, Lavender `#393449`, Warm `#49382F`, Primary Text `#EDF5EF`, Secondary Text `#B0C1B6`, Divider `#3B4B41`, Input `#26342C`.
  - **Semantic Status Tokens**: Upload `#35B889`, Download `#5A9BE6`, Error `#E55858`, Warning `#E6A63E`, Running `#49D3A1`, Paused `#8B9E94`, Stopped `#6B7A72` (plus distinct accents for `Connecting`, `Announcing`, and `Waiting`).
- **Typography & Density**: Modern sans-serif stack (`Inter` / system sans) with tabular numerals (`font-variant-numeric: tabular-nums`) for speeds, ratios, and byte counts; single-line truncation with ellipsis for long torrent names, info hashes, and tracker URLs (expandable in Diagnostics).

#### Fixed 3-Tab Navigation
- Persistent bottom navigation bar (respecting Android system navigation bar safe-area insets) with exactly three tabs: **Phiên**, **Preset**, and **Cài đặt**.
- Switching tabs preserves scroll/filter state and never interrupts running Rust backend sessions.

#### Key User Flows

1. **Tab 1 — Phiên (`Sessions`)**:
   - **Compact Header & Summary**: Title `Quản lý phiên`, live active count subtitle, primary `+ Thêm phiên` action button, and a slim overview card showing aggregate Upload (Mint `#35B889`) and Download (Blue `#5A9BE6`) rates.
   - **Bulk Controls & Instant Search**: Responsive row of three real actions (`Chạy hết`, `Tạm dừng`, `Dừng hết`), single-line search bar (`"Tìm theo tên, tracker hoặc info hash..."`) with search/clear icons, and horizontally scrollable status filter chips (`Tất cả`, `Đang chạy`, `Đang kết nối`, `Đang announce`, `Chờ lần announce tiếp theo`, `Tạm dừng`, `Đã dừng`, `Lỗi tracker`).
   - **Session Cards & Diagnostics Sheet**: Compact Neumorphic cards showing name, status badge, quick menu, truncated Info Hash & Tracker URL, Upload/Download totals & speeds, Seeders/Leechers, conditional Error row, and Next Announce timestamp. Tapping a card opens a scrollable Bottom Sheet with full **Thông tin phiên**, **Thông tin Client**, **Thông tin Tracker** (HTTP status, interval, seeders, leechers, peers, announce time, last error), **Thống kê**, and live actions (`Announce ngay`, `Tạm dừng / Tiếp tục`, `Dừng`, `Xóa phiên`). Values with no backend data yet display `—` rather than fake `0`s.
   - **Mandatory `.torrent` Import Flow**: `+ Thêm phiên` → Android SAF File Picker (`OpenDocument` filtered to `.torrent` / `application/x-bittorrent`) → Native URI permission & byte stream → Rust `TorrentInfo::from_bytes` metadata parse → session creation & immediate list update (no manual form, no Magnet Link). Includes dedicated empty state (`Chưa có phiên nào`).

2. **Tab 2 — Preset**:
   - **Header & Actions**: `Quản lý Preset` + subtitle, prominent full-width `Tạo Preset mới`, and paired `Nhập JSON` / `Xuất JSON` buttons (two-row fallback on narrow phones so text never wraps awkwardly).
   - **Preset Cards**: Displays name, badges (`Tích hợp`, `Mặc định`, `Đang áp dụng`), color-grouped real settings summary (Rates & Randomization, Progressive Ramp, Stop Conditions & Idle, Client), and actions (`Áp dụng`, `Sửa`, `Nhân bản`, `Đặt mặc định`, `Xóa`).
   - **Full-Width Bottom Sheets**: Create/Edit Preset sheet exposing only genuine `PresetSettings` fields from Rustatio 2.14.1 with per-field validation and keyboard-safe scrolling; Import JSON dialog with syntax/schema validation and real backend import count; Export JSON sheet with clipboard copy and Android Share/Save document support.

3. **Tab 3 — Cài đặt (`Settings`)**:
   - **Group A — Giao diện**: Light Mint / Deep Forest toggle card, immediately switching CSS theme tokens and persisting selection to backend config.
   - **Group B — Client / Version / Target OS**: Summary card opening a selector sheet with Backend-sourced `Client` list (`qBittorrent`, `µTorrent`, `Transmission`, `Deluge`, `BitTorrent`, `rTorrent`), dynamically filtered `Version` list, and `Target OS` (`Windows 7`, `Windows 10`, `Windows 11`) which updates client User-Agent / headers and persists globally.
   - **Group C — Port**: Card displaying current Announce Port + Router icon; opens configuration dialog with explicit distinction between **Announce Port** (reported to tracker) and **Listening Port** (optional local TCP peer listener bound by `PeerListenerService`), plus a `Ngẫu nhiên` button (1024–65535) that updates only the draft input until `Lưu` is tapped.
   - **Group D — Quản lý Preset**: Quick-navigation card jumping straight to Tab 2 (`Preset`).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Audit & Reuse `rustatio-core` + Mobile Entrypoint (`lib.rs`)**:
  - *Chosen Approach*: Extract `rustatio-2.14.1` cleanly into the repository layout, add `#[cfg_attr(mobile, tauri::mobile_entry_point)]` in `rustatio-desktop/src/lib.rs` (keeping desktop binary compatibility), and gate desktop-only plugins (`updater`, `tray-icon`, `process`, `os-release`) behind `#[cfg(not(any(target_os = "android", target_os = "ios")))]`.
  - *Why*: Preserves 100% of `rustatio-core` protocol logic (Bencode, HTTP/UDP tracker, peer ID/key generation, rate randomization, progressive ramp, stop conditions) with zero logic drift.
- **Decision 2 — Android `app_data_dir()` Persistence & Preset Storage**:
  - *Chosen Approach*: Replace PC `$HOME/.config/rustatio/` paths on Android with Tauri's `app.path().app_data_dir()` resolved at startup and stored inside `AppState` / `persistence.rs`, extending `PersistedState` with custom/default presets and `target_os` while maintaining backward compatibility with existing JSON schemas.
  - *Why*: Android sandboxes apps and does not provide a writable `$HOME/.config` directory; using `app_data_dir()` guarantees reliable restoration after process death or app restart.
- **Decision 3 — Android Native Plugin (`RustatioAndroidPlugin`) for SAF + Foreground Service**:
  - *Chosen Approach*: Implement a dedicated Tauri 2 Android Kotlin plugin registered in `MainActivity` that handles: (1) `OpenDocument` `.torrent` URI selection + `ContentResolver` byte streaming to Rust (`load_torrent_bytes`), (2) `RustatioForegroundService` (`foregroundServiceType="dataSync"`) synced from Rust whenever active session counts/rates change, and (3) Android 13+ `POST_NOTIFICATIONS` runtime check and JSON export sharing/saving.
  - *Why*: Avoids broad storage permissions (`READ_EXTERNAL_STORAGE`), avoids duplicating any tracker state in Kotlin, and respects Google Play Foreground Service rules.
- **Decision 4 — Target OS & Port Separation**:
  - *Chosen Approach*: Add `TargetOs` (`Windows7`, `Windows10`, `Windows11`) to `ClientConfig` / `AppConfig` so tracker HTTP User-Agent / OS metadata reflects the chosen platform, and clearly separate `announce_port` (`config.client.default_port` / `FakerConfig.port`) from `listening_port_enabled` / `PeerListenerService` bound port in both Rust and UI.
  - *Why*: Matches tracker anti-cheat expectations and honors the user's explicit distinction between Announce Port and Listening Port.
- **Decision 5 — GitHub Actions CI/CD Release APK Workflow**:
  - *Chosen Approach*: Provide `.github/workflows/android-release.yml` targeting `ubuntu-latest`, installing JDK 17, Android SDK/NDK, Rustup + all 4 Android ABIs, Node.js, and `@tauri-apps/cli`, dynamically locating the Tauri project root (or extracting nested archives if present), running frontend build + `cargo tauri android build --apk`, and uploading the APK artifact.
  - *Why*: Guarantees reproducible, verifiable APK builds outside Google AI Studio's Android-only container.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       ANDROID HOST (Kotlin / Gradle)                    │
│  MainActivity (TauriActivity) ──► RustatioAndroidPlugin                 │
│   ├─ SAF File Picker (OpenDocument .torrent) ─► ContentResolver bytes   │
│   ├─ RustatioForegroundService (dataSync)   ◄─► Persistent Notification │
│   └─ Permissions (INTERNET, POST_NOTIFICATIONS, FOREGROUND_SERVICE)     │
└───────────────────────────────▲───────────────────────┬─────────────────┘
                                │ Tauri Plugin Bridge   │ JNI / Lifecycle
┌───────────────────────────────┴───────────────────────▼─────────────────┐
│                       TAURI 2 RUNTIME + RUST BACKEND                    │
│  rustatio-desktop (lib.rs / mobile_entry_point)                         │
│   ├─ Commands: instances, faker, config, presets, system, android_bridge│
│   ├─ AppState (RwLock<HashMap<u32, FakerInstance>>, AppConfig, Presets) │
│   ├─ Persistence: app_data_dir()/state.json & presets.json & config.json│
│   └─ Background Sync Hook ──► updates ForegroundService notification    │
│                                                                         │
│  rustatio-core (100% reused protocol & faker engine)                    │
│   ├─ TorrentInfo::from_bytes (Bencode + SHA-1 info_hash)                │
│   ├─ TrackerClient (HTTP reqwest+rustls / UDP socket)                   │
│   ├─ RatioFaker + Scheduler (progressive/random rates, stop conditions) │
│   ├─ ClientType / ClientConfig / TargetOs (peer_id, key, User-Agent)    │
│   └─ PeerListenerService (optional local TCP handshake listener)        │
└───────────────────────────────▲─────────────────────────────────────────┘
                                │ Tauri IPC (invoke + events)
┌───────────────────────────────┴─────────────────────────────────────────┐
│                    SVELTE 5 + TYPESCRIPT FRONTEND                       │
│  Design System (Light Mint / Deep Forest Neumorphism 2.0 CSS Tokens)    │
│  AppShell (3-Tab Bottom Bar + Safe Areas)                               │
│   ├─ Tab 1: SessionsView ─► SummaryBar, BulkBar, Search/Chips, Cards,   │
│   │                         SessionDetailsSheet (Diagnostics + Actions) │
│   ├─ Tab 2: PresetsView  ─► PresetCards, PresetEditorSheet,             │
│   │                         JsonImportSheet, JsonExportSheet            │
│   └─ Tab 3: SettingsView ─► ThemeCard, ClientOsDialog, PortDialog,      │
│                             PresetShortcutCard                          │
└─────────────────────────────────────────────────────────────────────────┘
```

#### Data Model & State
- **Single Source of Truth**: Rust `AppState` holds `fakers: HashMap<u32, FakerInstance>`, `config: AppConfig`, `presets: PresetStore` (built-in + custom + `default_preset_id` + `active_preset_id`), `peer_listener: PeerListenerService`, and `app_data_dir: PathBuf`.
- **Session Status Mapping**: Rust `FakerStats` (`FakerState` + `tracker_error` + `is_idling` + `tracker_retry_at_ms` + `announce_in_progress`) maps deterministically to the 7 mobile UI states (`Running`, `Connecting`, `Announcing`, `Waiting`, `Paused`, `Stopped`, `TrackerError`) without fabricated metrics.
- **Process-Kill Recovery**: Every state change, session start/pause/stop, preset edit, and periodic 30s/lifecycle `onStop` flush writes atomically (`*.tmp` + `sync_all` + `rename`) into `app_data_dir()`. On relaunch, Rust restores instances with cumulative stats and restores active foreground tracking state if sessions are auto-resumed or user-resumed.

#### Interactive Component & State Mapping
- **Add Session (`+ Thêm phiên`)**: Invokes `RustatioAndroidPlugin.pickTorrentFile()` → returns base64/byte buffer + filename → invokes Rust `import_torrent_bytes` → parses `TorrentInfo` → creates `FakerInstance` with active default preset/global config → saves state → emits reactive update to Svelte store.
- **Session Actions & Bulk Controls**: `start_faker`, `pause_faker`, `resume_faker`, `stop_faker`, `manual_announce`, `delete_instance`, `start_all`, `pause_all`, `stop_all` all execute in Rust, recalculate active count + aggregate speeds, and push a single status payload to `RustatioForegroundService` (`startForeground` when `activeCount > 0`, `stopForeground` when `0`).
- **Presets & JSON**: Rust manages built-in + custom presets (`list_presets`, `save_preset`, `delete_preset`, `duplicate_preset`, `set_default_preset`, `apply_preset`, `import_presets_json`, `export_presets_json`) keeping full schema parity with `rustatio-preset` v1 JSON.
- **Settings**: `update_config` persists theme (`dark_mode`), `ClientType`, `client_version`, `TargetOs`, `announce_port`, and `listening_port_enabled` / `listening_port`, immediately updating running/new instances according to PC rules.

#### Verification Strategy
- **In AI Studio**: Verify Svelte/TypeScript typechecking & production bundle (`npm run build`), verify `PORTING_STATUS.md` tracking, and statically validate Gradle/Kotlin/AndroidManifest/Cargo/Workflow manifests.
- **Via GitHub Actions & Real Android Device**: `.github/workflows/android-release.yml` verifies `cargo check` / `cargo test` for `rustatio-core` + `rustatio-desktop`, compiles the Android `.so` targets with NDK, packages the Release APK via `tauri android build`, and marks runtime/device tests (`NOT TESTED` until executed on CI/device).
