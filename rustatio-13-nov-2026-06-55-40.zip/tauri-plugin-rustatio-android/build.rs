const COMMANDS: &[&str] = &[
    "pick_torrent_file",
    "sync_foreground_service",
    "request_notification_permission",
    "get_service_status",
    "share_or_save_json",
];

fn main() {
    tauri_plugin::Builder::new(COMMANDS)
        .android_path("android")
        .build();
}
