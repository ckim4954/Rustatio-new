use serde::{Deserialize, Serialize};
use tauri::{
    plugin::{Builder, TauriPlugin},
    AppHandle, Manager, Runtime,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PickedTorrentFile {
    pub name: String,
    pub bytes_base64: String,
    pub size: u64,
    pub cancelled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ForegroundServiceSyncPayload {
    pub active_sessions: u32,
    pub upload_rate_kbps: f64,
    pub download_rate_kbps: f64,
    pub status_line: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct ForegroundServiceStatus {
    pub is_running: bool,
    pub active_sessions: u32,
    pub notification_granted: bool,
    pub sdk_int: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ShareJsonPayload {
    pub filename: String,
    pub content: String,
    pub mode: String, // "save" | "share"
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ShareJsonResult {
    pub success: bool,
    pub message: String,
}

#[cfg(target_os = "android")]
pub struct RustatioAndroidHandle<R: Runtime>(tauri::plugin::PluginHandle<R>);

#[cfg(not(target_os = "android"))]
pub struct RustatioAndroidHandle<R: Runtime>(std::marker::PhantomData<R>);

impl<R: Runtime> RustatioAndroidHandle<R> {
    #[cfg(target_os = "android")]
    pub fn pick_torrent_file(&self) -> Result<PickedTorrentFile, String> {
        self.0
            .run_mobile_plugin("pickTorrentFile", ())
            .map_err(|e| format!("Android File Picker error: {e}"))
    }

    #[cfg(not(target_os = "android"))]
    pub fn pick_torrent_file(&self) -> Result<PickedTorrentFile, String> {
        Err("Android File Picker is only available on Android".to_string())
    }

    #[cfg(target_os = "android")]
    pub fn sync_foreground_service(
        &self,
        payload: ForegroundServiceSyncPayload,
    ) -> Result<ForegroundServiceStatus, String> {
        self.0
            .run_mobile_plugin("syncForegroundService", payload)
            .map_err(|e| format!("Foreground service sync error: {e}"))
    }

    #[cfg(not(target_os = "android"))]
    pub fn sync_foreground_service(
        &self,
        payload: ForegroundServiceSyncPayload,
    ) -> Result<ForegroundServiceStatus, String> {
        Ok(ForegroundServiceStatus {
            is_running: payload.active_sessions > 0,
            active_sessions: payload.active_sessions,
            notification_granted: true,
            sdk_int: 0,
        })
    }

    #[cfg(target_os = "android")]
    pub fn request_notification_permission(&self) -> Result<ForegroundServiceStatus, String> {
        self.0
            .run_mobile_plugin("requestNotificationPermission", ())
            .map_err(|e| format!("Notification permission error: {e}"))
    }

    #[cfg(not(target_os = "android"))]
    pub fn request_notification_permission(&self) -> Result<ForegroundServiceStatus, String> {
        Ok(ForegroundServiceStatus {
            is_running: false,
            active_sessions: 0,
            notification_granted: true,
            sdk_int: 0,
        })
    }

    #[cfg(target_os = "android")]
    pub fn get_service_status(&self) -> Result<ForegroundServiceStatus, String> {
        self.0
            .run_mobile_plugin("getServiceStatus", ())
            .map_err(|e| format!("Service status error: {e}"))
    }

    #[cfg(not(target_os = "android"))]
    pub fn get_service_status(&self) -> Result<ForegroundServiceStatus, String> {
        Ok(ForegroundServiceStatus::default())
    }

    #[cfg(target_os = "android")]
    pub fn share_or_save_json(&self, payload: ShareJsonPayload) -> Result<ShareJsonResult, String> {
        self.0
            .run_mobile_plugin("shareOrSaveJson", payload)
            .map_err(|e| format!("Android share/save error: {e}"))
    }

    #[cfg(not(target_os = "android"))]
    pub fn share_or_save_json(&self, _payload: ShareJsonPayload) -> Result<ShareJsonResult, String> {
        Err("Android JSON share/save is only available on Android".to_string())
    }
}

pub trait RustatioAndroidExt<R: Runtime> {
    fn rustatio_android(&self) -> &RustatioAndroidHandle<R>;
}

impl<R: Runtime, T: Manager<R>> RustatioAndroidExt<R> for T {
    fn rustatio_android(&self) -> &RustatioAndroidHandle<R> {
        self.state::<RustatioAndroidHandle<R>>().inner()
    }
}

pub fn init<R: Runtime>() -> TauriPlugin<R> {
    Builder::new("rustatio-android")
        .setup(|app, api| {
            #[cfg(target_os = "android")]
            {
                let handle =
                    api.register_android_plugin("com.rustatio.android", "RustatioAndroidPlugin")?;
                app.manage(RustatioAndroidHandle(handle));
            }
            #[cfg(not(target_os = "android"))]
            {
                let _ = api;
                app.manage(RustatioAndroidHandle::<R>(std::marker::PhantomData));
            }
            Ok(())
        })
        .build()
}

pub fn sync_background_service<R: Runtime>(
    app: &AppHandle<R>,
    active_sessions: u32,
    upload_rate_kbps: f64,
    download_rate_kbps: f64,
    status_line: String,
) {
    if let Some(handle) = app.try_state::<RustatioAndroidHandle<R>>() {
        let payload = ForegroundServiceSyncPayload {
            active_sessions,
            upload_rate_kbps,
            download_rate_kbps,
            status_line,
        };
        if let Err(err) = handle.sync_foreground_service(payload) {
            log::warn!("Failed to sync Android Foreground Service: {err}");
        }
    }
}
