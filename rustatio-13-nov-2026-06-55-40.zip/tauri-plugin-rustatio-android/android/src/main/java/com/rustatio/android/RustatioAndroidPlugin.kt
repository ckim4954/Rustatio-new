package com.rustatio.android

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.result.ActivityResult
import androidx.core.content.ContextCompat
import app.tauri.PermissionState
import app.tauri.annotation.ActivityCallback
import app.tauri.annotation.Command
import app.tauri.annotation.InvokeArg
import app.tauri.annotation.Permission
import app.tauri.annotation.PermissionCallback
import app.tauri.annotation.TauriPlugin
import app.tauri.plugin.Invoke
import app.tauri.plugin.JSObject
import app.tauri.plugin.Plugin
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

@InvokeArg
class SyncForegroundServiceArgs {
    var activeSessions: Int = 0
    var uploadRateKbps: Double = 0.0
    var downloadRateKbps: Double = 0.0
    var statusLine: String = ""
}

@InvokeArg
class ShareJsonArgs {
    var filename: String = "rustatio-presets.json"
    var content: String = ""
    var mode: String = "share"
}

@TauriPlugin(
    permissions = [
        Permission(
            strings = [Manifest.permission.POST_NOTIFICATIONS],
            alias = "notifications"
        )
    ]
)
class RustatioAndroidPlugin(private val activity: Activity) : Plugin(activity) {

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var pendingJsonContent: String? = null

    @Command
    fun pickTorrentFile(invoke: Invoke) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("application/x-bittorrent", "application/octet-stream", "*/*")
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(invoke, intent, "onTorrentFilePicked")
    }

    @ActivityCallback
    fun onTorrentFilePicked(invoke: Invoke, result: ActivityResult) {
        if (result.resultCode != Activity.RESULT_OK) {
            val ret = JSObject().apply {
                put("cancelled", true)
                put("name", "")
                put("bytesBase64", "")
                put("size", 0)
            }
            invoke.resolve(ret)
            return
        }

        val uri: Uri? = result.data?.data
        if (uri == null) {
            invoke.reject("Không nhận được URI file .torrent từ bộ chọn tệp Android.")
            return
        }

        ioExecutor.execute {
            try {
                val displayName = resolveDisplayName(uri) ?: "selected.torrent"
                val bytes = readUriBytes(uri)
                val looksLikeTorrentFile = displayName.lowercase().endsWith(".torrent")
                val looksLikeBencodeDict = bytes.isNotEmpty() && bytes[0] == 'd'.code.toByte()

                if (!looksLikeTorrentFile && !looksLikeBencodeDict) {
                    invoke.reject("Tệp đã chọn ($displayName) không phải định dạng .torrent hợp lệ.")
                    return@execute
                }

                val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                val ret = JSObject().apply {
                    put("cancelled", false)
                    put("name", displayName)
                    put("bytesBase64", encoded)
                    put("size", bytes.size)
                }
                invoke.resolve(ret)
            } catch (e: SecurityException) {
                invoke.reject("Không có quyền đọc URI tệp .torrent: ${e.message ?: "SecurityException"}")
            } catch (e: Exception) {
                invoke.reject("Không thể đọc tệp .torrent: ${e.message ?: "Unknown error"}")
            }
        }
    }

    @Command
    fun syncForegroundService(invoke: Invoke) {
        val args = invoke.parseArgs(SyncForegroundServiceArgs::class.java)
        try {
            RustatioForegroundService.sync(
                context = activity.applicationContext,
                activeSessions = args.activeSessions,
                uploadRateKbps = args.uploadRateKbps,
                downloadRateKbps = args.downloadRateKbps,
                statusLine = args.statusLine
            )
            invoke.resolve(buildStatusObject())
        } catch (e: Exception) {
            invoke.reject("Không thể cập nhật Foreground Service: ${e.message ?: "Unknown error"}")
        }
    }

    @Command
    fun getServiceStatus(invoke: Invoke) {
        invoke.resolve(buildStatusObject())
    }

    @Command
    fun requestNotificationPermission(invoke: Invoke) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            invoke.resolve(buildStatusObject())
            return
        }
        if (hasNotificationPermission()) {
            invoke.resolve(buildStatusObject())
            return
        }
        if (getPermissionState("notifications") == PermissionState.GRANTED) {
            invoke.resolve(buildStatusObject())
            return
        }
        requestPermissionForAlias("notifications", invoke, "onNotificationPermissionResult")
    }

    @PermissionCallback
    fun onNotificationPermissionResult(invoke: Invoke) {
        invoke.resolve(buildStatusObject())
    }

    @Command
    fun shareOrSaveJson(invoke: Invoke) {
        val args = invoke.parseArgs(ShareJsonArgs::class.java)
        if (args.mode == "save") {
            pendingJsonContent = args.content
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, args.filename.ifBlank { "rustatio-presets.json" })
            }
            startActivityForResult(invoke, intent, "onSaveJsonDocumentResult")
            return
        }

        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_SUBJECT, args.filename)
                putExtra(Intent.EXTRA_TEXT, args.content)
            }
            val chooser = Intent.createChooser(sendIntent, "Chia sẻ cấu hình Preset JSON")
            activity.startActivity(chooser)
            val ret = JSObject().apply {
                put("success", true)
                put("message", "Đã mở hộp thoại chia sẻ Android.")
            }
            invoke.resolve(ret)
        } catch (e: Exception) {
            invoke.reject("Không thể chia sẻ JSON: ${e.message ?: "Unknown error"}")
        }
    }

    @ActivityCallback
    fun onSaveJsonDocumentResult(invoke: Invoke, result: ActivityResult) {
        val content = pendingJsonContent
        pendingJsonContent = null

        if (result.resultCode != Activity.RESULT_OK) {
            val ret = JSObject().apply {
                put("success", false)
                put("message", "Đã hủy lưu file JSON.")
            }
            invoke.resolve(ret)
            return
        }

        val uri: Uri? = result.data?.data
        if (uri == null || content == null) {
            invoke.reject("Không thể xác định đích lưu file JSON.")
            return
        }

        ioExecutor.execute {
            try {
                activity.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(content.toByteArray(Charsets.UTF_8))
                    stream.flush()
                } ?: throw IllegalStateException("OutputStream null")

                val ret = JSObject().apply {
                    put("success", true)
                    put("message", "Đã lưu Preset JSON thành công.")
                }
                invoke.resolve(ret)
            } catch (e: Exception) {
                invoke.reject("Lỗi khi ghi file JSON: ${e.message ?: "Unknown error"}")
            }
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                activity,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun buildStatusObject(): JSObject {
        return JSObject().apply {
            put("isRunning", RustatioForegroundService.isServiceRunning)
            put("activeSessions", RustatioForegroundService.lastActiveSessions)
            put("notificationGranted", hasNotificationPermission())
            put("sdkInt", Build.VERSION.SDK_INT)
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        activity.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    return cursor.getString(idx)
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun readUriBytes(uri: Uri): ByteArray {
        val maxBytes = 32 * 1024 * 1024 // 32 MB safety cap for .torrent files
        val buffer = ByteArray(16 * 1024)
        val out = ByteArrayOutputStream()
        activity.contentResolver.openInputStream(uri)?.use { input ->
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > maxBytes) {
                    throw IllegalArgumentException("Tệp .torrent vượt quá giới hạn 32 MB.")
                }
                out.write(buffer, 0, read)
            }
        } ?: throw IllegalStateException("Không thể mở luồng đọc tệp từ URI.")
        return out.toByteArray()
    }
}
