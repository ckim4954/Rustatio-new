package com.rustatio.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Android Foreground Service responsible strictly for background process lifecycle
 * and persistent status notification while Rust backend sessions are active.
 *
 * All tracker protocol logic, timers, and session state remain exclusively inside Rust.
 */
class RustatioForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForegroundServiceInternal()
                return START_NOT_STICKY
            }
            else -> {
                val activeCount = intent?.getIntExtra(EXTRA_ACTIVE_SESSIONS, lastActiveSessions) ?: lastActiveSessions
                val uploadRate = intent?.getDoubleExtra(EXTRA_UPLOAD_RATE, lastUploadRate) ?: lastUploadRate
                val downloadRate = intent?.getDoubleExtra(EXTRA_DOWNLOAD_RATE, lastDownloadRate) ?: lastDownloadRate
                val statusLine = intent?.getStringExtra(EXTRA_STATUS_LINE) ?: lastStatusLine

                lastActiveSessions = activeCount
                lastUploadRate = uploadRate
                lastDownloadRate = downloadRate
                lastStatusLine = statusLine

                if (activeCount <= 0) {
                    stopForegroundServiceInternal()
                    return START_NOT_STICKY
                }

                isServiceRunning = true
                acquireWakeLockIfNeeded()
                val notification = buildNotification(activeCount, uploadRate, downloadRate, statusLine)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        releaseWakeLock()
        isServiceRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun stopForegroundServiceInternal() {
        isServiceRunning = false
        lastActiveSessions = 0
        releaseWakeLock()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Phiên Rustatio đang chạy",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Hiển thị trạng thái các phiên tracker đang hoạt động dưới nền"
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(
        activeCount: Int,
        uploadRateKbps: Double,
        downloadRateKbps: Double,
        statusLine: String
    ): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "Rustatio • $activeCount phiên đang hoạt động"
        val ratesText = "↑ ${formatRate(uploadRateKbps)}   ↓ ${formatRate(downloadRateKbps)}"
        val body = if (statusLine.isNotBlank()) "$ratesText • $statusLine" else ratesText

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(contentPendingIntent)
            .build()
    }

    private fun formatRate(kbps: Double): String {
        return if (kbps >= 1024.0) {
            String.format(java.util.Locale.US, "%.2f MB/s", kbps / 1024.0)
        } else {
            String.format(java.util.Locale.US, "%.1f KB/s", kbps)
        }
    }

    private fun acquireWakeLockIfNeeded() {
        val current = wakeLock
        if (current != null && current.isHeld) return
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rustatio:tracker_sync").apply {
            setReferenceCounted(false)
            // Bounded wake lock timeout (30 minutes), refreshed on periodic Rust syncs.
            acquire(30 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                }
            }
        } catch (_: Throwable) {
            // Ignore already-released lock
        } finally {
            wakeLock = null
        }
    }

    companion object {
        const val CHANNEL_ID = "rustatio_sessions"
        const val NOTIFICATION_ID = 4102
        const val ACTION_SYNC = "com.rustatio.android.action.SYNC"
        const val ACTION_STOP = "com.rustatio.android.action.STOP"
        const val EXTRA_ACTIVE_SESSIONS = "active_sessions"
        const val EXTRA_UPLOAD_RATE = "upload_rate"
        const val EXTRA_DOWNLOAD_RATE = "download_rate"
        const val EXTRA_STATUS_LINE = "status_line"

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var lastActiveSessions: Int = 0
            private set

        @Volatile
        var lastUploadRate: Double = 0.0
            private set

        @Volatile
        var lastDownloadRate: Double = 0.0
            private set

        @Volatile
        var lastStatusLine: String = ""
            private set

        fun sync(
            context: Context,
            activeSessions: Int,
            uploadRateKbps: Double,
            downloadRateKbps: Double,
            statusLine: String
        ) {
            if (activeSessions <= 0) {
                if (isServiceRunning) {
                    val stopIntent = Intent(context, RustatioForegroundService::class.java).apply {
                        action = ACTION_STOP
                    }
                    context.startService(stopIntent)
                }
                lastActiveSessions = 0
                lastUploadRate = 0.0
                lastDownloadRate = 0.0
                lastStatusLine = ""
                return
            }

            val intent = Intent(context, RustatioForegroundService::class.java).apply {
                action = ACTION_SYNC
                putExtra(EXTRA_ACTIVE_SESSIONS, activeSessions)
                putExtra(EXTRA_UPLOAD_RATE, uploadRateKbps)
                putExtra(EXTRA_DOWNLOAD_RATE, downloadRateKbps)
                putExtra(EXTRA_STATUS_LINE, statusLine)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
