-keepattributes *Annotation*
-keep class com.rustatio.android.** { *; }
-keepclassmembers class com.rustatio.android.** {
    @app.tauri.annotation.* <methods>;
    *;
}
